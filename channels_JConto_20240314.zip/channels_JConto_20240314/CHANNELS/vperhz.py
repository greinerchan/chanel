# vperhz.py - a vfunc_file for channels.py
''' uses:
  xchan = [A,B] - two channels per list
  ch_id, ch_data

  output:
     My['YP'] = result, where Ypi = Ai/Bi
'''
import numpy as np
global ch_id, ch_data
chanAid  = ch_id[channelst[0]]
chanBid  = ch_id[channelst[1]]
chA_idlst= getchanidlst(chanAid)
My['MACHBUSI'] = 'Machine %s-%s %s'%(chA_idlst[1], chA_idlst[-1],chA_idlst[2])
print(My['MACHBUSI'],chA_idlst)
A = np.array(ch_data[channelst[0]])		  #V chan, in pu
B = np.array(ch_data[channelst[1]])        #Freq chan, requires scale
C = B + 1								    #numpy array algebra
My['YP'] = A/C
