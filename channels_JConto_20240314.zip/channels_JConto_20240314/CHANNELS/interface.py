# interface.py - a vfunc_file for channels.py
''' interface.py - applies math to a group of channels
This file is called using the form "exec(open(My['VFUNC_FILE']).read())" that preserves access to all vars
Interface = sum of branch power  (direction of flow is controlled at channel definition
uses:
  channelst - n-channels per list [a,b,..]
  chanData_dict
  chanvals_npa(chanData_dict,chan)
  output:
     My['YP'] = array, where array = Sum(A,B,..)
'''
import numpy as np
global My, ch_id, ch_data

first = True
for chan in channelst:
    X = chanvals_npa(ch_data,chan)
    if first:
       T = np.zeros(len(X))
       first = False
    T += X											#numpy array algebra
My['YP'] = T
My['RETURN']= 'BREAK'
