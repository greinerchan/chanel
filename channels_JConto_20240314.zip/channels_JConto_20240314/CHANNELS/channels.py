# -*- coding: cp1252 -*-        #//# -*- coding: utf-8 -*-      #//# -*- coding: iso-8859-15 -*-
#channels.py  - Channels processing tool
from __future__ import print_function
'''
tested with python 27, 37, 39
====================================================================================================
 developed by Jose Conto
 @ Copyright 2016  Jose Conto - All rights reserved.
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
 associated documentation files (the "Software"), to deal in the Software without restriction, 
 including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense
 copies of the Software, and to permit persons to whom the Software is furnished to do so, 
 subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or 
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
 OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
====================================================================================================
Module dependencies:
  wx        -  4.1.1        graphics library
  matplotlib-  3.4.2        plotting tool
  numpy     -  1.22.4       numeric library
  PyPDF2    -  3.0.1        PDF library
  dyntools  -               PTI, tool to access channels
  excelpy   -               PTI, excel functions
  caspy     -               PTI, case data
====================================================================================================
Modules, Functions, Classes
import os, sys
import time,datetime
import math
import wx
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import glob      #The glob module exports a single function
def PDFmergerpxp(pdf_files,destination):
    from PyPDF2 import PdfReader, PdfFileWriter
def PDFmerger(pdf_files,destination):
    from PyPDF2 import PdfReader, PdfMerger
def columnlst(c,array2d):
def PSSe_extendedname(str):
def About(version):
def info(version):
def infoGUI(version):
def filechoose(filename,wildcardstr = "All files (*.*)|*.*"):
class MyFrame(wx.Frame):
    def __p1_layout(self):
    def p1OnFileSelect1(self, event):
    def p1OnFileSelect2(self, event):
    def p1guivargetvalue(self):
    def p1guiprintvalues(self):
    def p1guivarsetvalue(self):
    def p1guivarinitvalue(self):
    def p1OnRun(self, event):
    def p1OnQuit(self, event):
    def __p2_layout(self):       
    def p2guivargetvalue(self):
    def p2guivarsetvalue(self):
    def p2guivarinitvalue(self):
    def p2guistr2value(self):
    def p2guivalue2str(self):
    def p2guiprintvalues(self):
    def __p3_layout(self):       
    def OnQuit(self):
def INIsample():
def initialize(My):
def timeintervals(timelst,tinterval):
def getchanvals(chanData,chanid):
def chanvals_npa(chanData,chanid):
    import numpy as np
def My2filename(targetfn,prefix=None,suffix=None):
def My2str(targetstr,prefix=None,suffix=None):
def fnameroot(xfile):
def OUTfiles_select(My):
def pltfuncPU(vectin):
def pltfunc(vectin,chani):
def pltfuncPU_npa(vectin):
def pltfunc_npa(vectin):
    import numpy as np
def getchanidlst(chanidstr):
def Channel_select(chnfobj,outidx,channels):
def pagetitle_cmd(My):
def title_cmd(My):
def legend_parse(My):
    def legend_arg(test,position,fontsize):   #test = [position,4]
def getplotrc(ploti,rmax,cmax):
def points2plotvec(pointlst):
def plotoptions(axes,ploti,My):
def buschansort(chanbus,bchanlist,chanID_dict):
def chanpltpage(chanlist,My):
def Array_plot_1x1(axes,ploti,timelst,Y,My):
def Array_plot_1xm(axes,ploti,timelst,Y,My):
def page_plot_nx1(channelst,chanID_dict,chanData_dict,pp):
def page_plot_nxm(channelst,chanID_dict,chanData_dict,pp):
    import matplotlib.gridspec as gridspec
def Channel_plot(chnfobj,channelst,outlsti,fn_suffix=''):
def vfunc_plot_nx1(channelst,chanID_dict,chanData_dict,pp):
def vfunc_plot(chnfobj,channelst,outlsti,fn_suffix=''):
def pyplot_compare(My):     #1x1 or nx1
    import dyntools
    import numpy as np
def pyplot_compare_nxm(My):
    import matplotlib.gridspec as gridspec    
    import dyntools
def All_Channel_info(chnfobj,mychannels):
def Channels_export(chnfobj,mychannels,filei):
def peakdet(v, delta, x = None):
def peakdecay_damping(y,tvec, chan, My):     #damping of single channel
def UVDR(y,t,UVval,UVtime):           #Under Value Delay Recovery 
def OVDR(y,t,OVval,OVtime):           #Over Value Delay Recovery 
def damping(y,x,My):
def make_xlWorkbook(Wbfilename='',PgName='',
    import excelpy
def slope(y,x,idx):
    import numpy
def min2right(v,idx):
def min2left(v,idx):
def Channel_Index(chnfobj,channelsx,My,outidx):            #for a single OUT file 
        import numpy
def channelsmain():
       import redirect
    import dyntools
          import caspy
def main():
====================================================================================================
'''
import os, sys
import time,datetime
import math
import wx
import numpy as np
import matplotlib
#matplotlib.use('WXAgg',warn=False, force=True)
#from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import glob      #The glob module exports a single function
                 #also called glob, which takes a filename pattern
                 #and returns a list of all the filenames that match that pattern
#import multiprocessing as mup
import pandas as pd
import matrixpencil as mp
# =============================================================================================
# global var: My
My = {}
debug = 0
My['PRGNAME']= 'channels'
My['PRGVERSION'] = '2023.01.06'
cwd = os.getcwd()
root, ext = os.path.splitext(sys.argv[0])
if '_' in root:
   My['PRGNAMEVER'] = root[root.index('_'):]
else:
   My['PRGNAMEVER'] = ''
prgnamever = My['PRGNAMEVER']

# add user's code folder
# check for pythonCode
pythonCode = os.path.join(cwd,'SCRIPTS')
if os.path.isdir(pythonCode):
   if pythonCode not in sys.path:
      sys.path.insert(1,pythonCode)
try:
    pythonCode = os.environ['PYTHONCODE']
except:
    pass
if len(sys.argv) >1:
   if sys.argv[-1]== '@':
      pythonCode = sys.argv[-2]
      sys.argv.pop()
      sys.argv.pop()
# check for userCode
usercodepy = ''
if 'USERCODEPY' in os.environ: 
   usercodepy = os.environ['USERCODEPY']
   while usercodepy[-1]=='\\':
         usercodepy = usercodepy[0:-1]
   if os.path.isdir(usercodepy):
      if usercodepy not in sys.path:
         sys.path.append(usercodepy)
if not pythonCode and usercodepy:
   pythonCode = usercodepy
print('pythonCode=',pythonCode)
while pythonCode[-1]=='\\':
      pythonCode = pythonCode[0:-1]
if os.path.isdir(pythonCode):
   if pythonCode not in sys.path:
      sys.path.insert(1,pythonCode)

#for x in sys.path: print x
if debug:
   print ('usercodepy:',usercodepy)
   print ('pythonCode:',pythonCode)
   #list environ vars
   print('----ENVIRON LIST----')
   for env in os.environ:
       print ('%s=%s'%(env,os.environ[env]))
   print ('----END OF ENVIRON LIST----')
# ======================================================================
import JCtools

if not JCtools.run_from_dos:
   errtxt = '''\n WRONG usage.  This CHANNELS tool only runs outside PSSe GUI. Program will exit.
   
   Readme.txt provides additional help information.
   To run outside PSSe GUI, open a command prompt 
   (preferably using the link created by PSSe, i.e.: "PSSE 33 Command Prompt")
   move to the working directory and then to
   run a test using channels.bat with chan_Pe_plt.ini as argument:
    c:\..>channels chan_Pe_plt
   '''
   print (errtxt)
   quit()
#______________________________________________________________
def PDFmergerpxp(pdf_files,destination):
    from PyPDF2 import PdfReader, PdfFileWriter
    outpdf_obj = PdfFileWriter()
    for filename in pdf_files:
        inpdf_obj = PdfReader(file(filename,"rb"))
        [outpdf_obj.addPage(inpdf_obj.getPage(page_num)) for page_num in range(inpdf_obj.numPages)]
    outpdf_obj.write(file(destination,"wb"))

def PDFmerger(pdf_files,destination):
    '''usage:
        pdf_files = ['angle.pdf','speed.pdf']
        destination= "combined.pdf"
        PDFmergerpxp(pdf_files,destination)
    '''
    pyver = JCtools.pyver()
    ok = 1
    try:
       if pyver < 30:
        from PyPDF2 import PdfFileReader as PdfReader
        from PyPDF2 import PdfFileMerger as PdfMerger
       else:
        from PyPDF2 import PdfReader, PdfMerger
    #except ModuleNotFoundError:
    except:
        print('WARNING - Modules not loaded PdfReader, PdfMerger')
        return ok
    merger = PdfMerger()
    for filename in pdf_files:
        if os.path.isfile(filename):
           merger.append(PdfReader(filename, "rb"))
    try:
        merger.write(destination)
        merger.close()
        ok = 0
    except: ok = 1
    return ok
#______________________________________________________________
def columnlst(c,array2d):
    # c: column id, 0, 1,..
    lst = []
    for row in array2d:
        if row[c] not in lst:
           lst.append(row[c])
    return lst
        
def PSSe_extendedname(str):
    '''
    str = '[namekv]'
    where kv takes 6 chars & name can contain spaces
    '''
    name = ''
    kv   = 0.0
    str2 = str[1:-1]          #'deletes' brackets
    name = str2[:-6]
    kv   = float(str2[-6:])
    return name, kv
#______________________________________________________________
def About(version):
    About_txt = '''
_____________________________________
| channels                v.%s |
| Developed by Jose Conto            |          
| ERCOT System Planning staff        |                    
|                                    |
| This code is from the author's     |
| PSS/e python power system library. |
--------------------------------------                                      
'''%version
    return About_txt

def info(version):
    Help_txt = '''
_________________________________________
 channels                    v.%s

 It processes activities on channels
 as specified on input:
 info, export, plot, compare, index,
 vfunc, modal
 
 Input:
   Select a *.ini file
   or use GUI

 Out: plots or channels data

 Copyright Jose Conto, June 2017
 All rights reserved.
_________________________________________
'''%version
    return Help_txt

def filechoose(filename,wildcardstr = "All files (*.*)|*.*"):
    # allows multiple file selections as well.
    dlg = wx.FileDialog(None,
                        message="Choose a file",
                        defaultDir =os.getcwd(),
                        defaultFile=filename,
                        wildcard   =wildcardstr,
                        style=wx.OPEN | wx.MULTIPLE | wx.CHANGE_DIR)
    # Show the dialog and retrieve the user response.
    selectedFile = filename
    if dlg.ShowModal() == wx.ID_OK:
       selectedFile = dlg.GetPaths()[0]
       selectedFile = os.path.basename(selectedFile)
        #print('selectedFile=',selectedFile)
    # Destroy the dialog. Don't do this until you are done with it!
    dlg.Destroy()
    return selectedFile

#______________________________________________________________
#_____ GUI __________________
#______________________________________________________________
class MyFrame(wx.Frame):
    def __init__(self, *args, **kwds):
        kwds["style"] = wx.DEFAULT_FRAME_STYLE
        wx.Frame.__init__(self, *args, **kwds)
        # Menu Bar
        #self.menubar = wx.MenuBar()
        #menu = wx.Menu()
        #menu.Append(wx.NewId(), "AZO update", "", wx.ITEM_NORMAL)
        #menu.Append(wx.NewId(), "AZO copy"  , "", wx.ITEM_NORMAL)
        #menu.Append(wx.NewId(), "Neighbor"  , "", wx.ITEM_NORMAL)
        #menu.Append(wx.NewId(), "Quit"      , "", wx.ITEM_NORMAL)
        #self.menubar.Append(menu, "AZO")
        #self.SetMenuBar(self.menubar)
        # Menu Bar end

        self.nb1    = wx.Notebook(self, -1, style=0)
        self.nb1_p1 = wx.Panel(self.nb1, -1)
        self.nb1_p2 = wx.Panel(self.nb1, -1)
        self.nb1_p3 = wx.Panel(self.nb1, -1)
        
        self.nb1.AddPage(self.nb1_p1, "channels")
        self.nb1.AddPage(self.nb1_p2, "subsystem")
        self.nb1.AddPage(self.nb1_p3, "Help")
        
        self.__p1_layout()       
        self.__p2_layout()       
        self.__p3_layout()       


        self.SetTitle("channels tools")
        self.Notebook_statusbar = self.CreateStatusBar(2, 0)
        self.Notebook_statusbar.SetStatusWidths([-1, -1])
        Notebook_statusbar_fields = ["Welcome!", "Options"]
        for i in range(len(Notebook_statusbar_fields)):
            self.Notebook_statusbar.SetStatusText(Notebook_statusbar_fields[i], i)

    def __p1_layout(self):
        Xpos = 10
        Ypos = 10
        self.p1guivarinitvalue()
        self.p1label0 = wx.StaticText(self.nb1_p1, -1, 'channels', (Xpos+10,Ypos+10), (166, 35))
        self.p1label0.SetFont(wx.Font(20, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
  
        self.p1combox_list = ['INI','EXPORT','INFO']
        self.p1combox = wx.ComboBox(self.nb1_p1, -1, 'mach', (Xpos+190,Ypos+10), (121, 39), self.p1combox_list)
        self.p1combox.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p1combox.SetFont(wx.Font(20, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p1combox.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
 
        self.p1label1 = wx.StaticText(self.nb1_p1, -1, 'ini file', (Xpos+15,Ypos+100), (100, 29))
        self.p1txtbox1= wx.TextCtrl(self.nb1_p1, -1, '*.ini', (Xpos+120,Ypos+100), size=(230, 20))
        self.p1txtbox1.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p1txtbox1.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p1txtbox1.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        self.p1button1 = wx.Button(self.nb1_p1, -1, '...', (Xpos+365,Ypos+100), (30, 20))
        self.p1button1.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p1button1.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
 
        self.p1label2 = wx.StaticText(self.nb1_p1, -1, 'sav file', (Xpos+15,Ypos+150), (100, 29))
        self.p1txtbox2= wx.TextCtrl(self.nb1_p1, -1, '*.sav', (Xpos+120,Ypos+150), size=(230, 20))
        self.p1txtbox2.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p1txtbox2.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p1txtbox2.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        self.p1button2 = wx.Button(self.nb1_p1, -1, '...', (Xpos+365,Ypos+150), (30, 20))
        self.p1button2.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p1button2.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
  
        self.p1debug = wx.CheckBox( self.nb1_p1, -1, 'debug',  (Xpos+345,Ypos+200), (84, 21))
        self.p1debug.SetValue(False)
  
        self.p1button3 = wx.Button(self.nb1_p1, -1, 'Quit', (Xpos+60,Ypos+260), (110, 41))
        self.p1button3.SetFont(wx.Font(16, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
  
        self.p1button4 = wx.Button(self.nb1_p1, -1, 'RUN', (Xpos+250,Ypos+260), (110, 41))
        self.p1button4.SetFont(wx.Font(16, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
  
        self.p1progressbar = wx.Gauge(self.nb1_p1, -1, 100, (Xpos+10,Ypos+320), (381, 23))
        self.p1progressbar.SetValue(0)
  
        self.Bind(wx.EVT_BUTTON, self.p1OnFileSelect1,id=self.p1button1.GetId())
        self.Bind(wx.EVT_BUTTON, self.p1OnFileSelect2,id=self.p1button2.GetId())
        self.Bind(wx.EVT_BUTTON, self.p1OnQuit,       id=self.p1button3.GetId())
        self.Bind(wx.EVT_BUTTON, self.p1OnRun,        id=self.p1button4.GetId())

        self.p1guivarsetvalue()

    ############################################################################################
    def p1OnFileSelect1(self, event):
        global My
        wildcard = "INI files (*.ini)|*.ini|"  \
                   "All files (*.*)|*.*"
        My['INIFILE'] = filechoose(' ',wildcard)
        self.p1txtbox1.SetValue(My['INIFILE']) 

    def p1OnFileSelect2(self, event):
        global My
        wildcard = "SAV files (*.sav)|*.sav|"  \
                   "All files (*.*)|*.*"
        My['SAVFILE'] = filechoose(' ',wildcard)
        self.p1txtbox2.SetValue(My['SAVFILE'])

    def p1guivargetvalue(self):
        global My
        My['DATATYPE']= self.p1combox.GetValue()
        My['INIFILE'] = self.p1txtbox1.GetValue()
        My['SAVFILE'] = self.p1txtbox2.GetValue()
        My['DEBUG']   = self.p1debug.GetValue()

    def p1guiprintvalues(self):
        global My
        print ("My['DATATYPE']=",My['DATATYPE'])   
        print ("My['INIFILE'] =",My['INIFILE'])
        print ("My['SAVFILE'] =",My['SAVFILE'])   
        print ("My['DEBUG']   =",My['DEBUG'])   
       
    def p1guivarsetvalue(self):
        global My
        self.p1txtbox1.SetValue(My['INIFILE']) 
        self.p1txtbox2.SetValue(My['SAVFILE']) 
        self.p1debug.SetValue(My['DEBUG'])
            
    def p1guivarinitvalue(self):
        global My
        My['INIFILE'] = '*.ini'
        My['SAVFILE'] = '*.sav'
        My['DEBUG']   = False     # no debug messages
    
    def p1OnRun(self, event):
        global My
        self.p1guivargetvalue()
        self.p2guivargetvalue()
        self.p2guistr2value()
        if My['DEBUG']:
           self.p1guiprintvalues()
           self.p2guiprintvalues()
        result = channelsmain()
        if result:
           message = 'File %s was created!' % result
           dlg = wx.MessageDialog(self, message)
           dlg.ShowModal()
        event.Skip()

    def p1OnQuit(self, event):
        self.OnQuit()
#____________________________________________________________________________  
    def __p2_layout(self):       
        X0 = 10
        Y0 = 10
        Xpos = X0 + 10
        Ypos = Y0 + 10
        self.p2label0 = wx.StaticText(self.nb1_p2, -1, 'subsystem', (Xpos,Ypos), (175, 35))
        self.p2label0.SetFont(wx.Font(20, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        Xpos = X0 + 50
        Ypos = Y0 + 50
        self.p2label1 = wx.StaticText(self.nb1_p2, -1, 'sid', (X0+15,Ypos), (80, 29))
        self.p2txtbox1= wx.TextCtrl(self.nb1_p2, -1, '-1', (X0+100,Ypos), size=(30, 20))
        self.p2txtbox1.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox1.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox1.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        Xpos = X0 + 100
        Ypos = Y0 + 100
        self.p2label2 = wx.StaticText(self.nb1_p2, -1, 'base kv', (X0+15,Ypos), (80, 29))
        self.p2txtbox2= wx.TextCtrl(self.nb1_p2, -1, '', (X0+100,Ypos), size=(250, 20))
        self.p2txtbox2.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox2.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox2.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        Xpos = X0 + 150
        Ypos = Y0 + 150
        self.p2label3 = wx.StaticText(self.nb1_p2, -1, 'areas', (X0+15,Ypos), (80, 29))
        self.p2txtbox3= wx.TextCtrl(self.nb1_p2, -1, '', (X0+100,Ypos), size=(250, 20))
        self.p2txtbox3.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox3.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox3.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        Xpos = X0 + 200
        Ypos = Y0 + 200
        self.p2label4 = wx.StaticText(self.nb1_p2, -1, 'buses', (X0+15,Ypos), (80, 29))
        self.p2txtbox4= wx.TextCtrl(self.nb1_p2, -1, '', (X0+100,Ypos), size=(250, 20))
        self.p2txtbox4.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox4.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox4.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        Xpos = X0 + 250
        Ypos = Y0 + 250
        self.p2label5 = wx.StaticText(self.nb1_p2, -1, 'owners', (X0+15,Ypos), (80, 29))
        self.p2txtbox5= wx.TextCtrl(self.nb1_p2, -1, '', (X0+100,Ypos), size=(250, 20))
        self.p2txtbox5.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox5.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox5.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
        Xpos = X0 + 300
        Ypos = Y0 + 300
        self.p2label6 = wx.StaticText(self.nb1_p2, -1, 'zones', (X0+15,Ypos), (80, 29))
        self.p2txtbox6= wx.TextCtrl(self.nb1_p2, -1, '', (X0+100,Ypos), size=(250, 20))
        self.p2txtbox6.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p2txtbox6.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p2txtbox6.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))

#____________________________________________________________________________  
    def p2guivargetvalue(self):
        global My
        My['S_SID']   = self.p2txtbox1.GetValue()
        My['S_BASEKV']= self.p2txtbox2.GetValue()
        My['S_AREAS'] = self.p2txtbox3.GetValue()
        My['S_BUSES'] = self.p2txtbox4.GetValue()
        My['S_OWNERS']= self.p2txtbox5.GetValue()
        My['S_ZONES'] = self.p2txtbox6.GetValue()
       
    def p2guivarsetvalue(self):
        global My
        self.p2txtbox1.SetValue(My['S_SID']) 
        self.p2txtbox2.SetValue(My['S_BASEKV'])
        self.p2txtbox3.SetValue(My['S_AREAS'])
        self.p2txtbox4.SetValue(My['S_BUSES'])
        self.p2txtbox5.SetValue(My['S_OWNERS'])
        self.p2txtbox6.SetValue(My['S_ZONES'])

    def p2guivarinitvalue(self):
        global My
        My['S_SID']   = '-1'
        My['S_BASEKV']= ''
        My['S_AREAS'] = ''
        My['S_BUSES'] = ''
        My['S_OWNERS']= ''
        My['S_ZONES'] = ''

    def p2guistr2value(self):
        global My
        My['SID']   = int(My['S_SID'])
        #mList = [int(e) if e.isdigit() else e for e in mStr.split(',')]
        if My['S_BASEKV']:
           My['BASEKV']= [float(e) if e.isdigit() else e for e in My['S_BASEKV'].split(',')]
        else:
           My['BASEKV']= []
        if My['S_AREAS']:
           My['AREAS'] = [int(e) if e.isdigit() else e for e in My['S_AREAS'].split(',')]
        else:
           My['AREAS']= []
        if My['S_BUSES']:
           My['BUSES'] = [int(e) if e.isdigit() else e for e in My['S_BUSES'].split(',')]
        else:
           My['BUSES']= []
        if My['S_OWNERS']:
           My['OWNERS']= [int(e) if e.isdigit() else e for e in My['S_OWNERS'].split(',')]
        else:
           My['OWNERS']= []
        if My['S_ZONES']:
           My['ZONES'] = [int(e) if e.isdigit() else e for e in My['S_ZONES'].split(',')]        
        else:
           My['ZONES']= []
        
    def p2guivalue2str(self):
        global My
        My['S_SID']   = str(My['SID'])
        My['S_BASEKV']= ','.join(str(i) for i in My['BASEKV'])
        My['S_AREAS'] = ','.join(str(i) for i in My['AREAS'])
        My['S_BUSES'] = ','.join(str(i) for i in My['BUSES'])
        My['S_OWNERS']= ','.join(str(i) for i in My['OWNERS'])
        My['S_ZONES'] = ','.join(str(i) for i in My['ZONES'])    

    def p2guiprintvalues(self):
        global My
        print ("My['SID']   =",My['SID'])
        print ("My['BASEKV']=",My['BASEKV'])
        print ("My['AREAS'] =",My['AREAS'])
        print ("My['BUSES'] =",My['BUSES'])
        print ("My['OWNERS']=",My['OWNERS'])
        print ("My['ZONES'] =",My['ZONES'] )            
#____________________________________________________________________________  
    def __p3_layout(self):       
        global My
        X0 = 10
        Y0 = 10
        Xpos = X0 + 10
        Ypos = Y0 + 10
        self.p3label0 = wx.StaticText(self.nb1_p3, -1, 'HELP', (Xpos,Ypos), (175, 35))
        self.p3label0.SetFont(wx.Font(20, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        Xpos = X0 + 50
        Ypos = Y0 + 50
        help_txt = info(My['PRGVERSION'])
        self.p3txtbox1= wx.TextCtrl(self.nb1_p3, -1,
                                    help_txt,
                                    (X0+10,Ypos),
                                    size=(300,300),
                                    style=wx.TE_MULTILINE | wx.TE_READONLY)
        self.p3txtbox1.SetBackgroundColour(wx.Colour(255, 255, 255))
        self.p3txtbox1.SetFont(wx.Font(8.25, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL, 0, 'Microsoft Sans Serif'))
        self.p3txtbox1.SetCursor(wx.Cursor(wx.CURSOR_DEFAULT))
      
#____________________________________________________________________________  
    #common functions ####################################################################################
    def OnQuit(self):
        self.Close()
#______________________________________________________________
#_____ end of GUI class MyFrame  __________________
#______________________________________________________________
#_______________________________________________________________________
#___ Functions 
#_______________________________________________________________________
#_______________________________________________________________________
#_______________________________________________________________________
#______________________________________________________________
def INIsample():
    ini = """
/// begin INIsample
/chan_Pe_dmp.ini - 4 channels.py
[study]
ACTIVITY  = DAMPING         // PLOT, EXPORT, COMPARE, INDEX, INFO, DAMPING
program   = channels.py
studyname = Pe 
studytype = 
debug = 0
//logfile = chan_plt_Pe.log
logopen = w
//savfile = CASEs\\savnw.sav          //together with areamask or zonemask

[OUTfiles]
outvrsn = 0     /1 for OUTX format, 0 for (old) OUT format
//outlst = outs\\*GO*.out              /filename include "GO"
outlst = outs\\*.out     /wild card accepted, include path
//outlst = outs\\savnw_faults_*.out     /wild card accepted, include path
//outlst = ['outs\\abc.outx']                     /if entered, overwrites "outfile" 

[channels]
//channels= 9:11
//channels= [59,]         /f & V at Downtown bus
chanMask = POWR                      //ANGL, VOLT, POWR, VARS, FREQ, QLOd...
//chanMask = ['POWR','VARS']         //ANGL, VOLT, POWR, VARS, FREQ, QLOd...
chantypeid = 2                       //1:bus, 2:gen, load, 3:system, 4:branch
//KVmask   = [230,500.0]
//Areamask = [1,2]                    //select channels in AREA(s) given. SAV case required.
//Zonemask = [5]                      //select channels in ZONE(s) given. SAV case required.
//Chanexcl = ['W','S','F','E','N','C','P']             /first letter of ID
//Chanexcl = ['W','S','F','E']             /first letter of ID
//chanbus = [8335,8348]               // valid if channels by type, like = ANGL
chan_fx  = 100.0 * A                //scale POWR, VARS function
//Chan_fx  = 60.0 * (1 + A)           //scale FREQ function
//Chan_fx  = 1 + A                    //scale SPD function
//Chan_fx  = pu                       //scales to p.u. values, relative to value at t=0

[plot]
//plotpath = PLOTs\
plotshow  = True        //True or False, flag to 'see' on screen plots
chansperplot = 2
pltrows = 3
pltcols = 1
grid    = 1
marker  = 0
plotstudyfile= studyname_studytype_activity.pdf                     //one pdf per study
plotsubfile  = outlsti.pdf            //one pdf per loop
pagetitle = studyname outlsti
//pagetitle = '''
//                Summer Peak Conditions - study, fontsize=20
//            '''
title  = test
//ylabel = Volt (p.u.)        
//yscale = [0.5,1.5]            /default to PSSe proposed scale
//xlabel =                      /defalt to Times(s) for OUT files        
//xscale = [0.0,5.0]              /bypass for all x-points
//xaxis  = log                  /x-axis in log(x)
//flatlines= [[(0.0,1.1),(5.0,1.1)]]
//xyprofile= [[(1.15,0.0),(2.75,0.9),(5.0,0.9)]]  //LVRT =[[List of (Xi,Yi)],...] = n-points [[X1,Y1],..
linestyle= solid                / 'solid', 'dashed', 'dashdot', 'dotted'
/linecolors= "blue, red, black, green, magenta, darkblue, beige"
             //'blue', 'red', 'black', 'green', 'magenta', 'darkblue', 'beige',
             //'brown', 'gray', 'khaki', 'pink', 'purple', 'royalblue', 'violet' ,'cyan', 'yellow',
legend = '''
                      chanIDi,position= 4,fontsize= 7
                 '''
            //legendpos= outbelow, outright or
            //best: 0, upper right: 1, upper left: 2,lower left: 3, lower right: 4, right: 5, 
            //center left: 6, center right: 7, lower center: 8, upper center: 9, center: 10
                        //legendsize= 7           //font size
[Index]
doplot = 1
//doexport= 0
idxformat= CSV        // XLS= default
/Time_begin = 1.0       //time_begin & time_end defines a time interval for plot data processing
/Time_end   = 5.0
/Time_lastpct= 30
limitype   = 2          //1: abs, 2:delta, 3:percentage, 4:abs of final value, 5:peaktopeak deviation
/Ylowlimit  = -2        //triggers curve selection
/Yhighlimit = 170
/Yvalue_ref = 1.0        //default to first point value
/Tdelta_ref = 0.5        //sec - Valid if Yvalue_ref not given. Set Yvalue_ref = y(Tdelta_ref) 
                         //Enter -1 to make Yvalue_ref = Last point value
zerovtol = 0.01
trippedBus_inc= False   //default= True - set to False to exclude chans of tripped buses (V[-1]==0)
//chanminval = 4          //select top 2 channels with lowest value 
//chanmaxval = 4          //select top 3 channels with higest value
  [UVDR] Under Value Delay Recovery
//UVDR    = 0.9         // p.u. of Yvalue_ref
//UVDRtime= 2.0         // sec
  [OVDR] Over Value Delay Recovery 
//OVDR    = 1.05        //p.u. of Yvalue_ref
//OVDRtime= 1.0         // sec

[damping]
dampingpct   = 15.0      /damping threshold in pct, modes with larger damoing are ignored
//Time_begin = 2.0         //time_begin & time_end defines a time interval for data analysis
//Time_end   = 10.0      // or enter:
Time_lastpct= 50         // tail period, in pct.
dmpminpts    = 10        /if signal has less pts, skip
oscthreshold = 0.015     /if signal damping is lower, possible sustained oscillations
chandevpct   = 1         /if greater, the signal is used for further damping check
chandeltaval = 0.01      /step-size to detect peak value relative to its left
svd_thresh = 0.005       //original = 0.025
num_iter   = 10
oscAmin    = 0.05        //min Amplitude of oscillation, in p.u. of Yref
reconstruct= True        //to plot Orig + Calc traces
pooldelay  = 2
cpu = 2
[Headers]
//headerLimit  = ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','INDEX', 'DEVIATION','FINAL','MIN','MAX']
//headerUVOVDR = ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','INDEX', 'Tstart', 'Tend','threshold','Trecovery']
//headerDamping= ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','Damping','Threshold','Freq','Note']
headerDamping= Source,Signal,frequency(Hz),Damping(%)
sortkey = 7

[INFO]                //1=yes, 0=no
showChannelID         = 1
showChannelRange      = 0
showChannelScale      = 0
showChannelPrintScale = 0          //ID + Range + Scale at once
showChannelData       = 0          // not recommended, use EXPORT

[EXPORT]
//exp2txt  = scenario        /study, studyi
exp2xls  = scenario        / works only with v.33

[psse]
BusDim     = 150000
//PsseVersion= 33
psspyPath  = C:\Program Files (x86)\PTI\PSSE33\PSSBIN

[info]
/default values are in brackets
/comments start with or from /
/in-line comments are stripped before reading keyword value
/path ending with '\' is required
/emptry string set to ='' is read as to have two chars of '
/run as:
/runpy voltplot                    <- default to voltplot.ini
/runpy channels chan_plt_V[.ini]                    <- default to channels.ini
/Additional internal vars:
/study  = studyname_studytype
/studyi = studyname_studytype_outlsti_chani
/outlsti= out file i-th being processed
/chani  = channels i-th being processed
/// end   INIsample
    """
    return ini

# =============================================================================================
def initialize(My):
    #default vars:
    My['HEADERSTATS']  = ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','BEGIN','TBEGIN','MIN','TMIN','MAX','TMAX','FINAL','TFINAL','RISETIME','OVERSHOOT','SETTLINGTIME']
    My['HEADERLIMIT']  = ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','INDEX', 'DEVIATION','MIN','TMIN','MAX','TMAX','FINAL','TFINAL']
    My['HEADERUVOVDR'] = ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','INDEX', 'Tstart', 'Tend','threshold','Trecovery']
    My['HEADERDAMPING']= ['OUTFILE','CHANNEL','BUS','BNAME','KV','ID','VIOLATION','Damping','Threshold','Freq','Note']
     #print(' in Initialize', My)
     #print(sys.argv)
    # add user's code folder
    inifile = My['INIFILE']
    err, My = JCtools.readIni(inifile,My)
    if not err:
       My['HEADERLIMIT_IN']    = False 
       My['HEADERUVOVDR_IN']   = False
       My['HEADERDAMPING_IN']  = False
       if 'DEBUG' not in My:
          My['DEBUG'] = False
       study = JCtools.getStudy(My)
       My['STUDY'] = study
       My['PMU'] = False
       if 'PMUFILES' in My:
          for pmufile in My['PMUFILES']:
               #print('pmufile=%s-'%pmufile)
              if os.path.isfile(pmufile):
                 My['PMU'] = True
                 break
             
       if 'ZEROVTOL' not in My: 
          My['ZEROVTOL']= 0.01
       if 'PLTROWS' not in My: 
          My['PLTROWS']= 1
       if 'PLTCOLS' not in My: 
          My['PLTCOLS']= 1
       if 'CHANSPERPLOT' not in My: 
          My['CHANSPERPLOT']= 1
       else:
           #print('init CHANSPERPLOT:%s_'%(My['CHANSPERPLOT']))
          if JCtools.WhatType(My['CHANSPERPLOT'])=='STRING':
             if My['CHANSPERPLOT'].upper()=='ALLCHANNELS':
                My['LEGEND'] = None
                My['PLTROWS']= 1
                My['PLTCOLS']= 1
       My['PLOTSPERPAGE'] = My['PLTROWS']*My['PLTCOLS']
       if   My['PLOTSPERPAGE']== 1:    # 1 x 1 plot
            My['PLOTYPE'] = '1x1'
       elif My['PLTCOLS']==1:  # n x 1 plot
            My['PLOTYPE'] = 'nx1'
       elif My['PLTROWS']==1:  # 1 x n plot  - not implemented
            My['PLOTYPE'] = '1xn'
       else: #n x m plot
            My['PLOTYPE'] = 'nxm'
       if 'FIGSIZE' not in My:
          if My['PLTROWS']>My['PLTCOLS']:
             My['FIGSIZE'] = (8, 11)
          else:
             My['FIGSIZE'] = (11, 8)
          if 'PDFORIENTATION' in My:     # PORTRAIT or LANDSCAPE
             if My['PDFORIENTATION'].upper()=='PORTRAIT':
                My['FIGSIZE'] = (8, 11)
       if 'LEGEND' in My and My['LEGEND']:
          My['LEGENDSTR'],My['LEGENDPOS'],My['LEGENDSIZE']= legend_parse(My)
       if 'PLOTPATH' in My and My['PLOTPATH']:
          if not os.path.isdir(My['PLOTPATH']):
             os.mkdir(My['PLOTPATH'])
       if My['DEBUG']:
          print('_'*35+'\n+ sys.argv +')
          for x in sys.argv: print (x)
          print('0 inifile:%s'%inifile)
          print('_'*35+'\n')    
          for key, value in My.items():
              print('%s = %s'%(key, value))
    else:
       print('\n**ERROR %s - Bad ini file %s. Program quits.\n' %(err,inifile))
       print(INIsample())
       
    return err, My

# =============================================================================================
def timeintervals(timelst,tinterval):
    tstart = tinterval[0]
    tend = tinterval[1]
    startd = -1
    endd   = -1    
    for t in range(len(timelst)):
        if startd == -1:
           if timelst[t]>tstart: startd = t
        if endd == -1:
           if timelst[t]>=tend: endd = t
    if endd == -1: endd = len(timelst)
    return startd,endd
# =============================================================================================
def getchanvals(chanData,chanid):
    return chanData[chanid]
    
def chanvals_npa(chanData,chanid):
    import numpy as np
    #print (' chanData.keys:',chanData.keys())
    return np.array(chanData[chanid])
    
# =============================================================================================
def My2filename(targetfn,prefix=None,suffix=None):
    # targetfn = 'folder\studyname_studytype_outlsti_chanmask.pdf'
    # output = My-replaced
    global My
    
    if 'DEBUG' in My:
        debug = My['DEBUG']
    #debug = True
    fileiDic = JCtools.fnameDic(targetfn)         
    filei = fileiDic['ROOT']
    separchar = '_'
    if separchar in filei:
       fileilst = filei.split(separchar)
    else:
       fileilst = filei.split() #split on space
       separchar= ' '
    if debug:
       print ('My2filename')
       print ('INPUT fileilst:%s'%fileilst)
       print ('study:%s'%My['STUDY'])
    for k in range(len(fileilst)):
        keyword = fileilst[k].upper()
        if debug:
           print ('keyword:',keyword)
        if keyword in My:
           Mykeyword = str(My[keyword])
           if os.path.isfile(Mykeyword):
              fDic = JCtools.fnameDic(Mykeyword)
              fileilst[k] = fDic['ROOT']  #strip its PATH & EXT
           else:
              fileilst[k] = Mykeyword
           if debug:
              print ('fileilst[k]:',fileilst[k])
        else:
           if debug:
              print ('keyword %s NOT in My'%keyword)
    filename = separchar.join([str(i) for i in filter(None, fileilst)])
    filename = separchar.join([str(i) for i in filter(None, [prefix,filename,suffix])])
    filename = filename.replace('[','')
    filename = filename.replace(']','')
    if debug:
       print ('OUTPUT fileilst:%s'%fileilst)
       print (fileiDic['PATH'] + filename + fileiDic['EXT'])
    return fileiDic['PATH']+filename+fileiDic['EXT']
# =============================================================================================
def My2str(targetstr,prefix=None,suffix=None):
    # targetfn = 'folder\studyname_studytype_outlsti_chanmask.pdf'
    # output = My-replaced
    global My

    if 'DEBUG' in My:
        debug = My['DEBUG']
        if debug == True:
           debug = 1
    if '_' in targetstr:
       separchar = '_'
       keywordlst = targetstr.split(separchar)
    elif ',' in targetstr:
       separchar = ','
       keywordlst = targetstr.split(separchar)
    else:
       separchar = ' ' 
       keywordlst= targetstr.split() #split on space
    if debug>1:
       print ('My2str - keywordlst=', keywordlst)
    for k in range(len(keywordlst)):
        keyword = keywordlst[k].upper()
        if keyword in My:
           Mykeyword = str(My[keyword])
           if JCtools.WhatType(My[keyword])=="LIST":
              keywordlst[k] = '_'.join(str(si) for si in My[keyword])
           else:
              if os.path.isfile(Mykeyword):
                 fDic = JCtools.fnameDic(Mykeyword)
                 if My['ACTIVITY'] == 'COMPARE':
                    keywordlst[k] = fDic['ROOT'] #base name only
                 else:
                    keywordlst[k] = fDic['ROOT']+fDic['EXT'] #strip its PATH
              else:
                 keywordlst[k] = Mykeyword

    if debug>1:
       print ('My2str - keywordlst=', keywordlst)
    resultstr = separchar.join([str(i) for i in filter(None, keywordlst)])
    resultstr = separchar.join([str(i) for i in filter(None, [prefix,resultstr,suffix])])
    if debug: 
       print ('My2str in:%s, resultstr:%s'%(targetstr,resultstr))
    return resultstr
# =============================================================================================
def fnameroot(xfile):
    rootfn = os.path.basename(xfile)
    root, ext = os.path.splitext(rootfn)
    return root
# =============================================================================================   
def OUTfiles_select(My):
    outfiles = []
    temp = My['OUTLST']
    if isinstance(temp, list):
       if My['DEBUG']:
          print ('outlst:%s files'%len(temp))
          for xf in temp: print (xf)
       if len(temp)>1:      #=['file1.out','file*abc.out'..]
           for xfile in temp:
               #print ('xfile:',xfile)
               if os.path.isfile(xfile):
                   outfiles.append(xfile)
               else:
                   xpath,xbase = os.path.split(xfile)
                   outfiles += JCtools.find_files(xbase,xpath)
       else:
          if os.path.isfile(temp[0]):   #single file name like abc.out in list
             outfiles = temp
          else:
             xpath,xbase = os.path.split(temp[0])
             outfiles = JCtools.find_files(xbase,xpath)                      
    else:       # single str like savnw_flat32_*.out or *abc*.out
       if My['DEBUG']:
          print ('outlst:%s'%temp)
       if os.path.isfile(temp):   #single file name like abc.out
          outfiles.append(temp)
       else:
          xpath,xbase = os.path.split(temp)
          outfiles = JCtools.find_files(xbase,xpath)         
    if My['DEBUG']: print (outfiles)
    return outfiles

# =============================================================================================
def pltfuncPU(vectin):
    if abs(vectin[0]) < 1e-09:
       return 1,vectin
    vectout = []
    for k in range(len(vectin)):
        vectout.append(vectin[k]/vectin[0])
    return 0,vectout

def pltfunc(vectin,chani):
    global My
    if 'CHAN_FX' in My:
       if My['CHAN_FX'].upper()== 'PU':
          ier, z = pltfuncPU(vectin)
          if ier:
             print (' Chan %s - signal conversion to p.u. not allowed, ref val -> zero!'%chani)          
       else:
           z = []
           for yi in vectin:
               fx_str = My['CHAN_FX'].replace('A',str(yi))
               try:
                 zi = eval(fx_str)
               except:
                 zi = yi
               z.append(zi)
    else:
       z = vectin
    return z

def pltfuncPU_npa(vectin):
    #vectin is a numpy array
    if abs(vectin[0]) < 1e-09:
       return 1,vectin
    minval = min(vectin)
    if minval < 0.0:
       #shiht up by minval
       newvectin = vectin + abs(minval)
    else:
       newvectin = vectin
    newbase  = newvectin[0]
    return 0, newvectin/newbase

def pltfunc_npa(vectin):
    global My
    import numpy as np
    npvec = vectin
    if 'CHAN_FX' in My:
       if My['CHAN_FX'].upper()== 'PU':
          ier, z = pltfuncPU_npa(vectin)
          if ier:
             if 'CHANI' in My:
                print(' Chan %s - signal conversion to p.u. not allowed, ref val -> zero!'%My['CHANI'])
             else:
                print (' Signal conversion to p.u. not allowed, ref val -> zero!')
       else:
           z = []
           for yi in vectin:
               fx_str = My['CHAN_FX'].replace('A',str(yi))
               try:
                 zi = eval(fx_str)
               except:
                 zi = yi
               z.append(zi)
       npvec = np.array(z)
    elif 'CHANBUS' in My and My['CHANBUS']:
       #print(My['OUTLSTI'],'-', My['CHANMASKI'], My['CHANTYPEID'])
       if   My['CHANMASKI']=='POWR':
            if 'CHANTYPEID' in My and My['CHANTYPEID']==2:
               npvec = vectin * 100.0
               #print(My['OUTLSTI'],'-', My['CHANMASKI'], ' chan & chani:',My['CHANI'], My['CHANIDI'])
       elif My['CHANMASKI']=='VARS':
            if 'CHANTYPEID' in My and My['CHANTYPEID']==2:
               npvec = vectin * 100.0
               #print(My['OUTLSTI'],'-', My['CHANMASKI'], ' chan & chani:',My['CHANI'], My['CHANIDI'])
       elif My['CHANMASKI']=='FREQ':
            npvec = (1.0+vectin) * 60.0
       elif My['CHANMASKI']=='SPD':
            npvec = 1.0 + vectin    # Mach Speed in p.u. of Nominal speed

    return npvec
   
# =============================================================================================
def getchanidlst(chanidstr):
    ''' It return list with channel attributes.
        in  chanidstr = 'FREQ 44000 [W_A_P___345A345.00]'
        out chanidlst =['FREQ',44000,'W_A_P___345A',345.0,1]
                                                          |_chanidtype
        in  chanidstr = 'FREQ 44000 [W_A_P___345A345.00]S1' 
        out chanidlst =['FREQ',44000,'W_A_P___345A',345.0,'S1',2]
                                                               |_chanidtype
        in  chanidstr = 'PE-PL AREA 2016 [VALLEY ]'
        out chanidlst =['PE-PL', 'AREA', 2016, 'VALLEY',3]
        
        in  chanidstr = 'POWR 1695 TO 5925 CKT '1 '
        out chanidlst =['POWR', 1695, 5925, '1',4]
        
        chanidtype:
        0: Unknown!
        1: BUS CHANNEL
        2: Gen channel    (if POWR, values are in pu of 100)
        3: Region channel
        4: Branch channel (if POWR, values are True MW)
    '''   
    #print ('getchanidlst:')
    #print ('in %s'%chanidstr)
    chanidlst = []
    bname = ''
    kvstr = '0.0'
    chanidtype = 0                #type 0 = unknown
    if not '[' in chanidstr:      #chanidtype = 4
       if 'TO' in chanidstr and 'CKT' in chanidstr:    #type 4
          tmp4 = chanidstr.split()
          chanidtype = 4
    else:
       busnamekv = JCtools.betweenchars(chanidstr,'[',']')
       if busnamekv:
          if len(busnamekv)>5:
             kvstr = busnamekv[-6:]
             if JCtools.IsFloat(kvstr): 
                bname = busnamekv[:-6].strip()
                if len(chanidstr.split(']'))>1:     #type 2  'FREQ 44000 [W_A_P___345A345.00]S1'
                   reid = chanidstr.split(']')[1]
                   if reid.strip():
                      chanidtype = 2
                   else:                               #type 1 
                      chanidtype = 1
             else:
                chanidtype = 3                      # type 3   'PE-PL AREA 2016 [VALLEY ]'
       
    #print ('-%s-%s-%s-'%(chanidtype, bname,kvstr))

    if chanidtype in [1,2]:
       temp  = chanidstr.split('[')[0]         #='FREQ 44000 '
       chanidlst.append(temp[0:4].strip())
       chanidlst.append(int(temp[4:].strip()))
       chanidlst.append(bname)
       chanidlst.append(float(kvstr))
       if chanidtype == 2:                      #machine
          chanidlst.append(str(reid))  
    elif chanidtype == 3:
       temp  = chanidstr.split('[')[0]         #='PE-PL AREA 2016 '
       temp2 = temp.split()
       for valx in temp2:
           #print ('getchanidlst -%s-%s-'%(temp2, valx))
           val2 = JCtools.IsNumber(valx)
           chanidlst.append(val2)
       chanidlst.append(busnamekv.strip())
    elif chanidtype == 4:                       #branch
       chanidlst  = [tmp4[0],tmp4[1],tmp4[3],tmp4[5]]
    else:   
       chanidlst  = chanidstr.split()         #type 0 = unknown
       
    chanidlst.append(chanidtype)
    #print ('out:',chanidlst)
    return chanidlst

# =============================================================================================   
def Channel_select(chnfobj,outidx,channels):
    ''' 
    chanidlst = getchanidlst(chanidstr)
        in  chanidstr = 'FREQ 44000 [W_A_P___345A345.00]'
        out chanidlst =['FREQ',44000,'W_A_P___345A',345.0,1]
                                                          |_chantypeid
        in  chanidstr = 'POWR 44000 [W_A_P___345A345.00]S1' 
        out chanidlst =['POWR',44000,'W_A_P___345A',345.0,'S1',2]
                                                               |_chantypeid
        in  chanidstr = 'PE-PL AREA 2016 [VALLEY ]'
        out chanidlst =['PE-PL', 'AREA', 2016, 'VALLEY',3]
        
        in  chanidstr = 'POWR 1695 TO 5925 CKT '1 '
        out chanidlst =['POWR', 1695, 5925, '1',4]    
    return channelsx,chanidlsx,busChanD
    busChanD = {9:[11,18],                  For each bus, list its chan number
                10:[12,19]
                }
    '''
    global My
    
    busChanD  = {} 
    channelsx = []
    chanidlsx = []
    channelst = []
    #if 'CHANREF' in My:
    #   for k in  range(len(My['CHANREF'])):
    #       channelsx.append(-1)
    #       chanidlsx.append([])
    debug = My['DEBUG']
    sh_ttl, ch_id = chnfobj.get_id()
    outlsti = My['OUTLST'][outidx]
    if debug:
       print ('\n%s - IN channels:'%outlsti,channels)
    if JCtools.WhatType(channels)== 'LIST' and len(channels)>0:     #[31,32] or ['4:7', '8:11']
       for ch in channels:     #ch expected integer          
           if JCtools.WhatType(ch)== 'INTEGER':     #[31,32]
              channelst.append(ch)
              #chanidlsx.append(getchanidlst(ch_id[ch]))
           else:                                    #= ['4:7'] = [4,5,6,7]
              # from str, create a list of channels
              ch2 = str(ch)
              if ':' in ch2:       
                  begin= ch2.split(':')[0]
                  end  = ch2.split(':')[1]
                  #print (ch, begin, end)
                  for i in range(int(begin),int(end)+1):
                      channelst.append(i)
    elif ':' in str(channels):      #'4:7'
        #create a list of selected channels 
        ch2  = str(channels)        
        begin= ch2.split(':')[0]
        end  = ch2.split(':')[1]
        #print (ch, begin, end)
        for i in range(int(begin),int(end)+1):
            channelst.append(i)   
    elif 'INTERFACE' in My:
        #interface is made of input channels
        channelst = My['INTERFACE']
    else:                # get all channels for further selection below
       for ch in ch_id.keys():
           if ch=='time': continue
           channelst.append(ch)

    if debug:
       print ("channelst\nchan,\t,ch_id")
       for chan in channelst:
           print (chan, ch_id[chan])

    for ch in channelst:
        chanidlst = getchanidlst(ch_id[ch])
        chantypeid = chanidlst[-1]
        if debug:
           print ('-',ch_id[ch],'-')
           print ('-',chanidlst,'-')
        if 'CHANEXCL' in My and ch_id[ch][-1]!=']':
           if chanidlst[-2][0].upper() in My['CHANEXCL']: 
              if debug:
                 print ('Channel excluded for ID=',chanidlst[-2][0].upper())
              continue
        
        if 'CHANINCL' in My and ch_id[ch][-1]!=']':
           if not chanidlst[-2][0] in My['CHANINCL']: 
              continue

        if 'AREAMASK' in My and 'SAVFILE' in My:
           if   chantypeid in [1,2]:
                bus = chanidlst[1]
                #bidx= JCtools.indexof(My['BUSDICT'][0],bus)
                abus= My['BUSDICT'][bus][0]
                if not abus in My['AREAMASK']:
                   if My['DEBUG']:
                      print ("bus %s -a%s not in areamask."%(bus,abus))
                   continue
           elif chantypeid ==4:
                buses = [chanidlst[1]]
                buses.append(chanidlst[2])
                businregion= False
                for bus in buses:
                    #bidx= JCtools.indexof(My['BUSDICT'][0],bus)
                    abus= My['BUSDICT'][bus][0]
                    if abus in My['AREAMASK']: 
                       businregion= True
                       break
                if not businregion: continue                
        if 'ZONEMASK' in My and 'SAVFILE' in My:
           if debug:
              print ('ZONEMASK,SAVFILE', My['ZONEMASK'], My['SAVFILE'])        
              print ('ch:%s, ch_id[ch]:'%ch,ch_id[ch],'-')
              print ('chanidlst:',chanidlst,'-')
              print ('chantypeid:',chantypeid)           #x where x=1= buses, 2=gens,3=groups,4=branches
           if   chantypeid in [1,2]:
                bus = chanidlst[1]
                zbus= My['BUSDICT'][bus][1]
                if not zbus in My['ZONEMASK']: continue
           elif chantypeid ==4:
                buses = [chanidlst[1]]
                buses.append(chanidlst[2])
                businregion= False
                for bus in buses:
                    zbus= My['BUSDICT'][bus][1]
                    if zbus in My['ZONEMASK']: 
                       businregion= True
                       break
                if not businregion: continue                
                                 
        if 'KVMASK' in My:
           if My['KVMASK'][0] > float(chanidlst[3]): continue
           if My['KVMASK'][1] < float(chanidlst[3]): continue

        if 'CHANBTYPE' in My:             #= [x] where x=1= buses, 2=gens,3=groups,4=branches
           if chantypeid not in My['CHANBTYPE']: continue  #useful to filter power of gens v. power of branches

        if 'CHANBUS' not in My:            
            if 'CHANMASK' in My:          # a maskkey or a keyword
               #if debug:
               #   print ("My['CHANMASK']:",My['CHANMASK'])
               if JCtools.WhatType(My['CHANMASK'])== 'LIST':
                  cmaskflag = False
                  for cmask in My['CHANMASK']:
                      if chanidlst[0]!= cmask.upper():
                         if debug:
                            print ('Channel excluded - cmask:%s'%cmask, chanidlst[0])
                         continue
                      cmaskflag = True
                      break
                  if not cmaskflag: continue
               else:
                  #print ('**_%s_  _%s_'%(chanidlst[0], My['CHANMASK']))
                  if chanidlst[0] != My['CHANMASK'].upper(): 
                     continue              
               if chantypeid == 0:
                  if not My['CHANMASK'].upper() in ch_id[ch]: 
                     continue                               
               else:
                  if 'CHANTYPEID' in My:
                     if chantypeid != My['CHANTYPEID']: 
                        continue
                   
        else:        #'CHANBUS' in My
           if 'MASKEXCL' in My:
              if chanidlst[0] in My['MASKEXCL']: continue
           if debug: 
              print ("My['CHANBUS']=", My['CHANBUS'])
           bflag = False
           for busx in My['CHANBUS']:
               # has busChanD been initialized?
               try:
                  busChanD[busx]
               except:
                  busChanD[busx] = []
               if debug==2:
                  print ('CHANBUS ch=%s,  ch_id[ch]=%s'%(ch,ch_id[ch]))                   
               if busx in chanidlst:
                  if debug==2: 
                     print ('CHANBUS busx:',busx)
                     print ('CHANBUS ch=%s,  ch_id[ch]=%s'%(ch,ch_id[ch])) 
                  busChanD[busx].append(ch)
                  bflag = True 
                  break
           if not bflag: continue
           
        if debug:
           print ('ch=%s,  ch_id[ch]=%s'%(ch,ch_id[ch]))
           print ('ch=%s'%ch,' chanidlst=', chanidlst  )
        channelsx.append(ch)
        chanidlsx.append(chanidlst)
    if 'CHANBUS' in My:   #
       channelsx = []
       chanidlsx = []
       for busj in busChanD.keys():
           for chanj in busChanD[busj]:
               if chanj=='time': continue
               channelsx.append(chanj)
               chanidlsx.append(getchanidlst(ch_id[chanj]))
    if debug:
       print('Chanbus chan & chanid')
       print(len(channelsx),channelsx)
       print(len(chanidlsx),chanidlsx)
       print(outidx)       
    if outidx==0:       #do it one time!
       #My['CMPCHANREF']   = channelsx.copy()
       #My['CMPCHANIDREF'] = chanidlsx.copy()
       My['CMPCHANREF']   = list(channelsx)
       My['CMPCHANIDREF'] = list(chanidlsx)
    if My['ACTIVITY']== 'COMPARE' and outidx > 0:
       channelsxf = []
       chanidlsxf = []  
       for chridx in range(len(My['CMPCHANREF'])):
           chidi = My['CMPCHANIDREF'][chridx]
           for chidxj in range(len(channelsx)):
               chidj = chanidlsx[chidxj]
               if chidi == chidj:
                  channelsxf.append(channelsx[chidxj])
                  chanidlsxf.append(chidj)   
    else:
       channelsxf = channelsx
       chanidlsxf = chanidlsx
    if debug: 
       print ('\n- Channels found for OUTfile %s -'%outlsti)
       for ch in channelsxf:
           print (ch, ch_id[ch], chantypeid)
       if busChanD:
          print ('busChanD')
          for ch in busChanD.keys():
              print (ch,':', busChanD[ch])
       print(channelsxf)
       print(chanidlsxf)
       #exit() 
    return channelsxf,chanidlsxf,busChanD

def Channel_select_cmp(chnfobj,outidx,channels,My):
    ''' 
    chanidlst = getchanidlst(chanidstr)
        in  chanidstr = 'FREQ 44000 [W_A_P___345A345.00]'
        out chanidlst =['FREQ',44000,'W_A_P___345A',345.0,1]
                                                          |_chantypeid
        in  chanidstr = 'POWR 44000 [W_A_P___345A345.00]S1' 
        out chanidlst =['POWR',44000,'W_A_P___345A',345.0,'S1',2]
                                                               |_chantypeid
        in  chanidstr = 'PE-PL AREA 2016 [VALLEY ]'
        out chanidlst =['PE-PL', 'AREA', 2016, 'VALLEY',3]
        
        in  chanidstr = 'POWR 1695 TO 5925 CKT '1 '
        out chanidlst =['POWR', 1695, 5925, '1',4]    
    return channelsx,chanidlsx,busChanD
    busChanD = {9:[11,18],                  For each bus, list its chan number
                10:[12,19]
                }
    '''
    busChanD  = {} 
    channelsx = []
    chanidlsx = []
    channelst = []
    debug = My['DEBUG']
    sh_ttl, ch_id = chnfobj.get_id()
    outlsti = My['OUTLST'][outidx]
    if debug:
       print ('\n%s - IN channels:'%outlsti,channels)
    if JCtools.WhatType(channels)== 'LIST' and len(channels)>0:     #[31,32] or ['4:7', '8:11']
       for ch in channels:     #ch expected integer          
           if JCtools.WhatType(ch)== 'INTEGER':     #[31,32]
              channelst.append(ch)
              #chanidlsx.append(getchanidlst(ch_id[ch]))
           else:                                    #= ['4:7'] = [4,5,6,7]
              # from str, create a list of channels
              ch2 = str(ch)
              if ':' in ch2:       
                  begin= ch2.split(':')[0]
                  end  = ch2.split(':')[1]
                  #print (ch, begin, end)
                  for i in range(int(begin),int(end)+1):
                      channelst.append(i)
    elif ':' in str(channels):      #'4:7'
        #create a list of selected channels 
        ch2  = str(channels)        
        begin= ch2.split(':')[0]
        end  = ch2.split(':')[1]
        #print (ch, begin, end)
        for i in range(int(begin),int(end)+1):
            channelst.append(i)   
    elif 'INTERFACE' in My:
        #interface is made of input channels
        channelst = My['INTERFACE']
    else:                # get all channels for further selection below
       for ch in ch_id.keys():
           if ch=='time': continue
           channelst.append(ch)

    if debug:
       print ("channelst\nchan,\t,ch_id")
       for chan in channelst:
           print (chan, ch_id[chan])

    for ch in channelst:
           chanidlst = getchanidlst(ch_id[ch])
           chantypeid = chanidlst[-1]
           if debug:
              print ('-',ch_id[ch],'-')
              print ('-',chanidlst,'-')
           if 'CHANEXCL' in My and ch_id[ch][-1]!=']':
              if chanidlst[-2][0].upper() in My['CHANEXCL']: 
                 if debug:
                    print ('Channel excluded for ID=',chanidlst[-2][0].upper())
                 continue
           
           if 'CHANINCL' in My and ch_id[ch][-1]!=']':
              if not chanidlst[-2][0] in My['CHANINCL']: 
                 continue

           if 'AREAMASK' in My and 'SAVFILE' in My:
              if   chantypeid in [1,2]:
                   bus = chanidlst[1]
                   #bidx= JCtools.indexof(My['BUSDICT'][0],bus)
                   abus= My['BUSDICT'][bus][0]
                   if not abus in My['AREAMASK']:
                      if My['DEBUG']:
                         print ("bus %s -a%s not in areamask."%(bus,abus))
                      continue
              elif chantypeid ==4:
                   buses = [chanidlst[1]]
                   buses.append(chanidlst[2])
                   businregion= False
                   for bus in buses:
                       #bidx= JCtools.indexof(My['BUSDICT'][0],bus)
                       abus= My['BUSDICT'][bus][0]
                       if abus in My['AREAMASK']: 
                          businregion= True
                          break
                   if not businregion: continue                
           if 'ZONEMASK' in My and 'SAVFILE' in My:
              if debug:
                 print ('ZONEMASK,SAVFILE', My['ZONEMASK'], My['SAVFILE'])        
                 print ('ch:%s, ch_id[ch]:'%ch,ch_id[ch],'-')
                 print ('chanidlst:',chanidlst,'-')
                 print ('chantypeid:',chantypeid)
              if   chantypeid in [1,2]:
                   bus = chanidlst[1]
                   zbus= My['BUSDICT'][bus][1]
                   if not zbus in My['ZONEMASK']: continue
              elif chantypeid ==4:
                   buses = [chanidlst[1]]
                   buses.append(chanidlst[2])
                   businregion= False
                   for bus in buses:
                       zbus= My['BUSDICT'][bus][1]
                       if zbus in My['ZONEMASK']: 
                          businregion= True
                          break
                   if not businregion: continue                
                                    
           if 'KVMASK' in My:
              if My['KVMASK'][0] > float(chanidlst[3]): continue
              if My['KVMASK'][1] < float(chanidlst[3]): continue

           if 'CHANBTYPE' in My:             #= [x] where x=1= buses, 2=gens,3=groups,4=branches
              if chantypeid not in My['CHANBTYPE']: continue  #useful to filter power of gens v. power of branches

           if 'CHANBUS' not in My:            
               if 'CHANMASK' in My:          # a maskkey or a keyword
                  #if debug:
                  #   print ("My['CHANMASK']:",My['CHANMASK'])
                  if JCtools.WhatType(My['CHANMASK'])== 'LIST':
                     cmaskflag = False
                     for cmask in My['CHANMASK']:
                         if chanidlst[0]!= cmask.upper():
                            if debug:
                               print ('Channel excluded - cmask:%s'%cmask, chanidlst[0])
                            continue
                         cmaskflag = True
                         break
                     if not cmaskflag: continue
                  else:
                     #print ('**_%s_  _%s_'%(chanidlst[0], My['CHANMASK']))
                     if chanidlst[0] != My['CHANMASK'].upper(): 
                        continue              
                  if chantypeid == 0:
                     if not My['CHANMASK'].upper() in ch_id[ch]: 
                        continue                               
                  else:
                     if 'CHANTYPEID' in My:
                        if chantypeid != My['CHANTYPEID']: 
                           continue
                      
           else:        #'CHANBUS' in My
              if 'MASKEXCL' in My:
                 if chanidlst[0] in My['MASKEXCL']: continue
              if debug: 
                 print ("My['CHANBUS']=", My['CHANBUS'])
              bflag = False
              for busx in My['CHANBUS']:
                  # has busChanD been initialized?
                  try:
                     busChanD[busx]
                  except:
                     busChanD[busx] = []
                  if debug:
                     print ('CHANBUS ch=%s,  ch_id[ch]=%s'%(ch,ch_id[ch]))                   
                  if busx in chanidlst:
                     if debug: print ('CHANBUS busx:',busx)
                     busChanD[busx].append(ch)
                     bflag = True 
                     break
              if not bflag: continue
              
           #if debug]:
           #   print ('ch=%s,  ch_id[ch]=%s'%(ch,ch_id[ch]))
           #   print ('ch=%s'%ch,' chanidlst=', chanidlst  )
           channelsx.append(ch)
           chanidlsx.append(chanidlst)              
    if My['ACTIVITY']== 'COMPARE' and outidx > 0:
       channelsxf = []
       chanidlsxf = []  
       for chridx in range(len(My['CMPCHANREF'])):
           chidi = My['CMPCHANIDREF'][chridx]
           for chidxj in range(len(channelsx)):
               chidj = chanidlsx[chidxj]
               if chidi == chidj:
                  channelsxf.append(channelsx[chidxj])
                  chanidlsxf.append(chidj)
       #chanidlsxf = chanidlsxf[0]
    else:
       channelsxf = channelsx
       chanidlsxf = chanidlsx
    if debug: 
       print ('\n- Channels found for OUTfile %s -'%outlsti)
       for ch in channelsxf:
           print (ch, ch_id[ch], chantypeid)
       if busChanD:
          print ('busChanD')
          for ch in busChanD.keys():
              print (ch,':', busChanD[ch])
       #exit() 
    return channelsxf,chanidlsxf,busChanD

# =============================================================================================
def pagetitle_cmd(My):
    # My['PAGETITLE'] is a mix str composed of a true title string
    # and then CSV text formatting the title
    #cmd: pagetitle  = Machine at bus chanbusi,fontsize=6
    # in: pagetitle  = Machine at bus _chanbusi_,fontsize=6
    #                          My var ---^         ^--- option
    #out: pagetitle  = Machine at bus 101,fontsize=6
    #out:figure.suptitle("Machine at bus 101",fontsize=6)
    debug = My['DEBUG']
    fontsizestr = 'fontsize=20'
    newpagetitle = My['PAGETITLE'].split(',')
    if len(newpagetitle)==1:
     if My['ACTIVITY']=='COMPARE':
        if  My['PLOTYPE'] == '1x1':
            fontsizestr = 'fontsize=20'
            if 'LEGENDPOS' in My:
               if My['LEGENDPOS']=='outbelow':
                  newpagetitle.append('x=0.5')
                  newpagetitle.append('y=0.95')
               else:  #legend inside plot
                  newpagetitle.append('x=0.47')
                  fontsizestr = 'fontsize=20'
                  newpagetitle.append('y=0.95')
        elif My['PLOTYPE'] == 'nx1':
             if 'LEGENDPOS' in My:
                if My['LEGENDPOS']=='outright':
                   newpagetitle.append('x=0.4')
                   newpagetitle.append('y=0.97')
                else:  #legend inside plot
                   newpagetitle.append('x=0.5')
                   newpagetitle.append('y=0.97')
        elif My['PLOTYPE'] == 'nxm':
             fontsizestr = 'fontsize=20'

     else:  #Plot
       if   My['PLOTYPE'] == '1x1':
            fontsizestr = 'fontsize=20'
            if 'LEGENDPOS' in My:
               if My['LEGENDPOS']=='outright':
                  newpagetitle.append('x=0.4')
                  newpagetitle.append('y=0.9')
       elif My['PLOTYPE'] == 'nx1':
            fontsizestr = 'fontsize=20'
            if 'LEGENDPOS' in My:
                if My['LEGENDPOS']=='outright':
                   newpagetitle.append('x=0.4')
                   newpagetitle.append('y=0.97')
                else:  #legend inside plot
                   newpagetitle.append('x=0.5')
                   newpagetitle.append('y=0.97')
       elif My['PLOTYPE'] == 'nxm':
            fontsizestr = 'fontsize=12'
    found = False
    for phrase in newpagetitle:
        if 'FONTSIZE' in phrase.upper():
           found = True
           break
    if not found: newpagetitle.append(fontsizestr)
    pagetitlestr = My2str(newpagetitle[0])
    newpagetitle[0] = '"%s"'%pagetitlestr
    pagetitlecmd = 'figure.suptitle(%s)'%(','.join(newpagetitle))
    if debug:
       print('in pagetitle_cmd:',pagetitlecmd)
    return pagetitlecmd

def title_cmd(My):
    # My['TITLE'] is a mix str composed of a true title string
    # and then CSV text formatting the title
    #in: title  = Machine_at_bus_chanbusi,fontsize=6
    #                     My var ---^
    #out:axes.set_title("Machine at bus 101",fontsize=6)
    newtitle = My['TITLE'].split(',')
    if len(newtitle)==1:
       if My['PLOTYPE'] == 'nxm':
          newtitle.append('fontsize=6')
       else:
          newtitle.append('fontsize=12')
    titlestr = My2str(newtitle[0])
    newtitle[0] = '"%s"'%titlestr
    titlecmd = 'axes.set_title(%s)'%(','.join(newtitle))
    return titlecmd

# =============================================================================================
def legend_parse(My):
    #input data at INI file:
    #legend = '''
    #           outlsti,position= 4,fontsize= 7
    #         '''
    #
    #legendpos= outbelow, outright or
    #best: 0, upper right: 1, upper left: 2,lower left: 3, lower right: 4, right: 5, 
    #center left: 6, center right: 7, lower center: 8, upper center: 9, center: 10
    #legendsize= 7           //font size  
    #use as : legendstr,legendpos,legendsize= legend_parse(My)

    lstr    = ''
    position= 0
    fontsize= 7
    def legend_arg(test,position,fontsize):   #test = [position,4]
        key = test[0].strip()
        val = test[1].strip()
        #print ('%s-%s-%s'%(test,key,val))
        if   key.upper() == 'POSITION':
             try:
               position = int(val)  #int 0 to 10
             except:
               position = val.lower()       # str
        elif key.upper() == 'FONTSIZE':
             fontsize = int(val)      
        return position,fontsize

    if 'LEGEND' in My and My['LEGEND']:
       csvlst = My['LEGEND'].split(',')
       lstr = csvlst[0]
       if len(csvlst)>1:
          test = csvlst[1].split('=')
          position,fontsize = legend_arg(test,position,fontsize)
       if len(csvlst)>2:
          test = csvlst[2].split('=')
          position,fontsize = legend_arg(test,position,fontsize)             
    return lstr,position,fontsize

# =============================================================================================
def getplotrc(ploti,rmax,cmax):
    # rmax,cmax start from 1
    # ploti start from 1
    if cmax == 1:
       coli = 1
       rowi = ploti         #ploti cannot be > rmax
    else:      
        if ploti <= cmax:
           return 1, ploti
        remain = ploti % cmax         #modulo operator
        colfill= int(ploti / cmax)         #modulo operator
        if not colfill:
           rowi = 1
           coli = ploti
        else:
           if remain:
              rowi = colfill+1
              coli = remain
           else:
              rowi = colfill
              coli = cmax
              
    return rowi, coli
# =============================================================================================
def points2plotvec(pointlst):
    xlst = []
    ylst = []
    for point in pointlst:
        xlst.append(point[0])
        ylst.append(point[1])
    return [xlst,ylst]
# =============================================================================================
def plotoptions(axes,ploti,My):
    debug = My['DEBUG']
    #print('PlotOptions - debug=',debug)
    rowi, coli = getplotrc(ploti,My['PLTROWS'],My['PLTCOLS'])
    # to set 'autscientific scale' to off
    axes.ticklabel_format(useOffset=False, style='plain', axis='y')
    
    if 'GRID' in My and My['GRID']:          
       axes.grid(My['GRID'])

    if 'LINESTYLE' not in My:        #'solid', 'dashed', 'dashdot', 'dotted'
       My['LINESTYLE'] = 'solid'

    if 'XAXIS' in My:
       axes.set_xscale(My['XAXIS'])
       
    if 'XSCALE' in My:          
       axes.set_xlim(My['XSCALE'][0],My['XSCALE'][1])
    if 'YSCALE' in My:          
       axes.set_ylim(My['YSCALE'][0],My['YSCALE'][1])

    if   My['PLOTYPE'] == '1x1':
         if 'TITLE' in My:          
            #axes.set_title(My2str(My['TITLE']),fontsize=12)
            titlecmd = title_cmd(My)
            ier = eval(titlecmd)
         if 'YLABEL' in My:          
            axes.set_ylabel(My['YLABEL'])
            #set_ylabel_cmd = 'axes.set_xlabel("This is X Axis label", fontsize=18)'
            #ier = eval(set_ylabel_cmd)        
         if 'XLABEL' in My:          
            axes.set_xlabel(My['XLABEL'])
         if 'LEGEND' in My and My['LEGEND']:
            box = axes.get_position()
            if My['LEGENDPOS']=='outbelow':
               axes.set_position([box.x0, box.y0, box.width, box.height*0.75])
               #print ('Legend set to -%s-'%My['LEGENDPOS'])
               axes.legend(My['LEGENDLST'],
                                 loc=10, 
                                 #bbox_to_anchor=(0.5, 1.0),
                                 bbox_to_anchor=(0.5, -0.25), 
                                 ncol=3,
                                 frameon = False,            #  If True, draw the legend with a border
                                 #fancybox=True, 
                                 #shadow=True, 
                                 prop={'size':My['LEGENDSIZE']})
                                 #prop={'size':'small'})
            elif My['LEGENDPOS']=='outright':
               axes.set_position([box.x0,box.y0,box.width*0.8,box.height*0.8])
               axes.legend(My['LEGENDLST'],
                           loc='center left', 
                           bbox_to_anchor=(1, 0.5),
                           frameon = False,            #    If True, draw the legend with a border
                           prop={'size':My['LEGENDSIZE']})
            else:       #inside
               axes.set_position([box.x0, box.y0, box.width, box.height*0.9])
               axes.legend(My['LEGENDLST'], 
                           loc=My['LEGENDPOS'], 
                           frameon = False,            #    If True, draw the legend with a border
                           prop={'size':My['LEGENDSIZE']})
      
    elif My['PLOTYPE'] == 'nx1':
         if 'CHANBUS' in My:
            #axes.set_title(My['CHANMASKI'],fontsize=10)         
            #if My['PLTPAGE']== 'FIRST':
               if 'TITLE' in My:          
                  #axes.set_title(My2str(My['TITLE']),fontsize=12)         
                  titlecmd = title_cmd(My)
                  ier = eval(titlecmd)
         else:
               if 'TITLE' in My:          
                  #axes.set_title(My2str(My['TITLE']),fontsize=12)         
                  titlecmd = title_cmd(My)
                  ier = eval(titlecmd)
                            
         if 'YLABEL' in My:
            ylabel = My['YLABEL']
            if 'CHANBUS' in My:
               ylabel = My['CHANMASKI']
               if ylabel=='FREQ':
                  axes.yaxis.set_major_formatter(matplotlib.ticker.FormatStrFormatter('%.2f'))
             #if 'CHANBUS' in My and 'CHANMASKI' in My:
               #axes.set_ylabel(My['CHANMASKI'])
               #axes.tick_params(direction='out',length=6,width=2,colors='r')
               #axes.tick_params(length=6,width=2)
            axes.set_ylabel(ylabel)
         #print ("** x-axis: ", ploti, My['PLOTSPERPAGE'], My['CHANLAST'], My['XLABEL'])
         if ploti== My['PLOTSPERPAGE'] or My['CHANLAST']:
         #if ploti== My['PLOTSPERPAGE']:
            if 'XLABEL' in My:
               axes.xaxis.set_visible(True)
               axes.set_xlabel(My['XLABEL'])
         else:
               #axes.xaxis.set_visible(False)
               axes.xaxis.set_ticklabels([])
         #      #plt.xticks([])
         #      #plt.tick_params(axis='x', left='off', top='off', right='off', bottom='off', 
         #      #                labelleft='off', labeltop='off', labelright='off', labelbottom='off')
         if 'LEGEND' in My and My['LEGEND']:
            if My['LEGENDPOS']=='outright':
               box = axes.get_position()
               axes.set_position([box.x0,box.y0,box.width*0.75,box.height])
               #lgd = axes.legend(My['LEGENDLST'],loc=9,
               axes.legend(My['LEGENDLST'],
                           loc=9, 
                           bbox_to_anchor=[1.25, 0.5],
                           ncol=1,
                           frameon = False,            #    If True, draw the legend with a border
                           #fancybox=True, 
                           #shadow=True, 
                           prop={'size':My['LEGENDSIZE']})
                           #prop={'size':'small'})
            else:     #legend inside plot
               box = axes.get_position()
               axes.set_position([box.x0,box.y0,box.width,box.height])
               if My['LEGENDPOS']=='outbelow':
                  My['LEGENDPOS']= 4
               if My['LEGENDPOS']=='best':
                  My['LEGENDPOS']= 0
               axes.legend(My['LEGENDLST'],
                           loc=My['LEGENDPOS'], 
                           #bbox_to_anchor=[1.25, 0.97],
                           #ncol=1,
                           frameon = False,            #    If True, draw the legend with a border
                           #fancybox=True, 
                           #shadow=True, 
                           prop={'size':My['LEGENDSIZE']})

    elif My['PLOTYPE'] == '1xn':
         if 'YLABEL' in My:          
            axes.set_ylabel(My['YLABEL'])
         if My.has_key('XLABEL'):          
            axes.set_xlabel(My['XLABEL'])
            
    else:       #nxm  same type channels
         if 'CHANBUS' in My:
            if My['PLOTI']== 1:   #first page
               if 'TITLE' in My:          
                  #axes.set_title(My2str(My['TITLE']),fontsize=12)         
                  titlecmd = title_cmd(My)
                  ier = eval(titlecmd)
         else:
               if 'TITLE' in My:          
                  #axes.set_title(My2str(My['TITLE']),fontsize=12)         
                  titlecmd = title_cmd(My)
                  ier = eval(titlecmd)
         #print ('ploti:',ploti,'(%s,%s)'%(rowi, coli))
         #if coli == 1:
         if 'YLABEL' in My:          
            ylabel = My['YLABEL']
            if 'CHANBUS' in My:
               ylabel = My['CHANMASKI']
               #print('PlotOptions - ylabel=',ylabel)
            axes.set_ylabel(ylabel,fontsize=8)
            if ylabel=='FREQ':
               axes.yaxis.set_major_formatter(matplotlib.ticker.FormatStrFormatter('%.2f'))

         if debug:
            print('PLOTOPTIONS - %s - fig #%s:(%s,%s), last:%s, pltrows:%s'%(My['PLOTYPE'],ploti,rowi,coli,My['CHANLAST'],My['PLTROWS']))
         #if rowi == My['PLTROWS'] or My['PLOTI']== My['PLOTSPERPAGE'] or My['CHANLAST']:
         #if rowi == My['PLTROWS'] or My['CHANLAST'] or My['CHANLAST-1']:
         if rowi == My['PLTROWS'] or My['CHANLAST']:
            if 'XLABEL' in My:
               axes.xaxis.set_visible(True)
               axes.set_xlabel(My['XLABEL'])
            else:
               #axes.xaxis.set_visible(False)
               axes.xaxis.set_ticklabels([])
               
         if 'LEGEND' in My and My['LEGEND']:
            if My['LEGENDPOS']=='outbelow':
               My['LEGENDPOS']= 4
            if My['LEGENDPOS']=='outright':
               My['LEGENDPOS']= 4
            if My['LEGENDPOS']=='best':
               My['LEGENDPOS']= 0
            axes.legend(My['LEGENDLST'],
                        loc=My['LEGENDPOS'], 
                        #bbox_to_anchor=[1.25, 0.97],
                        #ncol=1,
                        frameon = False,            #    If True, draw the legend with a border
                        #fancybox=True, 
                        #shadow=True, 
                        prop={'size':My['LEGENDSIZE']})
                        #prop={'size':'small'})
    
    return
# =============================================================================================
def buschansort(chanbus,bchanlist,chanID_dict):
    #it groups chan of same bus together
    #in: [a1,b1,a2,b2]
    # It uses     chanidlst = getchanidlst(chanidstr)
    #    in  chanidstr = 'FREQ 44000 [W_A_P___345A345.00]'
    #    out chanidlst =['FREQ',44000,'W_A_P___345A',345.0,1]
    #    in  chanidstr = 'POWR 44000 [W_A_P___345A345.00]S1' 
    #    out chanidlst =['POWR',44000,'W_A_P___345A',345.0,'S1',2]
    #                                                           |_chanidtype
    # returns:
    #     newlst = [[a1,a2],[b1,b2]], where each sublist has chans per plot per page 

    pagelst= []
    for bus in chanbus:
      eleid = ''
      pltlst  = []
      for chan in bchanlist:
          ch_idlst = getchanidlst(chanID_dict[chan])
          #print ('buschansort:', chan, ch_idlst)
          if ch_idlst[1] == bus:
             if ch_idlst[-1]==1:    #a bus type, then added
                pltlst.append([chan])
                continue     
             if ch_idlst[-1]==2:    #a gen type, add if same id (this is the 'sort')
                eleid = ch_idlst[-2]
             if eleid:
                if eleid != ch_idlst[-2]:
                   continue
             pltlst.append([chan])
      if pltlst:
         pagelst.append(pltlst)
    return pagelst
# =============================================================================================
def chanpltpage(chanlist,My):
    #it groups chan per plot per page
    #in: [a1,b1,a2,b2]
    # returns:
    #     newlst = [[a1,b1],[a2,b2]], where each sublist has chans per plot per page 
    chanlst= []
    pagelst= []
    pltlst = []
    pltcount = 0
    curves   = 0
    chanlast = chanlist[-1]
    
    if My['CHANSPERPLOT']==1 and My['PLOTSPERPAGE']==1:
       for chan in chanlist:
           chanlst.append([chan])
       return chanlst
    #print ('0chanlst:',chanlst)
    #print ("0My['CHANSPERPLOT']:",My['CHANSPERPLOT'])
    #print ("0My['PLOTSPERPAGE']:",My['PLOTSPERPAGE'])
    if My['CHANSPERPLOT']==1:
       #for chan in chanlist:
       #    chanlst.append([chan])
       for chan in chanlist:
           pltlst.append(chan)
           curves += 1
           if curves== My['CHANSPERPLOT'] or chan == chanlast:
              pagelst.append(pltlst)
              curves = 0
              pltlst = []
              pltcount += 1
              if pltcount== My['PLOTSPERPAGE'] or chan == chanlast:
                 chanlst.append(pagelst)
                 pltcount = 0
                 pagelst= []
       print ('1pagelst:',pagelst)
       print ('1chanlst:',chanlst)
    else:
      for chan in chanlist:
          curves += 1
          pltlst.append(chan)
          if curves== My['CHANSPERPLOT'] or chan == chanlast:
             pltcount += 1
             pagelst.append(pltlst)
             curves = 0
             pltlst = []
          if pltcount== My['PLOTSPERPAGE'] or chan == chanlast:
             chanlst.append(pagelst)
             curves   = 0
             pltcount = 0
             pltlst = []
             pagelst= []
           
    return chanlst
#-----------------------------------------------------------------------------------------------------------
def Array_plot_1x1(axes,ploti,timelst,Y,My):
    '''
    plot 1-x vector against 1-y vector
    axes    is plotting obj
    ploti   is plot id out of row x col, in a page
    timelst is single time array
    Y       is a vector, where the pair (timelst,Y) is a curve
    My      is a data dictionary
    '''
    #fig = plt.figure()
    axes.plot(timelst,Y)
    if 'FLATLINES' in My:          
       for pointlst in My['FLATLINES']:
           plotline = points2plotvec(pointlst)
           plot1 = axes.plot(plotline[0],plotline[1], color='lightcoral', linewidth=4, linestyle=My['LINESTYLE'])
    if 'XYPROFILE' in My:
       for pointlst in My['XYPROFILE']:
           plotline = points2plotvec(pointlst)
           plot1 = axes.plot(plotline[0],plotline[1], color='blue')   

    plotoptions(axes,ploti,My)
    return

def Array_plot_1xm(axes,ploti,timelst,Y,My):
    '''
    plot 1-x vector against m-y vector
    axes    is plotting obj
    ploti   is plot id out of row x col, in a page
    timelst is single time array
    Y       is an array of Yi vector, where the pair (timelst,Yi) is a curve
    My      is a data dictionary
    '''
    linestyle = '-'
    linecolor = 'red'
    linewidth = 1
    #fig = plt.figure()
    for k in range(len(Y)):
        axes.plot(timelst,Y[k])
    if 'FLATLINES' in My:         
       if 'FLATLINESOPT' not in My:
           My['FLATLINESOPT']= [linestyle,linecolor,linewidth]
       for pointlst in My['FLATLINES']:
           plotline = points2plotvec(pointlst)
           plot1 = axes.plot(plotline[0],plotline[1],
                             linestyle=My['FLATLINESOPT'][0],
                             color    =My['FLATLINESOPT'][1],
                             linewidth=My['FLATLINESOPT'][2])
    if 'XYPROFILE' in My:
       if 'XYPROFILEOPT' not in My:
           My['XYPROFILEOPT']= [linestyle,linecolor,linewidth]
       for pointlst in My['XYPROFILE']:
           plotline = points2plotvec(pointlst)
           plot1 = axes.plot(plotline[0],plotline[1],
                             linestyle=My['XYPROFILEOPT'][0],
                             color    =My['XYPROFILEOPT'][1],
                             linewidth=My['XYPROFILEOPT'][2])
    plotoptions(axes,ploti,My)
    return
# =============================================================================================
def page_plot_nx1(channelst,chanID_dict,chanData_dict,pp):
    global My
    #use matplotlib xyplotting
    #from matplotlib import rcParams
    debug = My['DEBUG']
    #chanRange_dict = chnfobj.get_range()
    timelst = chanvals_npa(chanData_dict,'time')
    # Initialize:
    #rcParams['legend.loc'] = 'best'  # optimize legend placement
    #print ('CHANSPERPLOT:%s_'%My['CHANSPERPLOT'])
    if JCtools.WhatType(My['CHANSPERPLOT'])=='STRING':
       if My['CHANSPERPLOT'].upper()=='ALLCHANNELS' or My['CHANSPERPLOT'].upper()=='ALL':
          My['CHANSPERPLOT'] = len(channelst)
          My['LEGENDPOS'] = ''
          My['PLTROWS']= 1
          My['PLTCOLS']= 1
    if debug:
       print ("My['CHANSPERPLOT'],My['PLTROWS'], My['PLTCOLS'] ")
       print (My['CHANSPERPLOT'],My['PLTROWS'], My['PLTCOLS'])
    figsize = My['FIGSIZE']
      
    if 'CHANBUS' in My and My['CHANBUS']:
       # sort channelst to plot all chan of same bus number together
       pltpagelst = buschansort(My['CHANBUS'],channelst,chanID_dict)
       My['PLTROWS']= len(pltpagelst[0])
       My['PLTCOLS']= 1
    else:
       pltpagelst = chanpltpage(channelst,My)
       
    if debug:
       print('pltpagelst:')
       for x in pltpagelst: print (x)
    pagelast = False  
    My['CHANLAST'] = False
    for page in pltpagelst:
        if debug:
           print('page:',page)
        if page == pltpagelst[-1]:
           pagelast = True
        figure = plt.figure(figsize=figsize)
        ploti = 0
        plotlast = False
        for plotlsti in page:
            if debug:
               print('plotlsti:',plotlsti)
            if My['PLOTYPE']=='1x1':
               if My['CHANSPERPLOT'] ==1:
                  plotlst = [plotlsti]
               else:
                  plotlst = plotlsti
            else:       # nx1
               if 'CHANBUS' in My and My['CHANBUS']:
                  plotlst = plotlsti
               elif My['CHANSPERPLOT'] ==1:
                    plotlst = plotlsti
               else:
                  plotlst = plotlsti
            if debug:
               print ('plotlst:',plotlst)
            ploti += 1
            My['PLOTI'] = ploti
            My['LEGENDLST'] = []
            if debug:
               print("My['PLTROWS'],My['PLTCOLS'], ploti:",My['PLTROWS'],My['PLTCOLS'],ploti)
            rowi, coli = getplotrc(ploti,My['PLTROWS'],My['PLTCOLS'])
            axes = plt.subplot2grid((My['PLTROWS'],My['PLTCOLS']), (rowi-1,coli-1))
            Yp = []
            if My['CHANSPERPLOT']==1 and My['PLOTSPERPAGE']==1:
               plotlast = True
            #   
            #elif My['PLOTSPERPAGE']==1:
            #   
            else:
               if ploti == len(page):
                  plotlast = True
            for xchan in plotlst:
                if pagelast and plotlast:
                   if xchan == plotlst[-1]:
                      My['CHANLAST'] = True
                      #My['PLOTSPERPAGE'] = len(page)
                My['CHANI']  = xchan
                if debug:
                   print('xchan:',xchan, plotlst, plotlast, My['CHANLAST'])
                My['CHANIDI']= chanID_dict[xchan]
                if 'CHANBUS' in My and My['CHANBUS']:
                   ch_idlst = getchanidlst(chanID_dict[xchan])
                   My['CHANMASKI']    = ch_idlst[0]
                   My['CHANBUSI'] = ch_idlst[1]  
                   My['CHANBUSNAMEI'] = ch_idlst[2]  
                   My['CHANBUSKVI'] = ch_idlst[3]  
                   My['CHANTYPEID']   = ch_idlst[-1]
                if 'LEGENDSTR' in My and My['LEGENDSTR']:
                   My['LEGENDLST'].append(My2str(My['LEGENDSTR']))           
                #timelst  = chanvals_npa(chanData_dict,'time')      # uses common time vector
                yvaluelst= chanvals_npa(chanData_dict,xchan)
                #Yp = pltfunc_npa(yvaluelst)                 # test for single Y vector
                #Array_plot_1x1(axes,ploti,timelst,Yp,My)
                Yp.append(pltfunc_npa(yvaluelst))
                
            Array_plot_1xm(axes,ploti,timelst,Yp,My)

        if 'PAGETITLE' in My:        
           pagetitlecmd = pagetitle_cmd(My)
           ier = eval(pagetitlecmd)
        pp.savefig()
    # Once you are done, remember to close the object:
    if 'PLOTSHOW' in My and My['PLOTSHOW']:
       plt.draw()
       plt.show()     
    return

def page_plot_nxm(channelst,chanID_dict,chanData_dict,pp):
    import matplotlib.gridspec as gridspec
    global My
    #use matplotlib xyplotting
    #from matplotlib import rcParams
    debug = My['DEBUG']
    #chanRange_dict = chnfobj.get_range()
    timelst = chanvals_npa(chanData_dict,'time')
    # Initialize:
    #rcParams['legend.loc'] = 'best'  # optimize legend placement
    if JCtools.WhatType(My['CHANSPERPLOT'])=='STRING':
       if My['CHANSPERPLOT'].upper()=='ALLCHANNELS':
          My['CHANSPERPLOT'] = len(channelst)
          My['LEGENDPOS'] = ''
          My['PLTROWS']= 1
          My['PLTCOLS']= 1
    figsize = My['FIGSIZE']
    
    if 'CHANBUS' in My and My['CHANBUS']:
       # sort channelst to plot all chan of same bus number together
       pltpagelst = buschansort(My['CHANBUS'],channelst,chanID_dict)
    else:
       pltpagelst = chanpltpage(channelst,My)
        #print('pltpagelst:',pltpagelst)
    pagelast = False  
    My['PAGELAST'] = pagelast 
    My['CHANLAST'] = False
    for page in pltpagelst:
        if page == pltpagelst[-1]:
           pagelast = True
           My['PAGELAST'] = pagelast 
        plotlast = False
        figure = plt.figure(figsize=figsize)
        gs1 = gridspec.GridSpec(My['PLTROWS'],My['PLTCOLS'])
        #for x in gs1: print 'gs1 ',x
        ploti = 0
        for plotlst in page:
            ploti += 1
            My['PLOTI'] = ploti
            My['LEGENDLST'] = []
            axes = figure.add_subplot(gs1[ploti-1])
            if ploti == len(plotlst):
               plotlast = True

            Yp = []
            for xchan in plotlst: 
                if pagelast and plotlast:
                   if xchan == plotlst[-1]:
                      My['CHANLAST'] = True
                My['CHANI']  = xchan
                My['CHANIDI']= chanID_dict[xchan]
                if 'CHANBUS' in My and My['CHANBUS']:
                   ch_idlst = getchanidlst(chanID_dict[xchan])
                   if debug:
                      print('---- in page_plot_nxm, ch_idlst=',ch_idlst)
                   My['CHANMASKI']= ch_idlst[0]
                   My['CHANBUSI'] = ch_idlst[1]  
                   My['CHANBUSNAMEI'] = ch_idlst[2]  
                   My['CHANBUSKVI'] = ch_idlst[3]  
                   My['CHANTYPEID']   = ch_idlst[-1]
                if 'LEGENDSTR' in My and My['LEGENDSTR']:
                   My['LEGENDLST'].append(My2str(My['LEGENDSTR']))           
                yvaluelst = chanvals_npa(chanData_dict,xchan)
                Yp.append(pltfunc_npa(yvaluelst))
                
            Array_plot_1xm(axes,ploti,timelst,Yp,My)
            # plot options
            #hspace = 0.2  # of plot height, titles and xlabels both fall within this ??
            #wspace = 0.3  # of plot height, titles and xlabels both fall within this ??
            #plt.subplots_adjust(left=0.1, right=0.95, top=0.93, bottom=0.1,
            #                    hspace=hspace,wspace=wspace)            
        if 'PAGETITLE' in My:        
           pagetitlecmd = pagetitle_cmd(My)
           ier = eval(pagetitlecmd)
        gs1.tight_layout(figure, rect=[0, 0.03, 1, 0.95])
        pp.savefig()
    # Once you are done, remember to close the object:
    if 'PLOTSHOW' in My and My['PLOTSHOW']:
       #plt.draw()
       plt.show()
        
    return
    
# =============================================================================================
def Channel_plot(chnfobj,channelst,outlsti,fn_suffix=''):
    #plot engine, allow scale function, optimal legend position 
    global My

    print(' \nActivity Plot')
    if not channelst: return
    
    study = My['STUDY']
    if 'PLOTPATH' in My and My['PLOTPATH']:
       plotpath = My['PLOTPATH']
    else:
       plotpath = ''
    if 'PLOTSUBFILE' in My:              
       plotSubFile = plotpath+ My2filename(My['PLOTSUBFILE'],fn_suffix)
    else:
       plotSubFile = plotpath+ My2filename('%s.pdf'%study,fn_suffix)
    if My['DEBUG']:
       print(' plotOutfile =',plotSubFile)
       
    pp = PdfPages(plotSubFile)
    
    short_title, chanID_dict, chanData_dict = chnfobj.get_data(channels=channelst)
    if   My['PLOTYPE'] == 'nxm':
         pdfile = page_plot_nxm(channelst,chanID_dict, chanData_dict,pp)
    else: # My['PLOTYPE'] = 'nx1'   #n>0, also 1x1
         pdfile = page_plot_nx1(channelst,chanID_dict, chanData_dict,pp)
         #pdfile = page_plot_nxm(channelst,chanID_dict, chanData_dict,pp)

    pp.close()
    
    print(' plots for outfile %s saved to %s'%(outlsti,plotSubFile))
    return [plotSubFile]

# =============================================================================================
def vfunc_plot_nx1(channelst,chanID_dict,chanData_dict,pp):
    '''channelslst is a list of list of channels
       i.e.: channels = [[1,2],[3,4],[5,6],[7,8]..]
       where each sub-list are parameters to a vector equation that
       results in a single new list of values:
       if chan1= V & chan2 = Freq then for equation a/b
       a new vector V/Hz v. time is plotted.
    '''
    global My
    #use matplotlib xyplotting
    #from matplotlib import rcParams
    #chanRange_dict = chnfobj.get_range()
    timelst = chanvals_npa(chanData_dict,'time')
    # Initialize:
    #rcParams['legend.loc'] = 'best'  # optimize legend place.ment
    figsize = My['FIGSIZE']
    pltpagelst = chanpltpage(channelst,My)
     #print('pltpagelst ',pltpagelst)
    My['RETURN'] = None
    for page in pltpagelst:
         #print('page ',page)
        figure = plt.figure(figsize=figsize)
        ploti = 0
        for plotlst in page:
            ploti += 1
            My['PLOTI'] = ploti
            My['LEGENDLST'] = []
            rowi, coli = getplotrc(ploti,My['PLTROWS'],My['PLTCOLS'])
            axes = plt.subplot2grid((My['PLTROWS'],My['PLTCOLS']), (rowi-1,coli-1))
            Yp = []
            #execfile(My['VFUNC_EXT']) #results in My['YP']
            exec(open(My['VFUNC_FILE']).read())
            Yp.append(My['YP'])
            #for xchan in plotlst:    #xchan = [1,2]
                #My['CHANI']  = xchan
                #My['CHANIDI']= chanID_dict[xchan]
                #yvaluelst = chanvals_npa(chanData_dict,xchan)
                #yvaluelst = pltfunc_npa(yvaluelst)
                #Yp.append(yvaluelst)
            if 'LEGENDSTR' in My and My['LEGENDSTR']:
               My['LEGENDLST'].append(My2str(My['LEGENDSTR']))           
            #plot 1-x vector against 1-y vector
            #Array_plot_1x1(axes,ploti,timelst,My['YP'],My)
            Array_plot_1xm(axes,ploti,timelst,Yp,My)
            if My['RETURN']== 'BREAK':
               break
        if 'PAGETITLE' in My:        
           pagetitlecmd = pagetitle_cmd(My)
           ier = eval(pagetitlecmd)
        pp.savefig()
        if My['RETURN']== 'BREAK':
           break
        
    # Once you are done, remember to close the object:
    if 'PLOTSHOW' in My and My['PLOTSHOW']:
       plt.draw()
       plt.show()
       
    return

# =============================================================================================
def vfunc_plot(chnfobj,channelst,outlsti,fn_suffix=''):
    #plot engine, allow scale function, optimal legend position 
    global My

    print(' \nActivity Vfunc')
    if not channelst: return
    
    if 'PLOTPATH' in My and My['PLOTPATH']:
       plotpath = My['PLOTPATH']
    else:
       plotpath = ''
    if 'PLOTSUBFILE' in My:              
       plotSubFile = plotpath+ My2filename(My['PLOTSUBFILE'],fn_suffix)
    else:
       plotSubFile = plotpath+ My2filename('%s.pdf'%study,fn_suffix)
    if My['DEBUG']:
       print(' plotOutfile =',plotSubFile)
    pp = PdfPages(plotSubFile)
    
    short_title, chanID_dict, chanData_dict = chnfobj.get_data(channels=channelst)
    pdfile = vfunc_plot_nx1(channelst,chanID_dict, chanData_dict,pp)
    pp.close()
    print(' ploti for outfile %s saved to %s'%(outlsti,plotSubFile))
    return [plotSubFile]

# =============================================================================================
def pyplot_compare():     #
    """  Plot specific channels, one at a time, from all the out files specified
         and save as subplots on one image.
    : outlst: list of  *.out file names with full path (two or more)
             = [abc\t1.out, xyz\t1.out]
    : chans : channels in the out file to be plotted
             = 4            <- single   channel  to compare
             = [2,3,4]      <- multiple channels to compare
      if chan not given, they will be selected:
      filter by chan type= CHANMASK = VOLT      <- select all VOLT channels
                           CHANMASK = POWR ...
    """   
    #---------------------------------------------------------------------------------------------  
    import dyntools
    import numpy as np
    global My
    # input data =================================================================================
    debug  = My['DEBUG']
    #debug = 1
    
    outlst = My['OUTLST']
    if len(outlst)<2 and not My['PMU']:
       print('ERROR: Only one (1) OUT file selected. Select more OUT files.')
       return
    # =============================================================================================
    if 'CHANMASK' in My:
       My['CHANMASKI'] = My['CHANMASK']
    chanbus = []
    channelsX= []
    chanidlsX= []
    ch_id    = []
    ch_data  = []
    channels = []
    pdfiles  = []
    outData_dict = []
    if 'CHANNELS' in My:      #assume same channel number for all out files
       if My['CHANNELS']:
          if isinstance(My['CHANNELS'][0],list):
             channels = My['CHANNELS'][0]
          else:
             channels = My['CHANNELS']
    # ======================================================================
    outidx = -1
    busChanT = {}
    for outlsti in outlst:
        My['OUTLSTI'] = outlsti
        outidx += 1
        outData_dict.append([])
        channelsX.append([])
        chanidlsX.append([])
        ch_id.append([])
        ch_data.append([])
        try:
            chnfobj = dyntools.CHNF(outlsti, outvrsn=My['OUTVRSN'])
        except:
            try:
                chnfobj = dyntools.CHNF(outlsti, My['OUTVRSN'])
            except:
                try:
                    chnfobj = dyntools.CHNF(outlsti)
                except:
                    quit
        channelsX[outidx],chanidlsX[outidx],busChanD = Channel_select(chnfobj,outidx,channels)
        if 'CHANBUS' in My:
           busChanT[outidx]= busChanD
        if debug:
           if 'CHANBUS' in My:
               print('COMPARE - file %s - selected %s buschan:'%(outlsti,len(busChanD)), busChanD)
           else:
               print('COMPARE - file %s - selected %s Channels:'%(outlsti,len(channelsX[outidx])), channelsX[outidx])
        short_title, chanID_dict, outData_dict[outidx] = chnfobj.get_data(channels=channelsX[outidx])
    #timelst = getchanvals(outData_dict[outidx],'time')
    # =============================================================================================
    if debug:
       print('chanidlsX')
       for key in chanidlsX:
           print(key)
    # =============================================================================================
    ppflag = False
    pdfilelst = []
    pageplotsetup = True
    pltpage  = 0
    My['CHANLAST'] = False
    figsize = My['FIGSIZE']
    if debug: print ('channelsX=',channelsX[0])
    numchans = len(channelsX[0])
    for pidx in range(numchans):   #chan order for busi
        if pidx == numchans-1:
           My['CHANLAST'] = True
        if pageplotsetup:
           pageplotsetup = False
           pltpage += 1
           My['PLTPAGE'] = pltpage
           plotsetup = True
           ploti  = 0                               #in matplotlib, plots start from 1
           figure = plt.figure(figsize=figsize)

        if plotsetup:
           plotsetup = False
           ploti += 1
           My['PLOTI'] = ploti
            
           My['LEGENDLST'] = []
           rowi, coli = getplotrc(ploti,My['PLTROWS'],My['PLTCOLS'])
           #print('rowi, coli=',rowi, coli)
           axes = plt.subplot2grid((My['PLTROWS'],My['PLTCOLS']), (rowi-1,coli-1))

        Yp = []
        outidx = -1
        for outlsti in outlst:
            My['OUTLSTI']= outlsti
            outidx += 1
            xchan   = channelsX[outidx][pidx]
            My['CHANI']  = xchan
            My['CHANIDI']= chanidlsX[outidx][pidx]
            chanidi = My['CHANIDI']
            if debug:
               print('pyplot_compare - chan & chani:', My['CHANI'], My['CHANIDI'])
               
            #print('pyplot_compare - chb_lst=',chb_lst)
            My['CHANMASKI']    = chanidi[0]
            #My['CHANBUSNAMEI'] = chanidi[2]  
            #My['CHANBUSKVI']   = chanidi[3]
            My['CHANTYPEID']   = chanidi[-1]
            #print('outlisti:',outlsti, chanidi, My['CHANMASKI'], My['CHANTYPEID'])   
               
            if 'LEGENDSTR' in My and My['LEGENDSTR']:
               My['LEGENDLST'].append(My2str(My['LEGENDSTR']))
            timelst   = chanvals_npa(outData_dict[outidx],'time')
            yvaluelst = chanvals_npa(outData_dict[outidx],xchan)
            Yp = pltfunc_npa(yvaluelst)
            #Array_plot_1x1(axes,ploti,timelst,Yp,My)
            axes.plot(timelst,Yp)
            #Yp.append(pltfunc_npa(yvaluelst))
        plotoptions(axes,ploti,My)
        
        if My['PMU']:
           k = -1
           for pmufile in My['PMUFILES']:
               k += 1
               if os.path.isfile(pmufile):
                  #pmudata is a 2d vector with time and vector
                  #pmudata[0] = time series
                  #pmudata[1] = vector data
                  ier, pmutemp = JCtools.CSVfile_read(pmufile,numeric=True)
                  My['PMUDATA'] = np.array(pmutemp).T.tolist()
                  timelst = My['PMUDATA'][0]
                  Yp      = My['PMUDATA'][1]
                  if 'PMULEGENDS' in My and My['PMULEGENDS']:
                     My['LEGENDLST'].append(My['PMULEGENDS'][k])
                  else:
                     My['LEGENDLST'].append(fnameroot(pmufile))
                  axes.plot(timelst,Yp)
        
        if 'FLATLINES' in My:          
           for pointlst in My['FLATLINES']:
               plotline = points2plotvec(pointlst)
               plot1 = axes.plot(plotline[0],plotline[1])
        if 'XYPROFILE' in My:
           for pointlst in My['XYPROFILE']:
               plotline = points2plotvec(pointlst)
               plot1 = axes.plot(plotline[0],plotline[1], color='red')   

        #Array_plot_1xm(axes,ploti,timelst,Yp,My)
        if  ploti < My['PLOTSPERPAGE'] and not My['CHANLAST']:
            plotsetup = True
            continue

        if 'PAGETITLE' in My:        
           pagetitlecmd = pagetitle_cmd(My)
           ier = eval(pagetitlecmd)
        pageplotsetup = True

        if 'PLOTSUBFILE' in My:              
           plotSaveFile = My2filename(My['PLOTSUBFILE'])            #My is global
        else:
           plotSaveFile = My2filename('study')        
        if '.PDF' not in plotSaveFile.upper():
           plotSaveFile += '.pdf'

        if not ppflag:
           pp = PdfPages(plotSaveFile)
           ppflag = True
           
        pp.savefig() 
        
        if  not My['CHANLAST']:
            plotsetup = True
            pageplotsetup = True
            #print(plotSaveFile,My['PLOTSPERPAGE'], ploti, My['CHANLAST'])
            continue
            
        pp.close()
        ppflag = False
        pdfiles.append(plotSaveFile)
        print(' \nplots for comparing channels saved to %s'%(plotSaveFile))
   
    if 'PLOTSHOW' in My and My['PLOTSHOW']:
       plt.show()
      
    return pdfiles

# =============================================================================================
def pyplot_bus_compare():
    """  Comparative plot channels from the specified outfiles and save them as subplots.
      outlst: list of  *.out file names with full path (two or more)
             = [abc\t1.out, xyz\t1.out]
      channels : list of channels in the outfile to be plotted
             = 4            <- single   channel  to compare
             = [2,3,4]      <- multiple channels to compare
      if chans not given, they will be selected:
      filter by chan type= CHANMASK = VOLT      <- select all VOLT channels
                           CHANMASK = POWR ...
      filter by bus number=CHANBUS =[1,2]       <- For network bus in CHANBUS, 
                                                   select channels by chan type (VOLT,..)
    """   
    #---------------------------------------------------------------------------------------------
    import matplotlib.gridspec as gridspec    
    import dyntools
    global My
    # input data =================================================================================
    debug  = My['DEBUG']
    #debug = 1
    outlst = My['OUTLST']
    if len(outlst)<2 and not My['PMU']:
       print('ERROR: pyplot_compare - No (2 or more) OUT file selected.')
       return
    # =============================================================================================
    chanbus  = []
    channelsX= []
    chanidlsX= []
    ch_id    = []
    ch_data  = []
    channels = []
    pdfiles  = []
    outData_dict = []
    if 'CHANMASK' in My:
       My['CHANMASKI'] = My['CHANMASK']
    if 'CHANBUS' in My:
       chanbus = My['CHANBUS']    #a list
       nchanbus= len(chanbus)

    busChanT = {}
    outidx = -1
    for outlsti in outlst:
        My['OUTLSTI'] = outlsti
        outidx += 1
        outData_dict.append([])
        channelsX.append([])
        chanidlsX.append([])
        ch_id.append([])
        ch_data.append([])
        
        if 'CHANNELS' in My:
           if My['CHANNELS']:
              if isinstance(My['CHANNELS'][0],list):
                 channels = My['CHANNELS'][outidx]
              else:
                 channels = My['CHANNELS']        
        
        try:
            chnfobj = dyntools.CHNF(outlsti, outvrsn=My['OUTVRSN'])
        except:
            try:
                chnfobj = dyntools.CHNF(outlsti, My['OUTVRSN'])
            except:
                try:
                    chnfobj = dyntools.CHNF(outlsti)
                except:
                    quit
        channelsX[outidx],chanidlsX[outidx],busChanD = Channel_select(chnfobj,outidx,channels)

        if debug:
            for x in channelsX[outidx]:
                print('channelsX-%s '%outidx,x)
        if 'CHANBUS' in My:
           busChanT[outidx]= busChanD
        if debug:
           if 'CHANBUS' in My:
               print('COMPARE - file %s - selected %s busChan:'%(outlsti,len(busChanD)), busChanD)
           else:
               print('COMPARE - file %s - selected %s Channels:'%(outlsti,len(channelsX[outidx])), channelsX[outidx])
        if My['PSSEVERSION'] == 35:
           if 'time' not in channelsX[outidx]:
              channelsX[outidx].append('time')
        short_title, chanID_dict, outData_dict[outidx] = chnfobj.get_data(channels=channelsX[outidx])
        if debug:
            print('outData_dict for OUTfile ',outlsti)
            print(outData_dict[outidx].keys())

    # =============================================================================================
    if debug:
       for key in busChanT:
           print(key,'=',busChanT[key])
    # =============================================================================================
    if 'PLOTSUBFILE' in My:              
       plotSaveFile = My2filename(My['PLOTSUBFILE'])            #My is global
    else:
       plotSaveFile = My2filename('study.pdf')
    # =============================================================================================
    chanbusidx = -1
    for chanbusi in chanbus:
        chanbusidx += 1
        My['CHANBUSI']= chanbusi
        if debug:
           print('pyplot_compare_nxm chanbusi=',chanbusi)
        ppflag = False
        pdffiles = []
        pageplotsetup = True
        pltpage = 0
        My['CHANLAST'] = False 
        figsize = My['FIGSIZE']
        if chanbusi:
           numchans = len(busChanT[outidx][chanbusi])
        else:
           numchans = len(channelsX[0])  #chans in first file
           if debug:
                print('channelsX[0]=',channelsX[0])
                print('channelsX[1]=',channelsX[1])
        for pidx in range(numchans):   #chan order for busi
            if pidx == numchans-1:
               My['CHANLAST'] = True
            if pidx == numchans-2:
               My['CHANLAST-1'] = True
            else:
               My['CHANLAST-1'] = False
            if pageplotsetup:
               pageplotsetup = False
               pltpage += 1
               plotsetup = True
               ploti= 0
               figure = plt.figure(figsize=figsize)
               gs1 = gridspec.GridSpec(My['PLTROWS'],My['PLTCOLS'])
            if plotsetup:
               plotsetup = False
               ploti += 1
               My['PLOTI'] = ploti

               My['LEGENDLST'] = []
               axes = figure.add_subplot(gs1[ploti-1])
            Yp = []
            outidx = -1
            for outlsti in outlst:
                My['OUTLSTI']= outlsti
                outidx += 1                
                if 'CHANBUS' in My:
                   busChanD= busChanT[outidx]
                   chani   = busChanD[chanbusi][pidx]
                   chb_idx = pidx +numchans*chanbusidx
                   chanidi = chanidlsX[outidx][chb_idx]
                else: 
                   chani   = channelsX[outidx][pidx]
                   chanidi = chanidlsX[outidx][pidx]
                if chani=='time': continue  #last item for pidx
                
                My['CHANI']  = chani
                My['CHANIDI']= chanidi
                if debug:
                   print(outlsti,'- chan & chani:',My['CHANI'], My['CHANIDI'])
                   
                My['CHANMASKI']    = chanidi[0]
                #My['CHANBUSNAMEI'] = chanidi[2]  
                #My['CHANBUSKVI']   = chanidi[3]
                My['CHANTYPEID']   = chanidi[-1]
                if debug:
                   print('bus:',chanbusi,outlsti,'chan:',chani, chanidi)
                   
                if 'LEGENDSTR' in My and My['LEGENDSTR']:                 
                   My['LEGENDLST'].append(My2str(My['LEGENDSTR']))
                timelst   = chanvals_npa(outData_dict[outidx],'time')
                yvaluelst = chanvals_npa(outData_dict[outidx],chani)
                
                Yp = pltfunc_npa(yvaluelst)
                axes.plot(timelst,Yp)
                    
            if My['PMU']:
               k = -1
               for pmufile in My['PMUFILES']:
                   k += 1
                   if os.path.isfile(pmufile):
                      #pmudata is a 2d vector with time and vector
                      #pmudata[0] = time series
                      #pmudata[1] = vector data
                      ier, pmutemp = JCtools.CSVfile_read(pmufile,numeric=True)
                      My['PMUDATA'] = np.array(pmutemp).T.tolist()
                      timelst = My['PMUDATA'][0]
                      Yp      = My['PMUDATA'][1]
                      if 'PMULEGENDS' in My and My['PMULEGENDS']:
                         My['LEGENDLST'].append(My['PMULEGENDS'][k])
                      else:
                         My['LEGENDLST'].append(fnameroot(pmufile))
                      axes.plot(timelst,Yp)

            if 'FLATLINES' in My:          
               for pointlst in My['FLATLINES']:
                   plotline = points2plotvec(pointlst)
                   plot1 = axes.plot(plotline[0],plotline[1])
            if 'XYPROFILE' in My:
               for pointlst in My['XYPROFILE']:
                   plotline = points2plotvec(pointlst)
                   plot1 = axes.plot(plotline[0],plotline[1], color='red')   

            if 'CHANBUS' in My:         #vars for page
                chb_idlst = My['CHANIDI']
            #    #My['CHANMASKI']    = chb_idlst[0]
            #    #My['CHANBUSI']     = chb_idlst[1]  
                My['CHANBUSNAMEI'] = chb_idlst[2]  
            #    #My['CHANBUSKVI']   = chb_idlst[3]
            #    #My['CHANTYPEID']   = chb_idlst[-1]
                if debug:
                   print('Page:', pltpage,'pidx:',pidx,' chb_idlst=',chb_idlst, My['CHANBUSNAMEI'],'\n')
                
            plotoptions(axes,ploti,My)
            #Array_plot_1xm(axes,ploti,timelst,Yp,My)
            if  ploti < My['PLOTSPERPAGE'] and not My['CHANLAST']: 
                plotsetup = True
                continue

            if 'PAGETITLE' in My:        
               pagetitlecmd = pagetitle_cmd(My)
               ier = eval(pagetitlecmd)
            pageplotsetup = True
            gs1.tight_layout(figure, rect=[0, 0.03, 1.0, 0.95])

            if 'PLOTSUBFILE' in My:              
               plotSaveFile = My2filename(My['PLOTSUBFILE'])            #My is global
            else:
               plotSaveFile = My2filename('study')
            if '.PDF' not in plotSaveFile.upper():
               plotSaveFile += '.pdf'
            if not ppflag:
               pp = PdfPages(plotSaveFile)
               ppflag = True
               
            pp.savefig()
            if  not My['CHANLAST']:
                plotsetup = True
                pageplotsetup = True
                #print(plotSaveFile,My['PLOTSPERPAGE'], ploti, My['CHANLAST'])
                continue
            
            pp.close()
            ppflag = False
            pdfiles.append(plotSaveFile)
      
    if 'PLOTSHOW' in My and My['PLOTSHOW']:
       plt.show()
    return pdfiles
    
# =============================================================================================   
# 1. Data extraction/information
def All_Channel_info(chnfobj,mychannels):
    ''' if mychannels not given, process all channels
        it process first OUT file in list
     '''
    global My

    Channel_info_str = ''
    print(' \nActivity Info')
    if not mychannels:
       print(' WARNING: All Channel_info - No channels were selected.')
       return Channel_info_str

    if My['SHOWCHANNELID']==1:
       '''{1: 'FREQ 44000 [W_A_P___345A345.00]', 
           2: 'FREQ 46500 [TOMBAL__345B345.00]',...'''
       sh_ttl, ch_id = chnfobj.get_id()
        #print(sh_ttl)
       Channel_info_str += '\nCHANNELs ID\n'
       Channel_info_str += 'ch#   CHANNEL ID\n'
       if mychannels:
          for chanID in mychannels:
              Channel_info_str += '%s = %s\n'%(chanID,ch_id[chanID])
       
    if My['SHOWCHANNELRANGE']==1:
       '''{1: {'max': 0.0, 'min': -0.004786934703588486}, 
           2: {'max': 0.0, 'min': -0.0047869072295725346}, ...'''
       ch_range = chnfobj.get_range()
       Channel_info_str +=  '\nCHANNELs RANGE [min, max]\n'
       Channel_info_str +=  'ch#   min      max]\n'
       if mychannels:
          for chanID in mychannels:
              Channel_info_str += '%s = [%.3f, %.3f]\n'%(chanID,ch_range[chanID]['min'],ch_range[chanID]['max'])

    if My['SHOWCHANNELSCALE']==1:
       ''' ch_scale = chnfobj.get_scale() # to get info for all channels
           {1: {'max': 0.0, 'min': -0.005}, 
            2: {'max': 0.0, 'min': -0.005},...
          or    
           chmin, chmax = outobj.scale(ch, limit_min2zero)    # to get info for a channel 
            ch              =  channel number
            limit_min2zero  =  boolean specifying if chmin values should be rounded
                               to zero if negative (False by default).
           
           '''
       ch_scale = chnfobj.get_scale()
       Channel_info_str +=  '\nCHANNELs SCALE [min, max]\n'
       Channel_info_str +=  'ch#   min      max]\n'
       if mychannels:
          for chanID in mychannels:
              #chmin, chmax = chnfobj.scale_pssplt(chanID)  #chnobj from OUTDATA, not in CHNF
              chmin = ch_scale[chanID]['min']
              chmax = ch_scale[chanID]['max']
              Channel_info_str += '%s = [%s, %s]\n'%(chanID,chmin,cmax)

    if My['SHOWCHANNELPRINTSCALE']==1:      #ID + Range + Scale at once
       '''                                                ACTUAL                SCALED
 CHN#    CHANNEL IDENTIFIER                       MINIMUM       MAXIMUM    MINIMUM  MAXIMUM
         Time(s)                                        0       30.0001          0       30
  1      FREQ 44000 [W_A_P___345A345.00]      -0.00478693             0     -0.005        0
  2      FREQ 46500 [TOMBAL__345B345.00]      -0.00478691             0     -0.005        0
       '''
       print('\nCHANNELs PRINT SCALE')
       chnfobj.print_scale()
       
    if My['SHOWCHANNELDATA']==1:
       '''{1: 'FREQ 44000 [W_A_P___345A345.00]', 
           2: 'FREQ 46500 [TOMBAL__345B345.00]','''
       short_title, ch_id, ch_data = chnfobj.get_data()
        #print(short_title)
       Channel_info_str += '\nCHANNELs DATA\n'
       Channel_info_str += 'ch#    Chan Bus  Name     Kv\n'
       if mychannels:
          for chanID in mychannels:
              Channel_info_str += '%s = %s\n'%(chanID,ch_data[chanID])
    
    return Channel_info_str
    
# =============================================================================================
# 1. Data extraction/information for a single OUT file
def Channels_export(chnfobj,mychannels,filei):
    global My
    #mychannels = [31,32,33,34,35]
    print(' \nActivity Export')
    if not mychannels:
       print(' WARNING: Channels_export - No channels were selected.')
       return
    else:
       print(' exp channels: ', mychannels)
    fileiroot, ext= os.path.splitext(filei.lower())
    
    if 'EXP2TXT' in My:
       TXTfile = My2filename(My['EXP2TXT'])
       chnfobj.txtout(channels=mychannels,txtfile=TXTfile)
       print('\n Channels exported to %s text file'%(TXTfile))
       
    if 'EXP2CSV' in My:
       CSVfile = My2filename(My['EXP2CSV'])
       chnfobj.csvout(channels=mychannels,csvfile=CSVfile)
       print('\n Channels exported to %s csv file'%(CSVfile))
       
    if 'EXP2XLS' in My:
       XLSfile = My2filename(My['EXP2XLS'])
       sheetname = fnameroot(fileiroot)
       if len(sheetname) >31: 
          sheetname = sheetname[:30]
       sheetname = sheetname.replace('[','')
       sheetname = sheetname.replace(']','')
       sheetname = sheetname.replace('.','_')
       try: 
         chnfobj.xlsout(channels=mychannels, show=False, outfile=filei ,xlsfile=XLSfile,sheet=sheetname)
         print('\n Channels exported to %s Excel file, sheet %s'%(XLSfile,sheetname))
       except:
         print('\n ERROR: Exporting Channels to %s Excel file, sheet %s failed.'%(XLSfile,sheetname))

# =============================================================================================
def UVDR(y,t,UVval,UVtime):           #Under Value Delay Recovery 
    UVDRflag = False        #true is UVDR detected
    UVflag= False           #true if y < ymin
    krange = []             #range of index for begin & end points
    for k in range(len(y)):
        if not UVflag:
           if y[k] < UVval:
              kstr = k
              UVflag= True
        else:
           period = t[k] - t[kstr]
           if period > UVtime:
              UVDRflag = True
              kend = k
              krange.append([kstr,kend])
              break                     #detect first UVDR and exit
           if y[k] > UVval:
              UVflag= False                
    return UVDRflag, krange

def OVDR(y,t,OVval,OVtime):           #Over Value Delay Recovery 
    OVDRflag = False        #true is OVDR detected
    OVflag= False           #true if y < ymin
    krange = []             #range of index for begin & end points
    for k in range(len(y)):
        if not OVflag:
           if y[k] > OVval:
              kstr = k
              OVflag= True
        else:
           period = t[k] - t[kstr]
           if period > OVtime:
              OVDRflag = True
              kend = k
              krange.append([kstr,kend])
              break                     #detect first OVDR and exit
           if y[k] < OVval:
              OVflag= False                
    return OVDRflag, krange

def make_xlWorkbook(Wbfilename='',PgName='',
                    data_array=[],
                    #CellHeader='',
                    row=1,col=1):
    print('make_xlWorkbook - load excelpy')
    try:
        import excelpy
    except:
        print("ERROR - excelpy NOT loaded")
    if not PgName:
       PgName = chanmask
    if not PgName:
       PgName = 'sheetx'
    # Open the work-book for writing
    #xlwb = excelpy.workbook(xlsfile='', sheet='', overwritesheet=False, mode='w')
    xlwb = excelpy.workbook(Wbfilename, PgName, True, 'w')
    xlwb.set_active_sheet(PgName)
    # --------
    # Enter the data
    xlwb.set_range(row,col, data_array)
    # --------
    xlwb.save(Wbfilename)
    xlwb.close()
    # --------
    return

# =============================================================================================
def slope(y,x,idx):
    import numpy
    try:
      dy = numpy.diff(y)
      dx = numpy.diff(x)
      slope = dy/dx
    except:
      return None
    return slope[idx-1]

def min2right(v,idx):
    '''
    find the first minimum point to the right of the idx location
    function is monotonically descending
    '''
    minv = 1e10
    for r in range(idx,len(v)-1):
        if r==idx: continue
        if v[r] < minv:
           minv = v[r]
           mini = r
           continue
        elif v[r] == minv: continue
        else:  #v[r] > minv
           break
    return mini

def min2left(v,idx):
    '''
    find the first minimum point to the left of the idx location
    function is monotonically descending
    '''
    minv = 1e10
    for r in range(idx):
        t = idx - r
        if t==idx: continue
        if v[t] < minv:
           minv = v[t]
           mini = t
           continue
        elif v[t] == minv: continue
        else:  #v[t] > minv
           break
    return mini

# =============================================================================================
def damping1(y,x,My):
    z = y
    tz= x
    Zmax = max(z)  #assume to be first +peak
    Zmaxidx= JCtools.indexof(z,Zmax)    #index of time_begin
    Tzmax  = tz[Zmaxidx]
    #assume: Zmin to be found after Zmax
    z_b  = z[Zmaxidx:]
    tz_b = tz[Zmaxidx:]
    Zmin = min(z_b)  #assume to be first -peak after +peak
    if My['DEBUG']: 
       print('Zmax=%s, Zmin=%s'%(Zmax, Zmin))
    if abs(JCtools.relativepercentfx(Zmax,Zmin))> 0.01:
       Zavg = (Zmax + Zmin)/2.0
       Zminidx= JCtools.indexof(z_b,Zmin)    #index of time
       Tzmin  = tz_b[Zminidx]
       if My['DEBUG']:
          print('Peaks')
          print(Zmaxidx,Zminidx,len(z))
          print(Tzmax, Tzmin)
       #assumes a  monotonically decreasing signal
       idxdelta = Zminidx
       if My['DEBUG']:
          print('idxdelta=', idxdelta)
       
       if   Tzmin > Tzmax:
            max2idx = min(Zmaxidx+2*idxdelta,len(z)-1)
            Zmax2 = z[max2idx]
       elif Tzmin < Tzmax:    #assumes a monotonically increasing signal
            max2idx = max(Zmaxidx-2*idxdelta,0)
            Zmax2 = z[max2idx]
       Zmax3 = abs(Zmax - Zavg)
       Zmax4 = abs(Zmax2- Zavg)
       if My['DEBUG']:
          print('Zmax=%s, Zmax2=%s'%(Zmax, Zmax2))
          print('Zmax3=%s, Zmax4=%s'%(Zmax3, Zmax4))
       dampingratio = abs(JCtools.relativepercentfx(Zmax3,Zmax4))
       if My['DEBUG']:
          print('dampingratio=', dampingratio)
    return dampingratio

def peakdet(v, x = None, delta=1 ):
    """
    PEAKDET Detect peaks in a vector
    Converted from MATLAB script at http://billauer.co.il/peakdet.html
    
    Returns two arrays
    
    call as: peakdet(v, x, delta)
    return : maxtab, mintab

    It finds the local maxima and minima ("peaks") in the vector V.
    MAXTAB and MINTAB consists of two columns. 
        Column 1 contains indices in V, and 
        column 2 the found values.
    
    When x-index values are provided the indices in MAXTAB and MINTAB 
    are replaced with the corresponding X-values.
    
    A point is considered a maximum peak if it has the maximal
    value, and was preceded (to the left) by a value lower by DELTA.
    
    Eli Billauer, 3.4.05 (Explicitly not copyrighted).
    This function is released to the public domain; Any use is allowed.
    
    """
    maxtab = []
    mintab = []
       
    if x is None:
       x = np.arange(len(v))
    v = np.asarray(v)
    
    if len(v) != len(x):
       sys.exit('Input vectors v and x must have same length') 
    if not np.isscalar(delta):
       sys.exit('Input argument delta must be a scalar')   
    if delta <= 0:
       sys.exit('Input argument delta must be positive')
    
    mn, mx = np.Inf, -np.Inf
    mnpos, mxpos = np.NaN, np.NaN
    
    lookformax = True
    
    for i in np.arange(len(v)):
        this = v[i]
        if this > mx:
           mx = this
           mxpos = x[i]
        if this < mn:
           mn = this
           mnpos = x[i]
        if lookformax:
           if this < mx-delta:
              maxtab.append((mxpos, mx))
              mn = this
              mnpos = x[i]
              lookformax = False
        else:
           if this > mn+delta:
              mintab.append((mnpos, mn))
              mx = this
              mxpos = x[i]
              lookformax = True

    return np.array(maxtab), np.array(mintab)
    
def peakdecay_damping(y,tvec, chan, My):     #damping of single channel
    # chanmask = Etrm, SPD,,,to check (oscillatory stability)
    debug = My['DEBUG']
    chandeltaval= My['CHANDELTAVAL']
    oscthreshold= My['OSCTHRESHOLD']
    if 'FREQLIMIT' in My:
       freqlimit = My['FREQLIMIT']
    dp = My['DAMPINGPCT']/100.00  
    D = 999.0
    F = 0.0
    Note = ''
    pratio= math.exp(-4*math.pi*dp/(1-dp**2)**0.5)
    ndp=len(y)                           # count number of data points in one output signal
    if debug:
       print(' chan:%s has ndp=%s data points.'%(chan,ndp))
    for i in range(1):
       if ndp < My['DMPMINPTS']: 
          Note= ' chan:%s has only ndp=%s data points. Skip it.'%(chan,ndp)
          break
       maxpeak, minpeak = peakdet(y,chandeltaval,tvec)
       # maxpeak (and minpeak) is a list in which every entry has two columns (t, Y): 
       # column 1 contains tseries values, and column 2 the corresponding series values.
       if not maxpeak.all or not minpeak.all:
          Note=' Signal has no peaks'
          break   
       if debug:
          print('chan, maxpeak, minpeak')
          print(chan, maxpeak, minpeak)
          #for k in range(len(minpeak)):
          #    print ' '*10,'%s - %s'%(maxpeak[k],minpeak[k])
       if len(maxpeak)<3 or len(minpeak)<3:
          Note=' Signal has less than 3 peaks'
          break   
       PP1 =  maxpeak[-1][1]- minpeak[-1][1]
       PP3 =  maxpeak[-3][1]- minpeak[-3][1]
       T1  = abs(maxpeak[-3][0]- maxpeak[-1][0])/2.0    #period between two crests
       T2  = abs(minpeak[-3][0]- minpeak[-1][0])/2.0
       F   = 2.0/(T1+T2)                                  #frequency = 1/ avg(T1, T2)
       if 'FREQLIMIT' in My:
          if F > My['FREQLIMIT']: 
             Note=' Signal freq. %s > %s, max. freq'%(F,My['FREQLIMIT'])
             break
       # end of Alternative method to detect peaks 
       if debug:
          print(' chan:%s PP1=%s, PP3=%s, ratio=%s, pratio=%s'%(chan,PP1,PP3,PP3/PP1,pratio))
       if True:                             # if violation detected
       #if PP1/PP3 > pratio:                            # if violation detected
          M1 = np.log(PP3/PP1)                          # calculate damping D%
          M2 = (M1/4/math.pi)**2
          D  = 100*(-M1/abs(M1))*(M2/(1+M2))**(0.5)     # damping factor
          if debug:
             print(' chan:%s M1=%f, M2=%f, D=%f, f=%f'%(chan,M1,M2,D,F))
          Note=''
          if abs(D) < oscthreshold:              # the oscillation may be a limit cycle if the damping is very close to zero
             Note +=' sustained oscillation suspect'
       if Note: print(Note)
    return abs(D),F,Note

def Channel_Damping(chnfobj,My):            #for a single OUT file 
    chandamprsl= []
    chandamp= []
    outfile   = My['OUTLSTI']
    channelsx = My['CHANNELSX']
    if not channelsx:
       print(' ERROR - No channels detected. %s is bypassed!'%outfile)
       return '',''
    case_titles, ch_id, ch_data = chnfobj.get_data(channelsx,outfile)
    # time vector        
    xo = chanvals_npa(ch_data,'time')         #xo is original time vector
    if not len(xo):
       print(' ERROR - Vector time is empty or corrupted. %s is bypassed!'%outfile)
       return
       
    svd_thresh = My['SVD_THRESH'] 
    num_iter   = My['NUM_ITER'] 
    dampingpct = My['DAMPINGPCT']
    plotshow   = My['PLOTSHOW']
    reconstruct= My['RECONSTRUCT']
    oscAmin    = My['OSCAMIN']
    chandeltaval= My['CHANDELTAVAL']
    debug      = My['DEBUG']

    if 'DOMINANTPCT' in My:
       dominantpct= My['DOMINANTPCT']
    else:
       dominantpct= 0
    if 'FRANGE' in My:
        frange     = My['FRANGE']       #=[0.2, 2.0]
        frangemin  = frange[0]
        frangemax  = frange[1]
    else:
        frangemin  = 0.2
        frangemax  = 2.0
    
    if 'XSCALE' not in My:
       My['XSCALE'] = [xo[0],xo[len(xo)-1]]

    ib = 0
    ie = len(xo)-1
    if 'TIME_LASTPCT' in My:
       tend = xo[ie]
       tbegin = xo[0] + (tend-xo[0])*(1.0-My['TIME_LASTPCT']/100.0)
       ib = JCtools.indexof(xo,tbegin)        #index of time_begin
       if debug:
          print('TIME_LASTPCT period: t[first]=%s,t[last]=%s, n-points=%s'%(xo[ib], xo[ie],ie-ib))
    else:
       if 'TIME_BEGIN' in My:
          ib = JCtools.indexof(xo,My['TIME_BEGIN'])    #index of time_begin       
       if 'TIME_END' in My:
          ie = JCtools.indexof(xo,My['TIME_END'])       #index of time_end
    
    x = xo[ib:ie]       #x is a subset time vector
    if not len(x):
       print(' ERROR - Vector time is empty or corrupted. %s is bypassed!'%outfile)
       return
    if debug:  
       print('\n*** Processing time period: %7.3fs - %7.3fs'%(x[0],x[-1]))
       #print('ib, ie, x[0],x[-1]')
       #print(ib, ie, x[0], x[-1])

    # ----
    dp = My['DAMPINGPCT']/100.00  
    pratio= math.exp(-4*math.pi*dp/(1-dp**2)**0.5)
    # Calculate for each channel
    Ymatrix = []
    labels  = []
    chan_selected = []
    chanlast= False
    dampdf = ''
    mpdf = []
    # additional data conditioning and filtering based on amplitud
    for chan in channelsx:
        if chan == channelsx[-1]: chanlast= True
        ch_label  = ch_id[chan].strip()
        ch_labelst= getchanidlst(ch_label)
        if debug:  
           print('\n*** Damping - Channel %s:'%chan, ch_labelst)
        chanmask   = ch_labelst[0]
        chanbus    = ch_labelst[1]
        chanbusname= ch_labelst[2]
        chanbuskv  = ch_labelst[3]
        chantypeid = ch_labelst[-1]
        My['CHANTYPEID'] = chantypeid
        My['CHANI'] = chan
        if chantypeid==2:       # unit ID or load ID?
           chaneleid = ch_labelst[4]
        elif chantypeid==4:       # branch flow P or Q
           chaneleid = ch_labelst[-2]
        else:
           chaneleid = '-'

        # ----
        yo = pltfunc_npa(ch_data[chan])      #apply function to original data
        #yo = ch_data[chan]      #original data
        Yomax  = max(yo)
        Yomin  = min(yo)
        yobegin= yo[0]
        yoend  = yo[-1]
        
        if   'YVALUE_REF' in My:
             Yref = My['YVALUE_REF']
        elif 'TIME_REF' in My:
             if My['TIME_REF']== -1:
                Yref = yo[-1]
             else:
                ib  = JCtools.indexof(xo,My['TIME_REF'])    #index of time_begin
                Yref= yo(ib)
        else:
             if chanmask.upper()=='VOLT':
                Yref = 1.0
             elif chanmask.upper()=='FREQ':   #only if scale is applied to signal
                  Yref = 60.0
             else:
                Yref = yo[0]

        if debug:
            print('Yomax, Yomin, chan, ch_label: ',Yomax, Yomin, chan, ch_label)
            print('top 5: time, yo')
            for k in range(5):
                print(xo[k], yo[k])
                    
        y = yo[ib:ie]
        if not len(y):
           print(' ERROR - Vector y is empty or corrupted. Chan %s %s is bypassed!'%(chan,ch_label))
           continue
        
        yrange= range(len(y))
        Ymax  = max(y)
        iymax = JCtools.indexof(y,Ymax)    #index of Ymax
        Tmax  = x[iymax]
              
        Ymin  = min(y)
        iymin = JCtools.indexof(y,Ymin)    #index of Ymin
        Tmin  = x[iymin]

        #mdo: largest signal deviation in the whole data set
        #mdw: largest signal deviation in the data window
        mdo = Yomax-Yomin
        mdw = Ymax-Ymin
        
        #find period between peaks
        maxpeak, minpeak = peakdet(y,x,chandeltaval)
        # maxpeak (and minpeak) is a list in which every entry has two columns (t, Y): 
        # column 1 contains tseries values, and column 2 the corresponding series values.
        if not maxpeak.all or not minpeak.all:
           print(' Signal has no peaks')
           continue   
        if debug==2:
           print('chan, maxpeak, minpeak')
           print(chan, maxpeak, minpeak)
        if len(maxpeak)<3 or len(minpeak)<3:
           print(' Signal has less than 3 peaks')
           continue   
        PP1 =  maxpeak[-1][1]- minpeak[-1][1]
        PP3 =  maxpeak[-3][1]- minpeak[-3][1]
        T1  = abs(maxpeak[-3][0]- maxpeak[-1][0])/2.0    #period between two crests
        T2  = abs(minpeak[-3][0]- minpeak[-1][0])/2.0
        F   = 2/(T1+T2)                                  #frequency = 1/ avg(T1, T2)
        if debug==2: 
           print(' chan:%s PP1=%s, PP3=%s, ratio=%s, pratio=%s'%(chan,PP1,PP3,PP3/PP1,pratio))
           print('period=',1/F,'   freq=',F)
        if 'FREQLIMIT' in My:
           if F > My['FREQLIMIT']: 
              print(' Signal freq. %s > %s, max. freq'%(F,My['FREQLIMIT']))
              continue
        # end of Alternative method to detect peaks 
           
        if debug==2: 
           print('\nchan=%s, y len:%s, yo len:%s'%(chan,len(y),len(yo)))
           print(Yomax,Yomin, oscAmin, Yref)
           print(Ymax, Ymin,mdw,100.0*mdw/Yref)

        try:     
            if abs(100.0*(Ymax-Ymin)/Yref) < oscAmin:      #the amplitude of oscillation is too small
               print('chan=%s skipped!!  Signal deviation is too small.\n'%(chan))
               continue
            else:
               #print('chan=%s selected!!\n'%(chan))
               if not Ymatrix:
                  labels.append('Time(s)')
                  Ymatrix.append(x)
               Ymatrix.append(y)
               chan_selected.append(chan)
               labels.append('%s_%s'%(chan,ch_label))
               if debug:
                  print(outfile,chan,chanbus,chanbusname,chanbuskv,chaneleid)              
        except:
            print('L3105 - An error occured or the amplitude of oscillation is too small. Yref=',Yref)
            continue

    # -----------------------Damping Calculation--------------------------
    mpdf   = pd.DataFrame()
    dampdf = pd.DataFrame()  
    if labels:
        print('Modal analysis - %s signals selected.\n'%(len(labels)-1))
        print(chan_selected)        
        Ymatrix_df = pd.DataFrame(Ymatrix).T
        if debug==9:
            print ('MA- Ymatrix_df after transpose:')
            print (Ymatrix_df.head())      
        Ymatrix_df.columns = labels
        if debug==9:
            print ('MA- Ymatrix_df with headers:')
            print (Ymatrix_df.head())
            csvpath = 'jcmp.csv'
            open4   = 'w'               # a= append mode, w= overwrite mode
            Ymatrix_df.to_csv(csvpath,index=False,mode=open4)
        #dampdf = outfile     
        mpdf, dampdf = mp.main(Ymatrix_df,outfile,
                                 svd_thresh = svd_thresh,
                                 num_iter   = num_iter,
                                 dampingMax = dampingpct,
                                 plotshow   = plotshow,
                                 reconstruct= reconstruct,
                                 frangemin  = frangemin,
                                 frangemax  = frangemax,
                                 dominantpct= dominantpct,
                                 debug      = debug)
    else:
       print('\nModal analysis - No signal selected in file %s'%outfile)
    return mpdf, dampdf
    
# =============================================================================================
def Channel_Index(chnfobj,channelsx,My,outidx):            #for a single OUT file 
    chantrip  = []
    chanstats = []
    chanovuvd = []
    chanlimit = []
    chantemp1 = []
    outfile = My['OUTLST'][outidx]
    if not channelsx:
       print(' ERROR - No channels detected. %s is bypassed!'%outfile)
       return
    if 'CHANREF' in My:
       channelsx.append(My['CHANREF'])
    case_titles, ch_id, ch_data = chnfobj.get_data(channelsx,outfile)       
    # time vector        
    xo = chanvals_npa(ch_data,'time')         #xo is original time vector
    if not len(xo):
       print(' ERROR - Vector time is empty or corrupted. %s is bypassed!'%outfile)
       return
    if 'XSCALE' not in My:
       My['XSCALE'] = [xo[0],xo[len(xo)-1]]

    ib = 0
    ie = len(xo)-1
    if 'TIME_LASTPCT' in My:
       tend = xo[ie]
       #tt = tend*My['TIME_LASTPCT']/100.0      #tt = last-range data points
       #ib = JCtools.indexof(xo,tend-tt)        #index of time_begin
       tbegin = xo[0] + (tend-xo[0])*(1.0-My['TIME_LASTPCT']/100.0)
       ib = JCtools.indexof(xo,tbegin)        #index of time_begin
       print('ib, ie, x[0],x[-1]')
       print(ib, ie, xo[ib], xo[ie])
    else:
       if 'TIME_BEGIN' in My:
          ib = JCtools.indexof(xo,My['TIME_BEGIN'])    #index of time_begin       
       if 'TIME_END' in My:
          ie = JCtools.indexof(xo,My['TIME_END'])       #index of time_end
    
    x = xo[ib:ie]       #x is a subset time vector
    if not len(x):
       print(' ERROR - Vector time is empty or corrupted. %s is bypassed!'%outfile)
       return
    if My['DEBUG']:  
       print('\n*** Processing time period: %7.3fs - %7.3fs'%(x[0],x[-1]))
    # ----
    # Calculate the index for each channel
    chan_selected = []
    chanlast= False
    for chan in channelsx:
        if 'CHANREF' in My:
           if chan == My['CHANREF']: continue
        if chan == channelsx[-1]: chanlast= True
        ch_label  = ch_id[chan].strip()
        ch_labelst= getchanidlst(ch_label)
        #extendednamestr = JCtools.betweenchars(ch_label,'[',']')
        if My['DEBUG']:  
           print('\n*** Index - Channel %s:'%chan, ch_labelst)
        chanmask   = ch_labelst[0]
        chanbus    = ch_labelst[1]
        chanbusname= ch_labelst[2]
        chanbuskv  = ch_labelst[3]
        chantypeid = ch_labelst[-1]
        My['CHANTYPEID'] = chantypeid
        My['CHANI'] = chan
        if chantypeid==2:       # unit ID or load ID?
           chaneleid = ch_labelst[4]
        elif chantypeid==4:       # branch flow P or Q
           chaneleid = ch_labelst[-2]
        else:
           chaneleid = '-'
        # ----
        yo = []
        if 'CHANREF' in My:
           ytmp = ch_data[chan]
           ychanref = ch_data[My['CHANREF']]
           for i in range(len(ytmp)):
               yo.append(ytmp[i] - ychanref[i])         #relative data respect to chanref
        else:
           yo = ch_data[chan]                       #original data
        yo = pltfunc(yo,chan)                       #apply scale function if any
        Yomax  = max(yo)
        Yomin  = min(yo)
        yobegin= yo[0]
        yoend  = yo[-1]
        
        if   'YVALUE_REF' in My:
             Yref = My['YVALUE_REF']
        elif 'TIME_REF' in My:
             if My['TIME_REF']== -1:
                Yref = yo[-1]
             else:
                ib  = JCtools.indexof(xo,My['TIME_REF'])    #index of time_begin
                Yref= yo(ib)
        else:
             if chanmask.upper()=='VOLT':
                Yref = 1.0
             elif chanmask.upper()=='FREQ':
                  Yref = 60.0
             else:
                Yref = yo[0]
             #My['YVALUE_REF'] = Yref
        y = yo[ib:ie]
        if not y:
           print(' ERROR - Vector y is empty or corrupted. Chan %s %s is bypassed!'%(chan,ch_label))
           continue
        yrange= range(len(y))
        Ymax  = max(y)
        iymax = JCtools.indexof(y,Ymax)    #index of Ymax
        Tmax  = x[iymax]
              
        Ymin  = min(y)
        iymin = JCtools.indexof(y,Ymin)    #index of Ymin
        Tmin  = x[iymin]
              
        if My['DEBUG']: 
           print('chan=%s, y len:%s, yo len:%s'%(chan,len(y),len(yo)))
           print('Yomax,Yomin',Yomax,Yomin)
           print('Ymax, Ymin',Ymax, Ymin)

        ybegin= y[0]
        tbegin= x[0]
        Yend  = y[-1]
        Tend  = x[-1]
        
        import numpy
        dy = numpy.diff(y)
        dx = numpy.diff(x)
        dy = numpy.append(dy,dy[-1])
        dx = numpy.append(dx,dx[-1])
        #JCtools.List2File(zip(x,dx,y,dy),'arrays.csv')
        #JCtools.List2File(zip(x,y),'arrays.csv')
        #slope = dy/dx
                
        # ---------------------------------------------------------------------
        # for VOLT channels, check if bus tripped
        chan_trip = ''
        if 'CHANMASK' in My and My['CHANMASK']== 'VOLT':
           if y[-1]< My['ZEROVTOL']:     #=0.01
              chan_trip = 'BUS_TRIP'
              results=[outfile,chan,chanbus,chanbusname,chanbuskv,chaneleid,
                       chan_trip,
                       0.0,0.0,Ymin,Tmin,Ymax,Tmax,Yend,Tend]
              chantrip.append(results)
              if My['DEBUG']:
                 print(chan, ch_label,chan_trip, ' \t\t%.2f %.2f %.2f %.2f %.2f %.2f %.2f'%(ybegin,Ymin,Tmin,Ymax,Tmax,Yend,Tend))
              continue

        # ---------------------------------------------------------------------
        # CHAN STATs: min, max, risetime, overshoot, settling time
        if 'CHANSTATS' in My:
          for once in range(1):
              if 'TRIPPEDBUS_INC' in My and not My['TRIPPEDBUS_INC']:
                 if chan_trip == 'BUS_TRIP': break
              # risetime, overshoot, settling time 
              if 'RISETIMERNG' in My:
                  risetimerng = My['RISETIMERNG']   #[10,90] of (final value - initial value)
              else:
                  risetimerng = [10,90]
              if 'SETTLINGTRNG' in My:
                  settlingtrng= My['SETTLINGTRNG']  #[-1,1] of final value
              else:
                  settlingtrng= [-1,1]
              if 'CLEARTIME' in My:
                  cleartime = My['CLEARTIME']     # time of event or fault
              else:
                  cleartime = tbegin
              clrtimeidx   = JCtools.indexof(x,cleartime)
              clrtimesign = dy[clrtimeidx]
              if My['DEBUG']>5:
                  print('clrtimeidx:',clrtimeidx)
                  print('dy[clrtimeidx]:',dy[clrtimeidx])
                   #print('dx[clrtimeidx]:',dx[clrtimeidx])
                  print('clrtimesign:',clrtimesign)
              if clrtimesign > 0:
                 sgndelta = Ymax - ybegin
                 ylo = ybegin+risetimerng[0]*sgndelta/100.0
                 yup = ybegin+risetimerng[1]*sgndelta/100.0
              elif clrtimesign < 0:
                   minidx = min2left(y,iymax)
                   minext= y[minidx]
                   sgndelta = Ymax - minext
                   ylo = minext+risetimerng[0]*sgndelta/100.0
                   yup = minext+risetimerng[1]*sgndelta/100.0
              
              risetimeidxa = JCtools.indexof(y, ylo)             
              risetimeidxb = JCtools.indexof(y,yup)                          
              if My['DEBUG']>5:
                  print('ybegin,ylo:',ybegin,ylo)
                  print('ybegin,yup:',ybegin,yup)
                  print('sgndelta, risetimeidxa, risetimeidxb')
                  print(sgndelta, risetimeidxa, risetimeidxb)
                  print('\t', x[risetimeidxb],x[risetimeidxa])
              risetime     = x[risetimeidxb] - x[risetimeidxa]
              overshoot    = 100.0*JCtools.relativepu_float(Ymax,Yend)
              for m in range(len(y)):
                  r = len(y) -1 -m
                  if y[r]> Yend*(1+settlingtrng[1]/100.0) or \
                     y[r]< Yend*(1+settlingtrng[0]/100.0):
                     settlingtime = x[r] - cleartime
                     break

              # Mins & Maxs
              if 'CHANSTATS' in My:
                 results=[outfile,chan,chanbus,chanbusname,chanbuskv,chaneleid,
                          ybegin,tbegin,Ymin,Tmin,Ymax,Tmax,Yend,Tend,risetime,overshoot,settlingtime]
                 chanstats.append(results)
          
                 if My['DEBUG']>5:
                    print('CHANSTATs\nchan, ch_label,Ymin,Tmin,Ymax,Tmax,Yend,Tend,Risetime,Overshoot,Settlingtime')
                     #print('%s, %s \t\t%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f'%(chan, ch_label,ybegin,tbegin,Ymin,Tmin,Ymax,Tmax,Yend,Tend,risetime,overshoot,settlingtime))
                    print('%s, %s \t\t%.2f %.2f %.2f %.2f %.2f %.2f %.2f %.2f'%(chan, ch_label,ybegin,tbegin,Ymin,Tmin,Ymax,Tmax,Yend,Tend))
                    print('overshootpct:%.2f'%(overshoot))
                    print('settlingtime:%.2f'%(settlingtime))
                    print('risetime:',risetime)
            
        # ---------------------------------------------------------------------
        # Under Value Delay Recovery :
        for once in range(1):
            if 'TRIPPEDBUS_INC' in My and not My['TRIPPEDBUS_INC']:
               if chan_trip == 'BUS_TRIP':
                  print('UVDR skip - bus trip condition - chan ', chan)
                  break
            #do a UVDR test
            if 'UVDR' not in My: break          #=0.9 p.u. relative to Yreference
            if not JCtools.WhatType(My['UVDR'])=='LIST':
               UVDRlst = [My['UVDR'],]
               UVDRtlst= [My['UVDRTIME'],]
            else:
               UVDRlst = My['UVDR']
               UVDRtlst= My['UVDRTIME']
            if Ymin >= max(UVDRlst): 
               print('UVDR skip - Ymin >= max(UVDRlst) condition - chan ', chan)
            else:
                for k in range(len(UVDRlst)):
                    #UVDRval = UVDRlst[k]*Yref
                    UVDRval = UVDRlst[k]
                    UVDRtime= UVDRtlst[k]
                    if My['DEBUG']:
                       print('UVDR -UVDRval,UVDRtime:',UVDRval,UVDRtime)
                    fidvr, tkrange = UVDR(y,x,UVDRval,UVDRtime)
                    if fidvr:
                       kr = tkrange[0]
                       fb = kr[0]
                       fe = kr[1]
                       fx = x[fb:fe]
                       fy = y[fb:fe]
                       # find total area
                       dy  = [Yref-fy[t] for t in range(len(fy))]
                       area= JCtools.AreaTrapezoidal(fx, dy)
                       chanovuvd.append([outfile,
                                         chan,
                                         chanbus,
                                         chanbusname,
                                         chanbuskv,
                                         chaneleid,
                                         'UVDR',
                                         area,
                                         x[fb],
                                         x[fe],
                                         UVDRval,
                                         UVDRtime])
                       if My['DEBUG']:
                          print(chan,ch_label,'UVDR',area,x[fb],x[fe],UVDRval,UVDRtime)
                
            # Over Value Delay Recovery :
            if 'OVDR' not in My: break          #=0.9 p.u. relative to Yreference
            if not JCtools.WhatType(My['OVDR'])=='LIST':
               OVDRlst = [My['OVDR'],]
               OVDRtlst= [My['OVDRTIME'],]
            else:
               OVDRlst = My['OVDR']
               OVDRtlst= My['OVDRTIME']
            if Ymax < min(OVDRlst):
               print('OVDR skip - Ymax < min(OVDRlst) condition - chan ', chan)
               #break  #bypass test
            else:
                for k in range(len(OVDRlst)):
                    OVDRval = OVDRlst[k]*Yref
                    OVDRtime= OVDRtlst[k]
                
                    fidvr, tkrange = OVDR(y,x,OVDRval,OVDRtime)
                    if fidvr:
                       kr = tkrange[0]
                       fb = kr[0]
                       fe = kr[1]
                       fx = x[fb:fe]
                       fy = y[fb:fe]
                       # find total area
                       dy  = [fy[t]-Yref for t in range(len(fy))]
                       area= JCtools.AreaTrapezoidal(fx, dy)
                       chanovuvd.append([outfile,
                                         chan,
                                         chanbus,
                                         chanbusname,
                                         chanbuskv,
                                         chaneleid,
                                         'OVDR',
                                         area,
                                         x[fb],
                                         x[fe],
                                         OVDRval,
                                         OVDRtime])
                       if My['DEBUG']:
                          print(chan,ch_label,'OVDR',area,x[fb],x[fe],OVDRval,OVDRtime)

        # ---------------------------------------------------------------------
        # find if Yi is (instantaneously) out of bounds:
        if 'LIMITYPE' in My:
           limitype = My['LIMITYPE']
        high_limit = 0
        if 'YHIGHLIMIT' in My:
           if   limitype==1: #value
                if Ymax > My['YHIGHLIMIT']:
                   high_limit = 1
                   ydev = Ymax - My['YHIGHLIMIT']
                   #ihl  = JCtools.indexof(y,My['YHIGHLIMIT'])    #index
                   #Thl  = x[ihl]

           elif limitype==2: #delta
                deltamax = max(abs(Ymax - Yref),abs(Ymin - Yref))
                if deltamax > My['YHIGHLIMIT']:
                   high_limit = 2
                   if abs(Ymax - Yref)<abs(Ymin - Yref):
                      high_limit = -2
                   ydev  = deltamax
                   #ihl  = JCtools.indexof(y,Ytarget)    #index
                   #Thl  = x[ihl]
           elif limitype==3: #percentage - select if either peak exceed limit
                deltamax = max(abs(JCtools.relativepercentfx(Ymax,Yref)),abs(JCtools.relativepercentfx(Ymin,Yref)))
                if deltamax > My['YHIGHLIMIT']:
                   high_limit = 3
                   if abs(JCtools.relativepercentfx(Ymax,Yref))<abs(JCtools.relativepercentfx(Ymin,Yref)):
                      high_limit = -3
                   ydev = deltamax
           elif limitype==4: #max-min deviation
                deltamax  = abs(Ymax - Ymin)
                if deltamax > My['YHIGHLIMIT']:
                   high_limit = 4
                   ydev = deltamax
                   
        low_limit = ''
        for once in range(1):
            if 'TRIPPEDBUS_INC' in My and not My['TRIPPEDBUS_INC']:
               if chan_trip == 'BUS_TRIP': break
            if 'YLOWLIMIT' in My:
               if   limitype==1: #value
                    if Ymin < My['YLOWLIMIT']:
                       low_limit = True
                       ydev = Ymin - My['YLOWLIMIT']
               elif limitype==2: #delta
                    deltamax = max(abs(Ymax - Yref),abs(Ymin - Yref))
                    if deltamax < My['YLOWLIMIT']:
                       low_limit = True
                       ydev  = deltamax
               elif limitype==3: #percentage
                    deltamax = min(abs(JCtools.relativepercentfx(Ymax,Yref)),abs(JCtools.relativepercentfx(Ymin,Yref)))
                    if deltamax < My['YLOWLIMIT']:
                       low_limit = True
                       ydev  = deltamax
               elif limitype==4: #max-min deviation
                    deltamax  = abs(Ymax - Ymin)
                    if deltamax < My['YLOWLIMIT']:
                       low_limit = True
                       ydev  = deltamax
        
        if high_limit or low_limit:
           # find total area  
           dy  = [abs(y[t]-Yref) for t in yrange]
           area= JCtools.AreaTrapezoidal(x, dy)
           if high_limit:
              limitlabel = 'HIGHLIMIT'
              if   high_limit == 2:
                   limitlabel = 'HIGHDEV'
              elif high_limit == -2:
                   limitlabel = 'HIGHDEV-'
              if   high_limit == 3:
                   limitlabel = 'HIGHPCT'
              elif high_limit == -3:
                   limitlabel = 'HIGHPCT-'
              if   high_limit == 4:
                   limitlabel = 'HIGHP2P'
              results=[outfile,chan,chanbus,chanbusname,chanbuskv,chaneleid,
                       limitlabel,
                       area,ydev,Ymin,Tmin,Ymax,Tmax,Yend,Tend]
              chanlimit.append(results)
              if My['DEBUG']:
                 print(chan, ch_label, ' \t\t%.3f %.2f %.2f %.2f %.2f %.2f %.2f %.2f'%(area, ydev,Ymin,Tmin,Ymax,Tmax,Yend,Tend))
           if low_limit:       
              results=[outfile,chan,chanbus,chanbusname,chanbuskv,chaneleid,
                       'LOWLIMIT',
                       area,ydev,Ymin,Tmin,Ymax,Tmax,Yend,Tend]
              chanlimit.append(results)
              if My['DEBUG']:
                 print(chan, ch_label, ' \t\t%.3f %.2f %.2f %.2f %.2f %.2f %.2f %.2f'%(area, ydev,Ymin,Tmin,Ymax,Tmax,Yend,Tend))

    return chanlimit,chanstats,chanovuvd,chantrip

# ======================================================================
modalresults = []
def modal_mpaa(My):
    chnfobj = My['CHNFOBJ']
    chandampstr,dampdf = Channel_Damping(chnfobj,My)
    #chandamp = chandampstr.split('\n')
    #print(chandampstr)
    #sys.stdout.flush()
    return [chandampstr,dampdf]
    
def call_back(result):
    # This is called whenever run_py returns a result.
    # modalresults is modified only by the main process, not by the pool workers.
    modalresults.append(result)
    
def channelsmain():
    global My
    
    error, My = initialize(My)
    if error:
       saved_stdout = sys.stdout
       saved_stderr = sys.stderr
       logfileobj = open(My['PRGNAME']+'.log', 'w')
       print('X'*40)
       print(' < %s > v.%s'%(My['PRGNAME'],My['PRGVERSION']))
       print(' {:%Y-%b-%d %H:%M:%S}'.format(datetime.datetime.now()))
       print(' \nERROR: Bad file or data in %s. Program quits'%My['INIFILE'])
       print('X'*40)
       sys.stdout = saved_stdout
       sys.stderr = saved_stderr
       print(' \nERROR: Bad file or data in %s. Program quits'%My['INIFILE'])
       return

    if My['DEBUG']==7:
       print('\nChannels:',My['CHANNELS'])
       return
    # My defaults
    My['PSSEVERSIONDEFAULT'] = 35
    My['PYVERDEFAULT']   = 39
    psseversion = My['PSSEVERSIONDEFAULT']
    pyver       = My['PYVERDEFAULT']
    if 'PSSEPATH' in My or 'PSSPYPATH' in My:
        if 'PSSPYPATH' not in My:
           My['PSSPYPATH'] = My['PSSEPATH']
        psseversion = JCtools.psseversion(My['PSSPYPATH'])
        pyver       = JCtools.pyver(My['PSSPYPATH'])
    else:
        if 'PSSEVERSION' in os.environ:
           psseversion = int(os.environ['PSSEVERSION'])
        if 'PYVER' in os.environ:
           pyver = int(os.environ['PYVER'])

    My['PSSEVERSION'] = psseversion
    My['PYVER'] = pyver
    #print(psseversion,pyver)
    with JCtools.silence():
        try: 
            exec('import psse%s'%psseversion)
        except:
            print('ERROR - PSSE%s module was not imported!'%psseversion)
            quit()   
    # ======================================================================
    import dyntools
    # ======================================================================
       
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr
    if 'LOGFILE' in My:
       if My['LOGFILE']:
          logfile = My['LOGFILE']
       else:
          logfile = '%s.log'%My['PRGNAME']
       if 'LOGOPEN' in My and My['LOGOPEN']:
          logopen = My['LOGOPEN'].lower()
       else:
          logopen = 'w'
       logfileobj = open(logfile, logopen)
       sys.stdout = logfileobj
       sys.stderr = logfileobj
     
    prgroot,ext = os.path.splitext(My['PRGNAME'])
    #print('study ',My['STUDY'])
    #print('activity', My['ACTIVITY'])
    if My['STUDY']:
       scenario = "%s_%s"%(My['STUDY'],My['ACTIVITY'])                
    else:
       scenario = "%s_%s"%(prgroot,My['ACTIVITY'])
    #print('0 scenario ',scenario)
    if 'CHANMASK' in My and My['CHANMASK']:
       scenario += "_%s"%My['CHANMASK']
    My['SCENARIO'] = scenario
     #print('007 scenario ',My['SCENARIO'])
    # ======================================================================
    outlst = My['OUTLST']
    My['OUTLST'] = OUTfiles_select(My)
    if not My['OUTLST']:
       print(' ERROR - File(s) not found with selection:%s'%outlst)
       return
    if My['DEBUG']:
       print('OUTFILES:')
       for x in My['OUTLST']: print (x)

    if 'SAVFILE' in My:  #use for Areamask or Zonemask
       My['BUSDICT'] = {}
       try:
          import caspy
          caspydata = caspy.Savecase(My['SAVFILE'])
          caspybus  = list(caspydata.pssbus.num)
          caspyarea = list(caspydata.pssbus.area)
          caspyzone = list(caspydata.pssbus.zone)
          for k in range(len(caspybus)):
              My['BUSDICT'][caspybus[k]] = [caspyarea[k],caspyzone[k]]
          #My['BUSDICT'] = zip(caspybus,caspyarea,caspyzone)
          #My['BUSDICT'] = zip(*My['BUSDICT'])
          if My['DEBUG']:
             print('BUSDICT')
             for row in My['BUSDICT']: print (row)
       except:
          print(' ERROR - caspy not imported. Areamask or Zonemask ignored.')
       caspydata = None
    #======================================================================
    pdfiles = []
    if   My['ACTIVITY']=='COMPARE':
         print(' \nActivity Compare')
         if 'CHANBUS' in My and len(My['CHANBUS'])>0:
            #for chanbusi in My['CHANBUS']:
            #    pdfpage = pyplot_compare_nxm(My,chanbusi)    #1x1 or nx1
            #    pdfiles.append(pdfpage[0]) 
            pdfiles = pyplot_bus_compare()    #
         else:
            pdfiles = pyplot_compare()    #
    else:
         chanlimitT = []
         chanstatsT = []
         chanovuvdT = []
         chantripT  = []
         modalresults= []
         Tmpdf = pd.DataFrame()
         My['RUNI'] = 0
         #if My['ACTIVITY']=='DAMPING':
         #   pool= mup.Pool(processes=My['CPU'])
         for outidx in range(len(My['OUTLST'])):   #for each outfile in outlst do
             print('\n'+'-'*60)
             outlsti = My['OUTLST'][outidx]
             My['OUTLSTI'] = outlsti
             print(' Processing ',outlsti)
             fnameD = JCtools.fnameDic(outlsti)
             My['STUDYI'] = '%s_%s'%(My['STUDY'],fnameD['ROOT'])
             if 'OUTVRSN' not in My:
                 My['OUTVRSN'] = 0
             try:
                 chnfobj = dyntools.CHNF(outlsti, outvrsn=My['OUTVRSN'])
             except:
                 fly = 1
                 try:
                     chnfobj = dyntools.CHNF(outlsti, My['OUTVRSN'])
                 except:
                     fly = 2
                     try:
                         chnfobj = dyntools.CHNF(outlsti)
                     except:
                         fly = 3
                         quit
             if not chnfobj: 
                print ('ERROR - chnfobj not created! quit. ',fly)
                quit()
             # ======================================================================
             # Get and prepare the channel data
             # channels = [1,2,3,4]              -> same group of channels for every OUT file
             # channels = [[1,2],[1,3],[1,5]]     -> three groups of channels for three OUT files
             channels = []
             if 'CHANNELS' in My and My['CHANNELS']:
                if isinstance(My['CHANNELS'][0],list):
                   channels = My['CHANNELS'][outidx]
                else:
                   channels = My['CHANNELS']           
             outChanLst,chanidlsx,busChanD = Channel_select(chnfobj,outidx,channels)
             if not outChanLst:
                print('No channels selected, skip OUT file ',outlsti)
                continue
             if My['DEBUG']:
                print(' %s Channels:'%len(outChanLst),outChanLst)

             # ======================================================================
             if   My['ACTIVITY']=='INFO':
                  Channel_str = All_Channel_info(chnfobj,outChanLst)
                  if Channel_str:
                     print(Channel_str)
                     fname = '%s.dat'%scenario
                     fname = fname.replace('[','')
                     fname = fname.replace(']','')
                     JCtools.Str2File(Channel_str,fname)
                     break
             elif My['ACTIVITY']=='EXPORT':
                  Channels_export(chnfobj,outChanLst,outlsti)            
             elif My['ACTIVITY']=='PLOT':
                  pdfiles += Channel_plot(chnfobj,outChanLst,outlsti)            
             elif My['ACTIVITY']=='VFUNC':
                  pdfiles += vfunc_plot(chnfobj,outChanLst,outlsti)            
             elif My['ACTIVITY']=='INDEX':
                  print(' \nActivity Index')
                  #if 'CHANMASK' not in My: 
                  #   My['CHANMASK']= ''
                  chanlimit,chanstats,chanovuvd,chantrip = Channel_Index(chnfobj,outChanLst,My,outidx)
                  if chanlimit:
                     chanlimitT += chanlimit
                     chan_selected = columnlst(1,chanlimit)        #column start at 0
                     print(' %s Selected - Limit vio:'%len(chan_selected),chan_selected)
                     if 'DOPLOT' in My and My['DOPLOT']:
                        pdfiles += Channel_plot(chnfobj,chan_selected,outlsti,'limit')
                  if chanstats:
                     chanstatsT += chanstats
                  if chanovuvd:
                     chanovuvdT += chanovuvd
                     chan_selected = columnlst(1,chanovuvd)        #column start at 0
                     print(' %s Selected - OVUV vio:'%len(chan_selected),chan_selected)
                     if 'DOPLOT' in My and My['DOPLOT']:
                        pdfiles += Channel_plot(chnfobj,chan_selected,outlsti,'ovuvdelay')                     
                  if chantrip:
                     chantripT += chantrip
             elif My['ACTIVITY']=='DAMPING':
                  print(' \nActivity Damping')
                  My['RUNI'] += 1
                  My['CHANNELSX'] = outChanLst
                  My['CHNFOBJ'] = chnfobj
                  studyi = '%s_%s'%(My['STUDY'] ,My['RUNI'])

                  mpdf,dampdf = Channel_Damping(chnfobj,My)
                  #if not mpdf.empty:
                  if len(mpdf)>0:
                     modalresults.append(dampdf)                     
                     #Tmpdf = Tmpdf.append(mpdf, ignore_index=True)
                     Tmpdf = pd.concat([Tmpdf,mpdf],ignore_index=True)
                  else:
                     print (' Out file %s did not return oscillations data!'%outlsti)
                     continue
         
         if chanlimitT:
            chanlimitT.insert(0,My['HEADERLIMIT'])
         if chanstatsT:
            chanstatsT.insert(0,My['HEADERSTATS'])
         if chantripT:
            chantripT.insert(0,My['HEADERLIMIT'])
         if chanovuvdT:
            chanovuvdT.insert(0,My['HEADERUVOVDR'])
         if My['ACTIVITY']=='DAMPING':
            ##parallel implementation         
            #pool.close()
            #pool.join()
            #sys.stdout.flush()
            #k = -1
            if modalresults:
                pdfiles = modalresults
                pdfiles.sort()
            if len(Tmpdf):
                csvfname = scenario+'_undamped.csv'
                open4   = 'a'               # a= append mode, w= overwrite mode
                if os.path.isfile(csvfname):
                   Tmpdf.to_csv(csvfname,index=False,header=False,mode=open4)
                else:
                   Tmpdf.to_csv(csvfname,index=False)
         if 'IDXFORMAT'in My and My['IDXFORMAT'].upper()=='CSV':
            if chanlimitT:
               chan_vary=[]
               for x in chanlimitT:
                   chan_vary.append(JCtools.Listrec2CSVstr(x))
               JCtools.List2File(chan_vary,scenario+'_limit.csv')
            if chanstatsT:
               chan_vary=[]
               for x in chanstatsT:
                   chan_vary.append(JCtools.Listrec2CSVstr(x))
               JCtools.List2File(chan_vary,scenario+'_stats.csv')
            if chanovuvdT:
               chan_vary=[]
               for x in chanovuvdT:
                   chan_vary.append(JCtools.Listrec2CSVstr(x))
               JCtools.List2File(chan_vary,scenario+'_OVUVdelay.csv')
            if chantripT:
               chan_vary=[]
               for x in chantripT:
                   chan_vary.append(JCtools.Listrec2CSVstr(x))
               JCtools.List2File(chan_vary,scenario+'_trippedbus.csv')
            #if chandampT:
            #   chan_vary=[]
            #   for x in chandampT:
            #       chan_vary.append(JCtools.Listrec2CSVstr(x))
            #   JCtools.List2File(chan_vary,scenario+'_undamped.csv')
         else:
            if chanlimitT:
               make_xlWorkbook(scenario+'.xlsx','LIMITS',chanlimitT)
            if chanstatsT:
               make_xlWorkbook(scenario+'.xlsx','STATS',chanstatsT)
            if chanovuvdT:
               make_xlWorkbook(scenario+'.xlsx','OVUVDELAY',chanovuvdT)
            if chantripT:
               make_xlWorkbook(scenario+'.xlsx','TRIPPED',chantripT)
            #if chandampT:
            #   make_xlWorkbook(scenario+'.xlsx','DAMPING',chandampT)
             
    if pdfiles and 'PLOTSTUDYFILE' in My:
       if 'PLOTPATH' in My and My['PLOTPATH']:
          plotStudyFile = My['PLOTPATH']
       else:
          plotStudyFile = ''
       plotStudyFile += My2filename(My['PLOTSTUDYFILE'])
        #print('pdfiles=',pdfiles)
       #for fname in pdfiles:
       #    print fname
       ier = PDFmerger(pdfiles,plotStudyFile)
       count = 0
       if not ier:
           while not os.path.isfile(plotStudyFile):
                 count += 1
                 if count > 10: break
                 time.sleep(1)
           print('\n'+'_'*60)
           for fname in pdfiles:
               if os.path.isfile(fname):
                  os.remove(fname)    
           print(' PDF files merged into ',plotStudyFile)

    sys.stdout = saved_stdout               # remember to reset sys.stdout!
    sys.stderr = saved_stderr               # remember to reset sys.stdout!
    if not JCtools.run_from_dos:
       redirect.reset()
    return 0
#_______________________________________________________________________
#_____ MAIN
#_______________________________________________________________________
def main():
    global My

    if JCtools.run_from_dos():
       My['RUNFROM2'] = True
       pyverlst = sys.version.split()[0].split('.')
       pyver = int(pyverlst[0])*10+int(pyverlst[1])
       if pyver < 30:
          topstr = chr(223)*60
          botstr = chr(220)*60
          fname  = 'Jose'
       else:
          topstr = '='*60
          botstr = '='*60
          fname  = 'Jose'
       print(topstr)       
       print('  channels v.%s                                  '%My['PRGVERSION'])
       print('                                                         ')
       print('  Copyright - %s Conto, Jan 2016 - All rights reserved '%fname)
       print(botstr)
    else:
       My['RUNFROM2'] = False           
       print(' ERCOT ERCOT ERCOT ERCOT ERCOT ERCOT ERCOT ERCOT ERCOT ERCOT')
       print(' E channels v.%s                                   T'%My['PRGVERSION'])
       print(' E                                                         T')
       print(' E Copyright - Jose Conto, Jan 2016 - All rights reserved  T')
       print(' SYSTEMPLANNING SYSTEMPLANNING SYSTEMPLANNING SYSTEMPLANNING')
    #______________________________________________________________________________
    inifile = ''
    if len(sys.argv)>1:
       inifile = sys.argv[1].replace('@','')
       root,ext = os.path.splitext(inifile)
       if   os.path.isfile(root+'_.ini'):
            inifile = root+'_.ini'
       elif os.path.isfile(root+'.ini'):
            inifile = root+'.ini'
       elif os.path.isdir('inis\\'):
           if os.path.isfile('inis\\%s_.ini'%root):
              inifile = 'inis\\%s_.ini'%root
           elif os.path.isfile('inis\\%s.ini'%root):
                inifile = 'inis\\%s.ini'%root
       else:
            inifile = None
    else:
       if My['PRGNAMEVER']:
          root = '%s_%s'%(My['PRGNAME'],My['PRGNAMEVER'])
       else:
          root = My['PRGNAME']
       if   os.path.isfile(root+'_.ini'):
            inifile = root+'_.ini'
       elif os.path.isfile(root+'.ini'):
            inifile = root+'.ini'        
       elif os.path.isdir('inis\\'):
           if os.path.isfile('inis\\%s_.ini'%root):
              inifile = 'inis\\%s_.ini'%root
           elif os.path.isfile('inis\\%s.ini'%root):
                inifile = 'inis\\%s.ini'%root
       else:
            inifile = None 
                    
    if inifile:     #good INIfile
       My['INIFILE'] = inifile
       channelsmain()
    else:            # -> use GUI
       #app = wx.App(False)
       ##wx.InitAllImageHandlers()
       #appFrame = MyFrame(None, -1, "", size=(450, 450))
       ##app.SetTopWindow(Notebook)
       #appFrame.Show()
       #app.MainLoop()
       print('Check the INI file name or content.')
#__________________________________________________________
if __name__ == '__main__':
   main()
