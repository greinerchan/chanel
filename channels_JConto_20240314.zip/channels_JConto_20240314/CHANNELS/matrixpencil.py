# matrixpencil.py
'''GITHUB posting by Weifarers, Aug.2, 2019. Original package name: IMP-UI

'''
import os, sys
import time, datetime
import numpy as np
import pandas as pd
import scipy as sp
from scipy.linalg import eig

#global vars
debug  = 2

def detrend_constant(val):
    '''
      Does a constant detrend of the data.
      Inputs: val - The data that you want to detrend.
      Returns the detrended data, along with the average used for detrending.
    '''
    # Calculates the average, and subtracts it from the data.
    val = val - val.mean()
    # Divides the new data by its standard deviation, normalized by N.
    return val/(val.std(ddof=0)), val.mean()

def detrend_linear(time, val, label):
    '''
      linear detrend of the data.
      Inputs: time - Time series data.
              val - The data that you want to detrend. In Panda dataframe format!!
              label - The associated labels with each signal.
      Returns:
              detrend_data: the detrended data, df with m_values x n_signals
              quad_poly   : the linear function used for detrending.
              std_list    : the standard deviations
    '''
    degree = 1          # polynomial fitting degree for linear detrend
    # Initializes a data frame to store the detrended data.
    detrend_data = pd.DataFrame()
    # Gets the linear polynomial associated with each signal.
    lin_poly = np.polynomial.polynomial.polyfit(time, val, degree)
    # Initializes a dictionary to store standard deviations.
    std_list = {}
    # Iteratively detrends each signal by its' linear fit.
    for i in range(lin_poly.shape[1]):
        # Gets the current signal label.
        curr_sig = label[i]
        # Gets the linear fit associated with the current signal, and evaluates it for our time steps.
        poly_func = lin_poly[:, i]
        poly_eval = np.polynomial.polynomial.polyval(time, poly_func)
        # Subtracts the linear fit from the original data, and renames the series for storage.
        difference = val.iloc[:, i] - poly_eval
        difference = difference.rename(curr_sig)
        # Gets the standard deviation. We need this to rescale the data later.
        std_diff = difference.std(ddof=0)
        std_list[curr_sig] = std_diff
        # Divides the data by the standard deviation for normalization.
        detrend = difference/std_diff
        # Stores the data in a new list.
        detrend_df = pd.DataFrame(detrend)
        #detrend_data = detrend_data.append(detrend)        # pandas 1.5.3
        detrend_data = pd.concat([detrend_data,detrend], axis=1)
    return detrend_data, lin_poly, std_list

def detrend_quadratic(time, val, label):
    '''
      Does a quadratic detrend of the data.
      Inputs: time - Time series data.
              val - The data that you want to detrend.
              label - The associated labels with each signal.
      Returns:
              detrend_data: the detrended data,
              quad_poly   : the quadratic polynomial used for detrending.
    '''
    degree = 2          # polynomial fitting degree for quadratic detrend
    # Initializes a data frame to store the detrended data.
    detrend_data = pd.DataFrame()
    # Gets the quadratic polynomial associated with each signal.
    quad_poly = np.polynomial.polynomial.polyfit(time, val, degree)

    # Iteratively detrends each signal by its' quadratic fit.
    for i in range(quad_poly.shape[1]):
        # Gets the current signal label.
        curr_sig = label[i]
        # Gets the quadratic fit associated with the current signal, and evaluates it for our time steps.
        poly_func = quad_poly[:, i]
        poly_eval = np.polynomial.polynomial.polyval(time, poly_func)
        # Subtracts the quadratic fit from the original data, and renames the series for storage.
        difference = val.iloc[:, i] - poly_eval
        difference = difference.rename(curr_sig)
        # Divides the data by the standard deviation for normalization.
        detrend = difference/difference.std(ddof=0)
        # Stores the data in a new list.
        detrend_df = pd.DataFrame(detrend)
        #detrend_data = detrend_data.append(detrend)        # pandas 1.5.3
        detrend_data = pd.concat([detrend_data,detrend], axis=1)
    return detrend_data, quad_poly

def imp_mode_present(z, delta_t):
    '''Converts the discrete-time modes into continuous-time modes for presentation purposes.
    Note that when presenting the results:
        - we ignore the complex conjugates, and 
        - only show the eigenvalues with positive complex component.
    Inputs: z - The eigenvalues of the matrix pair {Y2,Y1}.
            delta_t - Time step between data points.
    Returns the modes by frequency and damping percentage.
    '''
    # Converts eigenvalues to continuous time ones.
    ct_lambda = np.log(z) / delta_t
    # Removes all complex conjugates with negative imaginary components.
    ct_lambda = np.extract(np.imag(ct_lambda) > 0.0, ct_lambda)
    
    # Gets the list of frequencies.
    eigen_real = np.real(ct_lambda)
    eigen_imag = np.imag(ct_lambda)
    f_listi    =  eigen_imag/ (2 * np.pi)
    # Gets the list of damping percentages.
    #b_peri = -100 * (eigen_real) / (np.sqrt(np.square(np.real(ct_lambda)) + np.square(np.imag(ct_lambda))))
    b_peri = -100 * eigen_real / np.abs(ct_lambda)
    if debug==2:
        print ('eigenvalues               freq    damping')
        for k in range(len(eigen_real)):
            #if f_listi[k] < 0.000001: continue
            print ('{0:9.6f},  {1:9.6f}, {2:7.2f},   {3:9.6f},'.format(eigen_real[k],eigen_imag[k],f_listi[k],b_peri[k]))
    return f_listi, b_peri

def mode_shapes(y, z):
    '''Calculates the mode shapes associated with each signal.
    Inputs: y - Detrended data that was used to calculate the modes.
            z - The eigenvalues of the matrix pair {Y2,Y1}.
    Returns the mode shapes split into two lists, magnitude and phase.
    '''
    exp     = np.arange(y.shape[0])
    exp_col = np.asmatrix(exp).transpose()
    # Constructs the Z matrix.  Error would occur is value deviations of signal's tail trend to zero
    z_mat = np.power(np.asmatrix(z), exp_col)
    # Solves for the mode shapes.
    mode_shape = np.linalg.lstsq(z_mat, y, rcond=None)[0]
    ## Gets the associated magnitudes and phases.
    #mode_mag   = np.absolute(mode_shape)
    #mode_ang = np.angle(mode_shape)
    #
    #return mode_mag, mode_ang
    return mode_shape

def matrix_pencil(y, svd_thresh):
    '''  the matrix pencil method.
    Inputs: y           - Signal matrix with multiple columns (signal data)
            svd_thresh  - The threshold used to filter the singular values.
    Returns the eigenvalues of the matrix pair {Y2, Y1}
    Gets the N and L (pencil parameter) used to create the Hankel matrix.
    '''
    num_data = y.shape[0]
    l_val = np.floor(num_data / 2)
    l_val = l_val.astype(int)
    # Initializes an empty Hankel matrix.
    hankel = np.array(())
    # Creates a temporary Hankel matrix for every signal.
    for column in y:
        temp_hankel = np.zeros((num_data - l_val, l_val + 1))
        # Iterates through every row of the Hankel matrix.
        for j in range(num_data - l_val):
            temp_hankel[j] = y[column][j:j + l_val + 1]
        # Vertically stacks the Hankel matrices, to increase its' size with more signals.
        # The if statement is there to check for the first instance of the Hankel matrix, where the size is 0.
        hankel = np.vstack([hankel, temp_hankel]) if hankel.size else temp_hankel

    # Takes a SVD of the Hankel matrix..
    u, s_val, vh = np.linalg.svd(hankel)
    # Converts vh into v.
    v = vh.conj().transpose()
    # Gets the largest singular value (=first entry since s_val is sorted in descending order)
    s_first = s_val[0]
    # Scales the values by the large singular value.
    s_val = s_val / s_first
    # Only keeps entries where the scaled value is greater than the threshold.
    s_val = s_val[s_val > svd_thresh]
    # Rescales the singular values back to their original value.
    s_val = s_val * s_first
    # Creates a diagonal matrix with the singular values we kept.
    new_s = np.diag(s_val)

    # Scales the size of the v matrix from SVD based on how many singular values we kept.
    num_cols = new_s.shape[1]
    new_v = v[:, 0:num_cols]

    # Gets the v1 and v2 matrices.
    v_1 = new_v[:-1, :]
    v_2 = new_v[1:, :]

    # Constructs the y1 and y2 matrices from v1/v2
    y_1 = np.dot(v_1.transpose(), v_1)
    y_2 = np.dot(v_2.transpose(), v_1)

    # Gets the eigenvalues of the matrix pair.
    eigs = sp.linalg.eig(y_2, y_1)[0]

    return eigs

def imp_reproduce(mode_shape_all, z, delta_t, signal_label, num_data, time_series, lin_poly, std_list):
    '''
    Reproduces each of the signals given the set of modes.
    Inputs: mode_shape_all - composed of:
                mode_mag    - The list of the magnitudes for each mode shape.
                mode_ang    - The list of the angles for each mode shape.
            z               - The eigenvalues of the matrix pair {Y2, Y1}.
            delta_t         - The time step between data points.
            signal_label    - list of signals in data set.
            num_data        - The number of data points per signal.
            time_series     - List of all time points.
            lin_poly        - List of linear polynomials used for data detrending.
            std_list        - List of standard deviations for each signal.
    Outputs: y_hat_data     - Reproduced data, rescaled.
             y_hat_data_ns  - Reproduced data, but unscaled. This is used for cost function calculations.
    Converts poles to the modes of the signal, which contain the damping and frequency.
    '''   
    # Gets the associated magnitudes and phases.
    mode_mag = np.absolute(mode_shape_all)
    mode_ang = np.angle(mode_shape_all)
    # Converts the discrete-time modes into continuous-time modes
    ct_lambda = np.log(z) / delta_t
    # Getting the number of modes.
    num_modes = ct_lambda.shape[0]
    # Breaks down the lambda into its real (damping) and imaginary (angular frequency) components.
    b_list = np.real(ct_lambda)
    w_list = np.imag(ct_lambda)         #= 2*pi*f
    # Initializing the data frame where we'll store the data.
    y_hat_data = pd.DataFrame()
    # Initializing another DataFrame where we store the unscaled data, so we can calculate the cost function.
    y_hat_data_ns = pd.DataFrame()
    for i in range(len(signal_label)):
        # Creates a name for each new signal.
        #signal_name = 'Signal ' + str(i + 1)
        signal_name = signal_label[i]
        # Gets the standard deviation of the associated signal. signal_label
        curr_std = std_list[signal_name]
        # Gets the detrend associated with the signal as well.
        curr_detrend = lin_poly[:, i]
        # Evaluates the detrend.
        detrend_data_lst = curr_detrend[1] * time_series + curr_detrend[0]
        # Initializes a temporary y_hat that we'll use to store the results.
        y_hat_temp = np.zeros((num_data, 1))
        # Iterating through each mode.
        for j in range(num_modes):
            # The data is split into two components, an exponential one and a cosine one.
            exp_comp = mode_mag[j, i] * np.exp(b_list[j] * time_series)
            cos_comp = np.cos(np.add(w_list[j] * time_series, mode_ang[j, i]))
            
            # Gets the values, and forces them into a shape such that you can combine them.
            exp_comp = exp_comp.values
            exp_comp = exp_comp.reshape((num_data, 1))
            cos_comp = cos_comp.values
            cos_comp = cos_comp.reshape((num_data, 1))
            
            # We update the values every iteration.
            y_hat_temp = np.add(y_hat_temp, np.multiply(exp_comp, cos_comp))

        # Adds this data to our entire reconstructed data set. 
        # Note that here we scale the data by the standard deviation and add back in the detrend,
        # effectively reversing what we had initially done to the data set.
        y_hat_data[signal_name] = curr_std * pd.Series(y_hat_temp.transpose()[0]) + detrend_data_lst
        
        # Stores the unscaled data so we can use it to calculate the cost function for each signal.
        y_hat_data_ns[signal_name] = pd.Series(y_hat_temp.transpose()[0])
    return y_hat_data, y_hat_data_ns

def cost_function(y, y_hat, signal_label, num_data):
    # Initializes a dictionary to store the cost functions.
    cost_list = {}
    # For each signal in our system, calculate the cost function. There's probably a faster way of
    # doing this via matrices, tbh.
    for signal_name in signal_label:
        # Gets a signal name.
        #signal_name = signal_label[i]
        # Calculates the residual.
        residual = np.subtract(y[signal_name], y_hat[signal_name])
        # Calculates the cost function.
        #temp_cost = np.linalg.norm(residual) / num_data
        # Adds this cost function to the list.
        cost_list[signal_name] = np.linalg.norm(residual) / num_data
    return cost_list

def modalplt(mp_df,signal_label,dampingMax,time_data,val_data,y_hat_data,plotshow):
    '''
    def modalplt(source,signal_label,f_list,b_per,dampingMax,time_data,val_data,y_hat_data,plotshow):
    call as:
           dampdf = #modalplt(source,signal_label,f_list,b_per,dampingMax,time_data,val_data,y_hat_data,plotshow
           modalplt(mp_df,dampingMax,time_data,val_data,y_hat_data,plotshow)
    '''
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_pdf import PdfPages
    
    source = mp_df['source'][0]
    sourcebase = os.path.basename(source)
    root,ext   = os.path.splitext(sourcebase)
    dampdf     = '%s_modes.pdf'%root
    pp = PdfPages(dampdf)

    for k in range(len(signal_label)):
        df = mp_df[mp_df['signal_name']==signal_label[k]]
        f_list = list(df['freq'])
        b_per  = list(df['dratio'])
       
    #for k in range(len(f_list)):
        # Initialise the subplot function using number of rows and columns
        #figure, axis = plt.subplots(2)   
        figure, (ax1, ax2) = plt.subplots(2, constrained_layout=True)            
        #figure, (ax1, ax2) = plt.subplots(2)
        #recon_data = y_hat_data.iloc[:, k]
        #orig_data  = val_data.iloc[:, k]
        recon_data = y_hat_data[signal_label[k]].values.tolist()        
        orig_data  = val_data[signal_label[k]].values.tolist()
        time_series= time_data.values.tolist()
        #print('time_data\n',time_data)        
        #print('orig_data\n',orig_data)        
        ax1.plot(time_series, orig_data, label="original")
        ax1.plot(time_series, recon_data, 'r--', label="re-constructed")
        #ax1.legend(loc="best", title="Legend Title", frameon=False)
        ax1.legend(loc="best", frameon=False)
        # Setting the plot options.
        ax1.grid()
        ax1.set_xlabel('Time (s)')
        #plt.ylabel('Frequency (Hz)')
        ax1.set_title('Modal - %s'%signal_label[k])

        # Plotting the modes.
        f_plt = []
        d_plt = []
        for j in range(len(f_list)):
            if f_list[j] <= 0.0: continue
            if b_per[j] > dampingMax: continue
            f_plt.append(f_list[j])
            d_plt.append(b_per[j])
               
        ax2.plot(f_plt, d_plt, 'o')
        #ax2.plot(f_list[k], b_per[k], 'o')
        # Setting the plot options.
        ax2.grid()
        ax2.set_xlabel('Frequency (Hz)')
        ax2.set_ylabel('Damping %')
        ax2.set_title('Modes')
        #ax2.set_ylim([0,10])
        # set the spacing between subplots
        figure.suptitle(root, fontsize=14)
        #figure.tight_layout()
        if plotshow: plt.show()
        pp.savefig(figure)
        plt.close(figure)
    pp.close()
    return dampdf

def imp(time_series, val, labelslst, svd_thresh, num_iter,debug):
    '''
    the Iterative Matrix Pencil method.
    Inputs: time       - Time series
            val        - The data that you want to detrend, in pandas dataframe format.
            labelslst  - The associated labels with each signal.
            svd_thresh - The threshold used to filter the singular values.
            num_iter   - Number of iterations provided by user.
            start_time - Initialization of starting time to time individual components of IMP.

    Outputs: f_list         - List of all the modal frequencies.
             b_per          - List of all the damping percentages for the modal frequencies.
             y_hat_data     - DataFrame containing the reproduced data.
             detrend_data   - DataFrame containing the original data that was detrended.
             cost_list      - List containing all the cost functions for each signal.
    
    Getting some initial values to pass down to the other functions.
      - num_data = number of data points per signal.
      - num_signal = number of signals.
    '''
    num_data   = val.shape[0]
    num_signal = val.shape[1]
    # Also checks if the number of iterations is greater than the number of signals.
    if num_iter > num_signal:
       num_iter = num_signal
    # Initializes some constants for later use.
    eigs = {}
    y_hat_data    = pd.DataFrame()
    y_hat_data_ns = pd.DataFrame()
    mp_df         = pd.DataFrame()      #mp results in df format, total = sum(mp_i)
    iter_time = {}
    f_list    = {}
    b_per     = {}
    # Data Pre-processing
    #print(time_series.info(verbose=True))
    time_series = time_series - time_series[0]      # sets time_series begin time to 0
    delta_t = time_series[1] - time_series[0]       # Gets the time step.
    detrend_data, lin_poly, std_list = detrend_linear(time_series, val, labelslst)
    # Transposes the result so each column is a signal.
    #detrend_data = detrend_data.transpose()
    #print('in IMP\n',detrend_data.head())
    detrend_time = time.time()

    # Iterative Matrix Pencil Method
    # Initializes the data set we'll be applying the matrix pencil method to.
    imp_data = pd.DataFrame()
    # Sets the initial signal to be the first signal in the data set. 
    #This gives us flexibility in choosing our starting point.
    initial_signal = detrend_data.iloc[:, 0]
    imp_data[initial_signal.name] = initial_signal.values
    for i in range(num_iter):
        # Starts a timer for each iteration of the IMP method, along with a dictionary to store values.
        iter_start = time.time()
        
        in_imp = True           # flag for use when checking cost functions.
        # Applies the matrix pencil method to the set of signals.
        eigs = matrix_pencil(imp_data, svd_thresh)
        #print('%s eigs='%len(eigs),eigs)
        matrix_pencil_time = time.time()        # Times the matrix pencil method for each iteration.
        # Gets the mode shapes for all of the data.
        try:
            mode_shape_all = mode_shapes(detrend_data, eigs)
            # Gets the associated magnitudes and phases.
            mode_mag = np.absolute(mode_shape_all)
            mode_ang = np.angle(mode_shape_all)
        except:
            print('ERROR - mode_shape vec NOT calculated.')
            continue
        #print('%s mode_shape_all='%len(mode_shape_all), mode_shape_all)
        mode_shape_df =  pd.DataFrame(mode_shape_all,columns=labelslst)
        #print(mode_shape_df.head())
        mode_shape_time = time.time()       # times how long it takes to get the mode shapes.
        # Reconstructs all of the data.
        y_hat_data, y_hat_data_ns = imp_reproduce(mode_shape_all, eigs, delta_t, labelslst,
                                                  num_data, time_series, lin_poly, std_list)
        reconstruct_time = time.time()      # Times how long it takes to reconstruct the data.

        # Gets the cost functions for all of the data.
        cost_list = cost_function(detrend_data, y_hat_data_ns, labelslst, num_data)
        #print(' Iter %s - Cost List A'%i)
        #print(cost_list)
        cost_time = time.time()     # Times how long it takes to calculate the cost functions.
        # Select signal with the largest cost function.
        max_cost = max(cost_list, key=lambda key: cost_list[key])
        # Includes a conditional that checks whether or not the signal has already been included. 
        # If it has, move to the next highest one. 
        # We use a flag to keep this up until we've run out of signals.
        while in_imp:
            if max_cost in imp_data.keys():
               del cost_list[max_cost]
               # This is a check to see if the list is empty. 
               # If it isn't, which returns true, we can just get the next signal.
               if bool(cost_list):
                  max_cost = max(cost_list, key=lambda key: cost_list[key])
               # If the list is empty, then we've taken the last signal, 
               # so nothing else has to be done and we can exit the loop.
               else:
                   in_imp = False
            else:
               in_imp = False
        # Updates the imp_data list with that signal.
        imp_data[max_cost] = pd.Series(detrend_data[max_cost].values)
        # Generates a dictionary for each iteration that stores the times for each iteration.
        iter_time[i] = ['\tMatrix Pencil: %.3f' % (matrix_pencil_time - iter_start),
                        '\tMode Shape Calculation: %.3f' % (mode_shape_time - matrix_pencil_time),
                        '\tReconstruction: %.3f' % (reconstruct_time - mode_shape_time),
                        '\tCost Function Calculation: %.3f' % (cost_time - reconstruct_time)]
        # Gets the frequencies and damping percentages associated with the last set of eigenvalues from IMP.
        #f_list[i], b_per[i] = imp_mode_present(eigs, delta_t)
        #f_list, b_per = imp_mode_present(eigs, delta_t)
        '''Converts the discrete-time modes into continuous-time modes for presentation purposes.
        Note that when presenting the results:
            - we ignore the complex conjugates, and 
            - only show the eigenvalues with positive complex component.
        Inputs: z - The eigenvalues of the matrix pair {Y2,Y1}.
                delta_t - Time step between data points.
        Returns the modes by frequency and damping percentage.
        '''
        # Converts eigenvalues to continuous time ones.
        ct_lambda_all = np.log(eigs) / delta_t
        #print('ct_lambda_all:\n',ct_lambda_all)
        mp_i = pd.DataFrame(ct_lambda_all, columns=['eigen'])
        #mp_i['mode_shape'] = mode_shape_all
        mp_i['mode_shape'] = mode_shape_df[labelslst[i]]
        mp_i['mode_mag']   = np.absolute(mp_i['mode_shape'])
        mp_i['mode_ang']   = np.angle(mp_i['mode_shape'])
        mp_i['eigen_r']    = np.real(mp_i['eigen'])
        mp_i['eigen_i']    = np.imag(mp_i['eigen'])
        mp_i['dampcoef']   = -100.0*mp_i['eigen_r']
        mp_i['dratio']     = mp_i['dampcoef']/np.abs(mp_i['eigen'])
        mp_i['freq']       = mp_i['eigen_i']/(2.0*np.pi)
        mp_i['dominantidx']= mp_i['mode_mag']/np.abs(mp_i['dratio'])
        dominantmax = max(mp_i['dominantidx'])
        mp_i['dominantidx']= mp_i['dominantidx']/dominantmax        
        #print('o_dominantmax=',mp_i['dominantidx'])
        mp_i['signal_name']= labelslst[i]
        
        #mp_df = mp_df.append(mp_i, ignore_index=True)   #works in pandas 1.5.3    
        mp_df = pd.concat([mp_df,mp_i],ignore_index=True)       
        ##cost_list = cost_function(detrend_data, y_hat_data_ns, labelslst, num_data)
        ##print(' Iter %s - Cost List B'%i)
        ##print(cost_list)        
    return mp_df, cost_list, y_hat_data, detrend_data, detrend_time, iter_time

def main(datadf,source,
         svd_thresh = 0.025,
         num_iter   = 10,
         dampingMax = 9.99,
         xcol = 1,
         ycol = 2,
         wtimebegin = 0.0,
         wtimend    = -1.0,     #signify to the end
         wtimelastpct= 0.0,
         plotshow   = True,
         reconstruct= True,
         frangemin  = 0.2,
         frangemax  = 2.0,
         dominantpct= 0.0,
         debug = 0):
    ''' test of the Iterative Matrix Pencil algorithm
    input: CSV file with time-series data, signal1.csv or signal5.csv
    output: modes and damping factors
    
    Note: The tool best results are achieved when data is "past" 
    its transient switching period, remaining smooth oscillatory waves
    
    CSV file format:
        Time(s), POWR 15[FTWAYNE V2138.00]1, POWR 18[MCKINLEY V2138.00]1, POWR 19[LINCOLN V2138.00]1, POWR 27[MADISON V2138.00]1, POWR 113[DEER CRK V2138.00]1
        1.12501, 0.00319027, 0.00331035, 0.00321779, 0.00323392, 0.0032688
        1.16251, 0.00347135, 0.00349102, 0.00354972, 0.00360591, 0.00354886
    
    '''
    # Initializes a start time for the code, so we can time individual portions.
    start_time = time.time()
    # Establishes some global variables to track computation times.
    # Gets the time series data. Expected at position [0]
    allabels = list(datadf.columns.values)    
    time_data = datadf[allabels[xcol-1]]
    #to = datadf[allabels[xcol-1]]
    #time_data = datadf['Time(s)']
    # Gets the signal labels.
    ##if wtimelastpct > 0.0:
    ##   wtimend = to[-1]
    ##   wtimebegin = to[0] + (wtimend-to[0])*(1.0-wtimelastpct/100.0)      #tt = last-range secs
    ##
    ##if wtimebegin > 0.0:
    ##   idxb = abs(to - wtimebegin).idxmin()
    ##   #idxb = indexof(to,wtimebegin)
    ##else:
    ##   idxb = 0
    ##if wtimend >  wtimebegin:
    ##   idxe = abs(to - wtimend).idxmin()
    ##    #idxe = indexof(to,wtimend)
    ##else:
    ##   idxe = len(to)-1
    ##   
    ##time_data = to[idxb:idxe]      
    ##time_data = time_data.reset_index().drop(['index'], axis=1)
    # Gets the remaining values from the data, 
    # use datadf.iloc[:, start_col:end_col], where [:, asks for all rows
    val_data = datadf.iloc[:, ycol-1:]
    #val_data = datadf.iloc[idxb:idxe, ycol-1:]
    #val_data = val_data.reset_index().drop(['index'], axis=1)
    if debug:
       print (time_data.head())
       print (val_data.iloc[:3])

    #signal_label = list(val_data)
    signal_label = list(val_data.columns.values)
    if debug:
       print ('signal_label=',signal_label)

    # Applies the iterative matrix pencil method.
    mp_df, cost_list, y_hat_data, detrend_data, detrend_time, iter_time = \
                      imp(time_data, val_data, signal_label, svd_thresh, num_iter,debug)
    imp_time = time.time()
    # add source as column
    mp_df['source'] = source
    #print('dominantidx:',mp_df['dominantidx'])
    #apply filtering per user criteria
    df1  = mp_df[mp_df['freq']>= frangemin]    
    df4  = df1[df1['freq']<= frangemax]    
    df2  = df4[df4['dratio'] <= dampingMax]
    #print('1 dominantidx:',df2['dominantidx'])
    mpdf = df2[df2['dominantidx'] > (dominantpct/100.0)]
    if debug:
       print('2 dominantidx:\n',mpdf['dominantidx'])
    # -------------------------------------------------------------------------
    if debug==2:
        cost_df = pd.DataFrame(cost_list)
        #cost_df = pd.DataFrame({"Number": list(cost_list.keys()), 
        #                        "Cost Function": list(cost_list.values())})
        print('\nCost Function Results: \n', cost_df)
    
        print('Time Taken to Detrend Data: %.2f s \n' % (detrend_time - start_time))
        print('Time Taken to do IMP: %.2f s \n' % (imp_time - start_time))

    if reconstruct:
       #dampdf = modalplt(source,signal_label,f_list,b_per,dampingMax,time_data,val_data,y_hat_data,plotshow)
       dampdf = modalplt(mp_df,signal_label,dampingMax,time_data,val_data,y_hat_data,plotshow)
    return mpdf, dampdf

def test():
    '''
    main(datadf,               #dataframe with time as first column, followed by multiple yi
         source,               # = 'filename' or description of data source
         svd_thresh = 0.025,
         num_iter   = 10,
         dampingMax = 9.99,
         debug = 0,
         plotshow = True,
         reconstruct= True):      #to plot Orig + Calc traces
    '''
    #global variables
    My = {}
    My['SIGNAL_LABEL'] = None
    filepath = 'matrixpencil.csv'
    if len(sys.argv)>1:
       filepath = sys.argv[1]
       root,ext = os.path.splitext(filepath)
       if not ext:
          filepath += '.csv'
    root, ext = os.path.splitext(filepath)
    # Out file from input CSV file
    csvpath = '%s_mp.csv'
    # read data into dataframe
    if os.path.isfile(filepath):
        datadf = pd.read_csv(filepath, sep=',')
        mpdf, dampdf = main(datadf,filepath,
                             svd_thresh = 0.005,        #original default = 0.025
                             num_iter   = 10,
                             dampingMax = 9.99,
                             #xcol = 1,
                             #ycol = 2,
                             wtimebegin = 2.0,
                             wtimend    = 10.0,     #signify to the end
                             #wtimelastpct= 34.0,
                             plotshow   = True,
                             reconstruct= True,
                             frangemin  = 0.2,
                             frangemax  = 2.0,
                             #dominantpct= 50.0,
                             debug=1)
        if len(mpdf):
            open4   = 'a'               # a= append mode, w= overwrite mode
            if os.path.isfile(csvpath):
               mpdf.to_csv(csvpath,index=False,header=False,mode=open4)
            else:
               mpdf.to_csv(csvpath,index=False)    
    return
#---------------------------------------------------------------------------
if __name__ == "__main__":
   test()