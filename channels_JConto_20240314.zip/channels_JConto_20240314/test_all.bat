@rem test_channels.bat
@rem run it as: c:\..>test_all
@rem ______________________________
call channels chan_V_info         // list of channels ID
call channels chan_V_exp          // export channels data
call channels chan_V_plt          // plot channels - all-in-one plot
call channels chan_V_plt_3x3      // plot channels - matrix format
call channels chan_V_idx          // rank channels on performance delay recovery
call channels chan_V_cmp          // compare channel from different runs
call channels chan_A_plt          // plot channels - p.u. format
call channels chan_Hz_plt         // plot freq channels with boundary profile 
call channels chan_Bus_plt        // plot channels of selected buses - "bus channels" format
call channels chan_Pe_dmp         // modal analysys of Pe signals
call channels chan_Pe_info
call channels chan_Pe_exp
call channels chan_Pe_plt
call channels chan_Pe_idx
call channels chan_Pe_cmp
