@rem channels.bat
@rem                           %1
@rem run it as: c:\..>channels chan_Pe_idx
@rem                    where "chan_Pe_idx[.ini]" is the argument filename
%pythonhome%python CHANNELS\channels.py %1
