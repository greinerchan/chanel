@echo off
REM Launch channels UI
cd /d "%~dp0"
C:\Users\grein\AppData\Local\Programs\Python\Python38\python.exe ui.py
pause
