@rem channels38.bat
@rem                           %1
@rem run it as: c:\..>channels38 chan_Pe_idx
@rem                    where "chan_Pe_idx[.ini]" is the argument filename
C:\Users\grein\AppData\Local\Programs\Python\Python38\python.exe CHANNELS\channels.py %1
