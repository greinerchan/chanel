channels
A tool to analize PSSe dynamic simulation results (*.out files).
Current version released tested with PSSe v.33, v.34, v.35
Dependency: Matplotlib, numpy, dyntools*, excelpy*, PyPDF2
(*) Installed with PSSe

files to rename: *.tab to *.bat, also in SCRIPTs\ folder

links to be added: 
  a link "__dos33" is included, to open a DOS window (aka.: "PSSe command prompt" link).
  a link "__dos3437" is included, to open a DOS window for PSSe 34 & python 3.7.
  a link "__dos3539" is included, to open a DOS window for PSSe 35 & python 3.9.

More information on the pdf document 'CHANNELS_tool_xx.pdf'

run a test using channels.bat with chan_Pe_plt.ini as argument.  If the INI file does not exist
in the working folder, it will search for it on the folder INIs if exist:
    c:\..>channels chan_Pe_plt		(chan_Pe_plt.ini located at INIs folder)
        
Introduction
� Quickly scan many OUTs files to rank channels� performance based on User�s criteria. 
  List channels that failed the criteria, with option to plot.
� Criteria -scanning channels for min, max violation, UV/OV delay recovery, peak-to-peak and delta violation
� User sets time period to process channels (post-clearing of fault to end), 
  with basic f(x) to scale f-channels, Pe-channels, etc.

For each OUT files and all channels selected:
    1. Detect signal going outside Vmin, Vmax
    2. Detects when signal violates delay recovery criteria
    3. Select lowest-value (or upper-value) channels
    4. ID channels that �tripped� 
    5. Plot only those channels outside criteria

Other features:
� Modal Analysis - Uses Matrix Pencil algorithm, with corresponding input data in INI's section [Damping]
  run demo as  c:\..>channels chan_Pe_dmp

� Flexible option to select channels. It relies on default format of channels definitions:
        ch# CHANNEL ID
        7   POWR 101[NUC-A 21.600]1
� PDF file merging

� Plotting new features include
    � *.out for specific channel type (VOLT, ANGL,�)
    � "all-in-one" plot
    � p.u. plotting
    - bus plots
    _ matrix plots
    - Plots types: 1x1 (one plot per page, default), nx1 (column type), nxm (matrix type)
    � Comparative plots (same channel, multiple *.out)
    � Limit lines & performance profiles
