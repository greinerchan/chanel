# -*- coding: cp1252 -*-
"""
channels UI - Graphical interface for channels.py
Allows users to select INI files, edit parameters, and run channels.py
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, scrolledtext
import os
import sys
import configparser
import subprocess
import glob
import shutil

# Add CHANNELS directory to sys.path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'CHANNELS'))

# ============================================================
# Define which sections/entries are relevant for each ACTIVITY
# ============================================================
ACTIVITY_SECTIONS = {
    'PLOT': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'EXPORT': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'COMPARE': ['study', 'OUTfiles', 'channels', 'PMU', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'INDEX': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'INFO': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'DAMPING': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
    'VFUNC': ['study', 'OUTfiles', 'channels', 'plot', 'Index', 'UVDR', 'OVDR', 'damping', 'Headers', 'INFO', 'EXPORT', 'psse'],
}

# Key entries for each section (the most commonly used ones)
SECTION_ENTRIES = {
    'study': {
        'ACTIVITY': ('PLOT', 'PLOT, EXPORT, COMPARE, INDEX, INFO, DAMPING, VFUNC'),
        'program': ('channels.py', 'Program name'),
        'studyname': ('', 'Study name'),
        'studytype': ('', 'Study type'),
        'debug': ('0', 'Debug mode (0/1)'),
        'logfile': ('', 'Log file name'),
        'logopen': ('w', 'Log open mode (w/a)'),
        'savfile': ('', 'SAV file path (for area/zone mask)'),
        'vfunc_file': ('', 'VFUNC script file path'),
    },
    'OUTfiles': {
        'outvrsn': ('0', 'OUT version (0=old, 1=OUTX)'),
        'outlst': ('', 'OUT file list or wildcard pattern'),
    },
    'channels': {
        'channels': ('', 'Channel numbers (e.g. 41:50 or [1,2,3])'),
        'chanMask': ('', 'Channel mask (ANGL, VOLT, POWR, VARS, FREQ, QLOd...)'),
        'maskexcl': ('', 'Mask exclude patterns'),
        'KVmask': ('', 'KV range mask [min,max]'),
        'Areamask': ('', 'Area mask [area1,area2,...]'),
        'Zonemask': ('', 'Zone mask [zone1,zone2,...]'),
        'Chanexcl': ('', 'Exclude channels by first letter of ID'),
        'Chanincl': ('', 'Include channels by first letter of ID'),
        'chanbus': ('', 'Bus numbers for channel selection'),
        'chantypeid': ('', 'Channel type ID (1=bus, 2=gen, 3=system, 4=branch)'),
        'Chan_fx': ('', 'Channel scaling function'),
    },
    'PMU': {
        'PMUfile': ('', 'PMU CSV file path'),
        'PMUlegend': ('', 'PMU legend text'),
    },
    'plot': {
        'plotpath': ('PLOTs\\', 'Plot output path'),
        'plotshow': ('True', 'Show plot on screen (True/False)'),
        'chansperplot': ('All', 'Channels per plot (All or number)'),
        'plotsperpage': ('', 'Plots per page'),
        'pltrows': ('1', 'Plot rows'),
        'pltcols': ('1', 'Plot columns'),
        'grid': ('0', 'Show grid (0/1)'),
        'marker': ('0', 'Show markers (0/1)'),
        'plotstudyfile': ('', 'Study-level PDF filename'),
        'plotsubfile': ('', 'Sub-level PDF filename'),
        'pagetitle': ('', 'Page title'),
        'title': ('', 'Plot title'),
        'ylabel': ('', 'Y-axis label'),
        'yscale': ('', 'Y-axis scale [min,max]'),
        'xlabel': ('', 'X-axis label'),
        'xscale': ('', 'X-axis scale [min,max]'),
        'xaxis': ('', 'X-axis type (log)'),
        'flatlines': ('', 'Flat reference lines'),
        'flatlinesopt': ('', 'Flat line options'),
        'xyprofile': ('', 'XY profile for limits'),
        'xyprofileopt': ('', 'XY profile options'),
        'linestyle': ('solid', 'Line style (solid, dashed, dashdot, dotted)'),
        'linecolors': ('', 'Line colors'),
        'legend': ('', 'Legend text'),
        'legendpos': ('', 'Legend position'),
        'legendsize': ('', 'Legend font size'),
    },
    'Index': {
        'doplot': ('1', 'Do plot (0/1)'),
        'doexport': ('0', 'Do export (0/1)'),
        'idxformat': ('', 'Index format (CSV/XLS)'),
        'Time_begin': ('', 'Time begin for analysis'),
        'Time_end': ('', 'Time end for analysis'),
        'Time_lastpct': ('30', 'Last percentage of data for analysis'),
        'limitype': ('1', 'Limit type (1=abs, 2=delta, 3=pct, 4=peaktopeak)'),
        'Ylowlimit': ('', 'Y low limit'),
        'Yhighlimit': ('', 'Y high limit'),
        'Yvalue_ref': ('', 'Y reference value'),
        'Tdelta_ref': ('', 'T delta reference'),
        'zerovtol': ('0.01', 'Zero voltage tolerance'),
        'trippedBus_inc': ('True', 'Include tripped buses (True/False)'),
        'chanminval': ('', 'Number of min value channels to select'),
        'chanmaxval': ('', 'Number of max value channels to select'),
        'chanref': ('', 'Reference channel number'),
    },
    'UVDR': {
        'UVDR': ('', 'Under Value Delay Recovery threshold'),
        'UVDRtime': ('', 'Under Value Delay Recovery time (sec)'),
    },
    'OVDR': {
        'OVDR': ('', 'Over Value Delay Recovery threshold'),
        'OVDRtime': ('', 'Over Value Delay Recovery time (sec)'),
    },
    'damping': {
        'dampingpct': ('3.0', 'Damping threshold in pct'),
        'DPwindowbegin': ('20', 'Damping window begin (pct)'),
        'DPwindowend': ('90', 'Damping window end (pct)'),
        'Time_begin': ('', 'Time begin for damping analysis'),
        'Time_end': ('', 'Time end for damping analysis'),
        'Time_lastpct': ('30', 'Last pct for damping analysis'),
        'frange': ('', 'Frequency range [min,max]'),
        'dmpminpts': ('10', 'Minimum data points'),
        'oscthreshold': ('0.015', 'Oscillation threshold'),
        'chandevpct': ('1', 'Channel deviation pct'),
        'chandeltaval': ('0.01', 'Channel delta value'),
        'svd_thresh': ('0.005', 'SVD threshold'),
        'num_iter': ('10', 'Number of iterations'),
        'oscAmin': ('0.05', 'Min oscillation amplitude'),
        'reconstruct': ('True', 'Reconstruct signal plot'),
        'dominantpct': ('0', 'Dominant mode pct filter'),
        'pooldelay': ('2', 'Pool delay'),
        'cpu': ('2', 'CPU count for parallel processing'),
    },
    'Headers': {
        'headerLimit': ('', 'Header for limit output'),
        'headerUVOVDR': ('', 'Header for UV/OVDR output'),
        'headerDamping': ('', 'Header for damping output'),
        'sortkey': ('7', 'Sort key column index'),
    },
    'INFO': {
        'showChannelID': ('1', 'Show channel ID (0/1)'),
        'showChannelData': ('0', 'Show channel data (0/1)'),
        'showChannelRange': ('0', 'Show channel range (0/1)'),
        'showChannelScale': ('0', 'Show channel scale (0/1)'),
        'showChannelPrintScale': ('0', 'Show channel print scale (0/1)'),
    },
    'EXPORT': {
        'exp2txt': ('', 'Export to text filename'),
        'exp2xls': ('', 'Export to Excel filename'),
    },
    'psse': {
        'BusDim': ('80000', 'Bus dimension'),
        'PsseVersion': ('33', 'PSS/E version'),
        'PssePath': ('', 'PSS/E path'),
        'psspyPath': ('', 'PSSPY path'),
    },
}

# Comment descriptions for each section
SECTION_COMMENTS = {
    'study': '[study] - Main study settings',
    'OUTfiles': '[OUTfiles] - Input OUT file settings',
    'channels': '[channels] - Channel selection settings',
    'PMU': '[PMU] - PMU data settings',
    'plot': '[plot] - Plot settings',
    'Index': '[Index] - Index calculation settings',
    'UVDR': '[UVDR] - Under Value Delay Recovery settings',
    'OVDR': '[OVDR] - Over Value Delay Recovery settings',
    'damping': '[damping] - Damping analysis settings',
    'Headers': '[Headers] - Output header settings',
    'INFO': '[INFO] - Channel info display settings',
    'EXPORT': '[EXPORT] - Export settings',
    'psse': '[psse] - PSS/E settings',
}


class ChannelsUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Channels Processing Tool - INI Editor & Runner")
        self.geometry("1100x750")
        
        # Current data
        self.current_ini_path = None
        self.ini_data = {}  # section -> {key: value}
        self.commented_data = {}  # section -> {key: (value, is_commented)}
        self.original_content = []  # lines of original file
        
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.ini_dir = os.path.join(self.base_dir, 'INIs')
        
        # Configure grid expansion
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        
        self.create_widgets()
        self.load_ini_list()
        
    def create_widgets(self):
        # Main paned window
        main_pw = ttk.PanedWindow(self, orient=tk.HORIZONTAL)
        main_pw.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
        
        # Left panel - INI file list
        left_frame = ttk.Frame(main_pw, width=250)
        main_pw.add(left_frame, weight=0)
        
        # Right panel - Editor
        right_frame = ttk.Frame(main_pw)
        main_pw.add(right_frame, weight=1)
        
        # === LEFT PANEL ===
        left_frame.columnconfigure(0, weight=1)
        left_frame.rowconfigure(2, weight=1)
        
        ttk.Label(left_frame, text="INI Files", font=("Helvetica", 12, "bold")).grid(row=0, column=0, sticky="w", padx=10, pady=(10,5))
        
        # INI file listbox
        list_frame = ttk.Frame(left_frame)
        list_frame.grid(row=1, column=0, sticky="ew", padx=10, pady=5)
        list_frame.columnconfigure(1, weight=1)
        
        self.ini_listbox = tk.Listbox(left_frame, width=30, font=("Courier", 9))
        self.ini_listbox.grid(row=2, column=0, sticky="nsew", padx=10, pady=5)
        self.ini_listbox.bind('<<ListboxSelect>>', self.on_ini_select)
        
        # Refresh button
        ttk.Button(left_frame, text="Refresh List", command=self.load_ini_list).grid(row=3, column=0, sticky="ew", padx=10, pady=5)
        
        # New INI button
        ttk.Button(left_frame, text="New INI from Template", command=self.new_ini_from_template).grid(row=4, column=0, sticky="ew", padx=10, pady=5)
        
        # === RIGHT PANEL ===
        right_frame.columnconfigure(0, weight=1)
        right_frame.rowconfigure(2, weight=1)
        
        # Top bar: Activity selector + file info
        top_bar = ttk.Frame(right_frame)
        top_bar.grid(row=0, column=0, sticky="ew", padx=10, pady=(10,5))
        top_bar.columnconfigure(3, weight=1)
        
        ttk.Label(top_bar, text="Activity:", font=("Helvetica", 10, "bold")).grid(row=0, column=0, padx=(0,5))
        self.activity_var = tk.StringVar(value="PLOT")
        self.activity_combo = ttk.Combobox(top_bar, textvariable=self.activity_var, 
                                           values=["PLOT", "EXPORT", "COMPARE", "INDEX", "INFO", "DAMPING", "VFUNC"],
                                           state="readonly", width=12)
        self.activity_combo.grid(row=0, column=1, padx=5)
        self.activity_combo.bind('<<ComboboxSelected>>', self.on_activity_change)
        
        ttk.Label(top_bar, text="INI:", font=("Helvetica", 10, "bold")).grid(row=0, column=2, padx=(15,5))
        self.ini_label = ttk.Label(top_bar, text="(none selected)", font=("Helvetica", 9))
        self.ini_label.grid(row=0, column=3, sticky="w", padx=5)
        
        # Notebook for sections
        self.notebook = ttk.Notebook(right_frame)
        self.notebook.grid(row=1, column=0, sticky="nsew", padx=10, pady=5)
        
        # Bottom bar: Action buttons
        bottom_bar = ttk.Frame(right_frame)
        bottom_bar.grid(row=3, column=0, sticky="ew", padx=10, pady=10)
        
        ttk.Button(bottom_bar, text="Save INI", command=self.save_ini).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_bar, text="Save As...", command=self.save_ini_as).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_bar, text="Run channels.py", command=self.run_channels).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom_bar, text="Quit", command=self.destroy).pack(side=tk.RIGHT, padx=5)
        
        # Status bar
        self.status_var = tk.StringVar(value="Ready")
        status_bar = ttk.Label(right_frame, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.grid(row=4, column=0, sticky="ew", padx=10)
        
        # Store section frames
        self.section_frames = {}
        self.section_widgets = {}  # section -> {key: widget}
        
    def load_ini_list(self):
        """Load list of INI files from INIs directory"""
        self.ini_listbox.delete(0, tk.END)
        if os.path.exists(self.ini_dir):
            ini_files = sorted(glob.glob(os.path.join(self.ini_dir, '*.ini')))
            for f in ini_files:
                self.ini_listbox.insert(tk.END, os.path.basename(f))
        self.status_var.set(f"Found {self.ini_listbox.size()} INI files")
    
    def parse_ini_file(self, filepath):
        """Parse an INI file, preserving comments and structure"""
        self.ini_data = {}
        self.commented_data = {}
        self.original_content = []
        
        current_section = None
        
        with open(filepath, 'r', encoding='cp1252', errors='replace') as f:
            lines = f.readlines()
        
        self.original_content = lines
        
        for line in lines:
            stripped = line.strip()
            
            # Skip empty lines
            if not stripped:
                continue
            
            # Section header
            if stripped.startswith('[') and ']' in stripped:
                section_name = stripped[1:stripped.index(']')].strip()
                current_section = section_name
                if current_section not in self.ini_data:
                    self.ini_data[current_section] = {}
                    self.commented_data[current_section] = {}
                continue
            
            # Comment line (starts with / or //)
            if stripped.startswith('/') or stripped.startswith('//'):
                continue
            
            # Key=value line (may have inline comments with // or /)
            if '=' in stripped and not stripped.startswith('['):
                # Split on first =
                eq_pos = stripped.index('=')
                key = stripped[:eq_pos].strip()
                rest = stripped[eq_pos+1:].strip()
                
                # Remove inline comments
                value = rest
                for comment_char in [' //', ' /', '\t//', '\t/']:
                    if comment_char in value:
                        value = value[:value.index(comment_char)].strip()
                
                # Check if originally commented
                is_commented = False
                # Find original line to check
                orig_stripped = line.strip()
                if orig_stripped.startswith('//') or orig_stripped.startswith('/'):
                    is_commented = True
                    # Extract key=value from comment
                    comment_content = orig_stripped.lstrip('/').strip()
                    if '=' in comment_content:
                        eq_pos2 = comment_content.index('=')
                        key = comment_content[:eq_pos2].strip()
                        rest2 = comment_content[eq_pos2+1:].strip()
                        for cc in [' //', ' /', '\t//', '\t/']:
                            if cc in rest2:
                                rest2 = rest2[:rest2.index(cc)].strip()
                        value = rest2
                
                if current_section:
                    if current_section not in self.ini_data:
                        self.ini_data[current_section] = {}
                        self.commented_data[current_section] = {}
                    self.ini_data[current_section][key] = value
                    self.commented_data[current_section][key] = is_commented
        
        self.current_ini_path = filepath
        self.ini_label.config(text=os.path.basename(filepath))
        
    def on_ini_select(self, event):
        """Handle INI file selection from list"""
        selection = self.ini_listbox.curselection()
        if not selection:
            return
        
        filename = self.ini_listbox.get(selection[0])
        filepath = os.path.join(self.ini_dir, filename)
        
        if os.path.exists(filepath):
            self.parse_ini_file(filepath)
            self.build_editor_tabs()
            self.status_var.set(f"Loaded: {filename}")
    
    def on_activity_change(self, event=None):
        """Handle activity change - show relevant sections"""
        activity = self.activity_var.get()
        # Update the ACTIVITY value in the study section
        if 'study' in self.ini_data:
            self.ini_data['study']['ACTIVITY'] = activity
        
        # Rebuild tabs to show only relevant sections
        self.build_editor_tabs()
    
    def build_editor_tabs(self):
        """Build notebook tabs based on current activity and available data"""
        # Clear existing tabs
        for tab_id in self.notebook.tabs():
            self.notebook.forget(tab_id)
        self.section_frames = {}
        self.section_widgets = {}
        
        activity = self.activity_var.get()
        relevant_sections = ACTIVITY_SECTIONS.get(activity, list(SECTION_ENTRIES.keys()))
        
        # Get sections that have data in the current INI
        available_sections = set(self.ini_data.keys()) if self.ini_data else set()
        
        # Always show sections that are relevant, even if empty
        sections_to_show = []
        for sec in relevant_sections:
            if sec in available_sections or sec in SECTION_ENTRIES:
                sections_to_show.append(sec)
        
        # Also add any sections from the INI that aren't in our predefined list
        for sec in available_sections:
            if sec not in sections_to_show:
                sections_to_show.append(sec)
        
        if not sections_to_show:
            # Show a placeholder tab
            placeholder = ttk.Frame(self.notebook)
            self.notebook.add(placeholder, text="No Data")
            ttk.Label(placeholder, text="Select an INI file from the left panel", 
                     font=("Helvetica", 14)).pack(expand=True, pady=50)
            return
        
        for section in sections_to_show:
            frame = ttk.Frame(self.notebook)
            self.notebook.add(frame, text=section)
            self.section_frames[section] = frame
            self.build_section_editor(section, frame)
    
    def build_section_editor(self, section, parent_frame):
        """Build editor widgets for a section"""
        parent_frame.columnconfigure(1, weight=1)
        parent_frame.rowconfigure(0, weight=1)
        
        # Canvas + Scrollbar for scrolling
        canvas = tk.Canvas(parent_frame, highlightthickness=0)
        scrollbar = ttk.Scrollbar(parent_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        
        # Mouse wheel scrolling
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        
        scrollable_frame.columnconfigure(1, weight=1)
        
        # Section comment
        comment = SECTION_COMMENTS.get(section, f'[{section}]')
        ttk.Label(scrollable_frame, text=comment, font=("Helvetica", 10, "italic"), 
                 foreground="gray").grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10,5))
        
        # Get section data
        section_data = self.ini_data.get(section, {})
        section_comments = self.commented_data.get(section, {})
        
        # Get predefined entries for this section
        predefined = SECTION_ENTRIES.get(section, {})
        
        # Collect all keys (predefined + extra from INI)
        all_keys = list(predefined.keys())
        for key in section_data:
            if key not in all_keys:
                all_keys.append(key)
        
        if not all_keys:
            ttk.Label(scrollable_frame, text="(No editable parameters)", 
                     font=("Helvetica", 10)).grid(row=1, column=0, columnspan=3, padx=10, pady=10)
            return
        
        self.section_widgets[section] = {}
        row = 1
        
        for key in all_keys:
            default_val, hint = predefined.get(key, ('', ''))
            current_val = section_data.get(key, default_val)
            is_commented = section_comments.get(key, False)
            
            # Key label
            key_label = ttk.Label(scrollable_frame, text=key, font=("Courier", 9, "bold"))
            key_label.grid(row=row, column=0, sticky="e", padx=(10,5), pady=3)
            
            # Value entry
            var = tk.StringVar(value=str(current_val))
            entry = ttk.Entry(scrollable_frame, textvariable=var, font=("Courier", 9))
            entry.grid(row=row, column=1, sticky="ew", padx=5, pady=3)
            
            # Commented checkbox
            commented_var = tk.BooleanVar(value=is_commented)
            commented_cb = ttk.Checkbutton(scrollable_frame, text="//", variable=commented_var)
            commented_cb.grid(row=row, column=2, sticky="w", padx=2, pady=3)
            
            # Hint tooltip
            if hint:
                hint_label = ttk.Label(scrollable_frame, text=hint, font=("Helvetica", 8), foreground="gray")
                hint_label.grid(row=row, column=3, sticky="w", padx=5, pady=3)
            
            self.section_widgets[section][key] = {
                'var': var,
                'commented_var': commented_var,
                'entry': entry,
                'checkbox': commented_cb
            }
            
            row += 1
        
        # Add a "raw" section for any extra keys not in predefined
        extra_keys = [k for k in section_data if k not in predefined]
        if extra_keys:
            sep = ttk.Separator(scrollable_frame, orient='horizontal')
            sep.grid(row=row, column=0, columnspan=4, sticky="ew", padx=10, pady=10)
            row += 1
            ttk.Label(scrollable_frame, text="Additional parameters:", 
                     font=("Helvetica", 9, "italic")).grid(row=row, column=0, columnspan=4, sticky="w", padx=10)
            row += 1
    
    def collect_editor_data(self):
        """Collect all data from editor widgets back into ini_data"""
        for section, widgets in self.section_widgets.items():
            if section not in self.ini_data:
                self.ini_data[section] = {}
            if section not in self.commented_data:
                self.commented_data[section] = {}
            
            for key, w in widgets.items():
                self.ini_data[section][key] = w['var'].get()
                self.commented_data[section][key] = w['commented_var'].get()
    
    def generate_ini_content(self):
        """Generate INI file content from current data"""
        self.collect_editor_data()
        
        lines = []
        activity = self.activity_var.get()
        
        # Header
        lines.append(f"/ channels INI file - generated by channels UI")
        lines.append(f"/ Activity: {activity}")
        lines.append(f"")
        
        # Determine section order based on activity
        relevant_sections = ACTIVITY_SECTIONS.get(activity, list(SECTION_ENTRIES.keys()))
        
        # Add sections in order, plus any extra sections
        all_sections = []
        for sec in relevant_sections:
            if sec in self.ini_data:
                all_sections.append(sec)
        for sec in self.ini_data:
            if sec not in all_sections:
                all_sections.append(sec)
        
        for section in all_sections:
            section_data = self.ini_data.get(section, {})
            section_comments = self.commented_data.get(section, {})
            
            if not section_data:
                continue
            
            # Section header
            comment = SECTION_COMMENTS.get(section, f'[{section}]')
            lines.append(f"")
            lines.append(f"  {comment}")
            lines.append(f"")
            
            # Get predefined entries order
            predefined = SECTION_ENTRIES.get(section, {})
            
            # Write predefined keys first, then extras
            written_keys = set()
            
            for key in predefined:
                if key in section_data:
                    val = section_data[key]
                    is_commented = section_comments.get(key, False)
                    hint = predefined[key][1]
                    
                    if val or is_commented:
                        prefix = '//' if is_commented else ''
                        hint_str = f'  //{hint}' if hint else ''
                        lines.append(f"{prefix}{key} = {val}{hint_str}")
                    written_keys.add(key)
            
            # Write extra keys
            for key in section_data:
                if key not in written_keys:
                    val = section_data[key]
                    is_commented = section_comments.get(key, False)
                    if val or is_commented:
                        prefix = '//' if is_commented else ''
                        lines.append(f"{prefix}{key} = {val}")
            
            lines.append(f"")
        
        # Add info section at the end
        lines.append(f"")
        lines.append(f"  [info]")
        lines.append(f"/default values are in brackets")
        lines.append(f"/comments start with or from /")
        lines.append(f"/in-line comments are stripped before reading keyword value")
        lines.append(f"/path ending with '\\' is required")
        lines.append(f"/run as:")
        lines.append(f"/runpy channels [inifile]")
        lines.append(f"")
        
        return '\n'.join(lines)
    
    def save_ini(self):
        """Save current INI file"""
        if not self.current_ini_path:
            self.save_ini_as()
            return
        
        content = self.generate_ini_content()
        try:
            with open(self.current_ini_path, 'w', encoding='cp1252') as f:
                f.write(content)
            self.status_var.set(f"Saved: {os.path.basename(self.current_ini_path)}")
            messagebox.showinfo("Success", f"INI file saved:\n{self.current_ini_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")
    
    def save_ini_as(self):
        """Save INI file with new name"""
        content = self.generate_ini_content()
        
        filepath = filedialog.asksaveasfilename(
            initialdir=self.ini_dir,
            title="Save INI File As",
            defaultextension=".ini",
            filetypes=[("INI files", "*.ini"), ("All files", "*.*")]
        )
        
        if filepath:
            try:
                with open(filepath, 'w', encoding='cp1252') as f:
                    f.write(content)
                self.current_ini_path = filepath
                self.ini_label.config(text=os.path.basename(filepath))
                self.status_var.set(f"Saved: {os.path.basename(filepath)}")
                messagebox.showinfo("Success", f"INI file saved:\n{filepath}")
                # Refresh list
                self.load_ini_list()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save: {e}")
    
    def new_ini_from_template(self):
        """Create a new INI file from template based on selected activity"""
        activity = self.activity_var.get()
        
        # Create template data
        self.ini_data = {}
        self.commented_data = {}
        self.current_ini_path = None
        
        # Build template based on activity
        relevant_sections = ACTIVITY_SECTIONS.get(activity, ['study', 'OUTfiles', 'channels', 'plot', 'Index'])
        
        for section in relevant_sections:
            self.ini_data[section] = {}
            self.commented_data[section] = {}
            predefined = SECTION_ENTRIES.get(section, {})
            for key, (default_val, hint) in predefined.items():
                if default_val:
                    self.ini_data[section][key] = default_val
                    self.commented_data[section][key] = False
                else:
                    self.ini_data[section][key] = ''
                    self.commented_data[section][key] = True  # Comment out empty ones
        
        # Set activity
        if 'study' in self.ini_data:
            self.ini_data['study']['ACTIVITY'] = activity
            self.commented_data['study']['ACTIVITY'] = False
        
        self.ini_label.config(text="(new file - save as...)")
        self.build_editor_tabs()
        self.status_var.set(f"New {activity} template created. Edit and Save As...")
    
    def run_channels(self):
        """Run channels.py with current INI file"""
        # First save the INI
        if not self.current_ini_path:
            self.save_ini_as()
            if not self.current_ini_path:
                return
        
        self.save_ini()
        
        # Find python executable
        python_exe = sys.executable
        if not python_exe:
            python_exe = "python"
        
        channels_script = os.path.join(self.base_dir, 'CHANNELS', 'channels.py')
        ini_file = self.current_ini_path
        
        if not os.path.exists(channels_script):
            messagebox.showerror("Error", f"channels.py not found at:\n{channels_script}")
            return
        
        # Run in a separate window
        cmd = f'start "Channels" "{python_exe}" "{channels_script}" "{ini_file}"'
        
        try:
            self.status_var.set(f"Running: {python_exe} {channels_script} {ini_file}")
            os.system(cmd)
            messagebox.showinfo("Running", 
                f"channels.py is running in a new window.\n\n"
                f"INI: {ini_file}\n"
                f"Python: {python_exe}\n\n"
                f"Check the console window for output.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to run: {e}")


if __name__ == "__main__":
    app = ChannelsUI()
    app.mainloop()
